/*
 * Copyright (c) 2004, 2005 TADA AB - Taby Sweden
 * Distributed under the terms shown in the file COPYRIGHT
 * found in the root folder of this project or at
 * http://eng.tada.se/osprojects/COPYRIGHT.html
 */
package org.postgresql.pljava.example;

import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import org.postgresql.pljava.ObjectPool;
import org.postgresql.pljava.PooledObject;
import org.postgresql.pljava.ResultSetProvider;
import org.postgresql.pljava.SessionManager;

/**
 * @author Thomas Hallgren
 */
public class UsingProperties implements ResultSetProvider, PooledObject
{
	private static Logger s_logger = Logger.getAnonymousLogger();
	private final Properties m_properties;
	private final ObjectPool m_pool;

	private Iterator m_propertyIterator;

	public UsingProperties(ObjectPool pool)
	throws IOException
	{
		m_pool = pool;
		m_properties = new Properties();

		s_logger.info("** UsingProperties()");
		InputStream propStream = this.getClass().getResourceAsStream("example.properties");
		if(propStream == null)
		{
			s_logger.info("example.properties was null");
		}
		else
		{
			m_properties.load(propStream);
			propStream.close();
			s_logger.info("example.properties has " + m_properties.size() + " entries");
		}
	}

	public void activate()
	{
		s_logger.info("** UsingProperties.activate()");
		m_propertyIterator = m_properties.entrySet().iterator();
	}

	public void remove()
	{
		s_logger.info("** UsingProperties.remove()");
		m_properties.clear();
	}

	public void passivate()
	{
		s_logger.info("** UsingProperties.passivate()");
		m_propertyIterator = null;
	}

	public boolean assignRowValues(ResultSet receiver, int currentRow)
			throws SQLException
	{
		if(!m_propertyIterator.hasNext())
		{
			s_logger.fine("no more rows, returning false");
			return false;
		}
		Map.Entry propEntry = (Map.Entry)m_propertyIterator.next();
		receiver.updateString(1, (String)propEntry.getKey());
		receiver.updateString(2, (String)propEntry.getValue());
		// s_logger.fine("next row created, returning true");
		return true;
	}

	public void close()
	throws SQLException
	{
		m_pool.passivateInstance(this);
	}

	public static ResultSetProvider getProperties()
	throws SQLException
	{
		ObjectPool pool = SessionManager.current().getObjectPool(UsingProperties.class);
		return (ResultSetProvider)pool.activateInstance();
	}
}
