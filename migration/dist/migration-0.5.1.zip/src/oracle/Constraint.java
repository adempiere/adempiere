package oracle;

public class Constraint {

	/**
	 * Constructor.
	 * @param name	constraint name
	 * @param tableName 
	 */
	public Constraint(String name, String tableName) {
		this.name = name;
		this.tableName = tableName;
	}

	public static final String PRIMARY_KEY = "P";

	public static final String FOREIGN_KEY = "R";

	public static final String CHECK = "C";

	public static final String UNIQEINDEX = "U"; // TODO: implement...

	/** constraint name */
	private String name;

	/** constraint type */
	private String type;

	/** table (to alter) */
	private String tableName;
	
	/** condition of check constraints */
	private String checkCondition;

	/** index name of unique index * */
	private String indexName;

	/** name of primary/foreign key column */
	private String columnName;

	/** on delete clause */
	private String onDelete;

	/**
	 * needed for foreign keys - the primary key constraint of the referenced
	 * table
	 */
	private Constraint rConstraint;

	private String deleteRule;

	/**
	 * Returns an sql statement that adds the constrain to its table.
	 * @return alter table statement
	 */
	public String getAlterTableString() {
		StringBuffer buffer = new StringBuffer();

		buffer = buffer.append("ALTER TABLE ").append(tableName);
		buffer = buffer.append(" ADD ");

		if (type.equals(PRIMARY_KEY)) {
			buffer = buffer.append("CONSTRAINT ");
			buffer = buffer.append(name).append(" PRIMARY KEY (").append(columnName).append(")");
		} else if (type.equals(FOREIGN_KEY)) {
			buffer = buffer.append("CONSTRAINT ");
			buffer = buffer.append(name).append(" FOREIGN KEY (");
			buffer = buffer.append(columnName).append(")");
			buffer = buffer.append(" REFERENCES ").append(rConstraint.getTableName());
			buffer = buffer.append(" (").append(rConstraint.getColumnName()).append(")");
			if (onDelete != null) {
				buffer.append(" ON DELETE " + onDelete);
			}
		} else if (type.equals(CHECK)) {
			buffer = buffer.append("CHECK (").append(checkCondition).append(")");
		} else if (type.equals(UNIQEINDEX)) {
			// TODO implementation
		}
		
		buffer = buffer.append(";");
		return buffer.toString();
	}
	
	public String getDropString(){
		StringBuffer buffer = new StringBuffer();
		buffer = buffer.append("ALTER TABLE ").append(tableName);
		buffer = buffer.append(" DROP CONSTRAINT ").append(name).append(";");
		return buffer.toString();
	}

	public String getCheckCondition() {
		return checkCondition;
	}

	public void setCheckCondition(String checkCondition) {
		this.checkCondition = checkCondition;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getIndexName() {
		return indexName;
	}

	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Constraint getRConstraint() {
		return rConstraint;
	}

	public void setRConstraint(Constraint constraint) {
		rConstraint = constraint;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDeleteRule(String deleteRule) {
		this.deleteRule = deleteRule;
		
	}

}
