package oracle;

import java.util.Vector;

public class Table {

	/** all columns of the table */
	private Vector<Column> allTableColumns = new Vector<Column>();

	/** missing columns of the table in comparisment with the other db */
	private Vector<Column> columnsToAdd = new Vector<Column>();
	
	/** changed columns of the table in comparisment with the other db */
	private Vector<Column> columnsToModify = new Vector<Column>();
	
	/** columns of the table deleted (missing) in db2 */
	private Vector<Column> columnsToDrop = new Vector<Column>();

	/** table name */
	private String name;

	/**
	 * Constructor.
	 * @param name
	 */
	public Table(String name) {
		this.name = name;
	}

	/**
	 * Returns a create table statement.
	 * @return create table statement
	 */
	public String getCreateStatement() {
		StringBuffer insert = new StringBuffer();
		insert = insert.append("CREATE TABLE ").append(name).append("\n");
		insert = insert.append("(").append("\n");
		for (int i = 0; i < allTableColumns.size(); i++) {
			insert = insert.append(allTableColumns.get(i).getDefinitionString());
			if (i != allTableColumns.size() - 1) {
				insert = insert.append(",\n");
			}
		}
		insert = insert.append("\n").append(");\n");
		return insert.toString();
	}
	

	/**
	 * Returns a alter table statement.
	 * @return	alter table statement
	 */
	public String getAlterAddStatement() {
		StringBuffer alter = new StringBuffer();
		alter = alter.append("ALTER TABLE ").append(name).append("\n");
		alter = alter.append("ADD (").append("\n");
		for (int i = 0; i < columnsToAdd.size(); i++) {
			if(!columnsToAdd.get(i).isNullable()&&
					columnsToAdd.get(i).getDefaultValue()==null){
				alter = alter.append("\n-- BEWARE YOU NEED TO SET A DEFAULT VALUE TEMPORARILY\n");
			}
			alter = alter.append(columnsToAdd.get(i).getDefinitionString());
			if (i != columnsToAdd.size() - 1) {
				alter = alter.append(",\n");
			}
		}
		alter = alter.append("\n").append(");\n");
		return alter.toString();
	}
	
	/**
	 * Returns a alter table statement.
	 * @return	alter table statement
	 */
	public String getAlterDropStatement() {
		StringBuffer alter = new StringBuffer();
		alter = alter.append("ALTER TABLE ").append(name).append("\n");
		alter = alter.append("DROP (").append("\n");
		for (int i = 0; i < columnsToDrop.size(); i++) {
			alter = alter.append(columnsToDrop.get(i).getColumnName());
			if (i != columnsToDrop.size() - 1) {
				alter = alter.append(",\n");
			}
		}
		alter = alter.append("\n").append(");\n");
		return alter.toString();
	}
	
	/**
	 * Returns a alter table statement.
	 * @return	alter table statement
	 */
	public String getAlterModifyStatement() {
		StringBuffer alter = new StringBuffer();
		alter = alter.append("ALTER TABLE ").append(name).append("\n");
		alter = alter.append("Modify (").append("\n");
		for (int i = 0; i < columnsToModify.size(); i++) {
			if(!columnsToModify.get(i).isNullable()&&
					columnsToModify.get(i).getDefaultValue()==null){
				alter = alter.append("\n-- BEWARE YOU NEED TO SET A DEFAULT VALUE TEMPORARILY\n");
			}
			alter = alter.append(columnsToModify.get(i).getDefinitionString());
			if (i != columnsToModify.size() - 1) {
				alter = alter.append(",\n");
			}
		}
		alter = alter.append("\n").append(");\n");
		return alter.toString();
	}
	
	public String getDropStatement(){
		return "DROP TABLE " + name + ";";
	}
	
	/**
	 * Adds a columns to the table.
	 * @param column
	 */
	public void addColumn(Column column) {
		if (!allTableColumns.contains(column)) {
			allTableColumns.add(column);
		}
	}

	/**
	 * Adds a missing colum that will be included in the alter statement.
	 * @param column
	 */
	public void addColumnToAdd(Column column) {
		if (!columnsToAdd.contains(column)) {
			columnsToAdd.add(column);
		}
	}
	
	/**
	 * Adds a colum that will be dropped from the table.
	 * @param column
	 */
	public void addColumnToDrop(Column column) {
		if (!columnsToDrop.contains(column)) {
			columnsToDrop.add(column);
		}
	}
	
	/**
	 * Adds a column that has been modified between the two dbs.
	 * @param column
	 */
	public void addColumnToModify(Column column) {
		if (!columnsToModify.contains(column)) {
			columnsToModify.add(column);
		}
	}
	
	public boolean isAlterAdd(){
		return columnsToAdd.size()>0;
	}
	
	public boolean isAlterDrop(){
		return columnsToDrop.size()>0;
	}
	
	public boolean isAlterModify(){
		return columnsToModify.size()>0;
	}

}
