Written by Karsten Thiemann, kt@schaeffer-ag.de

How to build a Compiere/Adempiere migration script.


Installation of reference database (target)

1.	Create a new Oracle database with the name c253b.
2.	Check the connectivity of the new db with tnsping:
	from console: tnsping c253b
3. 	Download Compiere253b (the version to migrate to)
4.	Import the compiere reference into the new database
	Replace COMPIERE_DB_PASSWORD w�th the password of the new oracle
	database system user password and COMPIERE253b_DIRECTORY with
	the directory of the downloaded Compiere253b
	
	- create a user compiere with password compiere in the reference db:
	prompt>sqlplus system/COMPIERE_DB_PASSWORD@c253b @"COMPIERE253b_DIRECTORY\utils\oracle\CreateUser.sql" compiere compiere
	
	- import dump
	prompt>imp system/COMPIERE_DB_PASSWORD@c253b FILE="COMPIERE253b_DIRECTORY\data\Compiere.dmp" FROMUSER=(reference) TOUSER=compiere STATISTICS=RECALCULATE
	
	- import sqlj functions
	 prompt>loadjava -user compiere/COMPIERE_DB_PASSWORD@COMPIERE_DB_NAME -verbose -force -resolve "COMPIERE253b_DIRECTORY\lib\sqlj.jar"
	 prompt>sqlplus compiere/COMPIERE_DB_PASSWORD@COMPIERE_DB_NAME @"COMPIERE253b_DIRECTORY\utils\oracle\createSQLJ.sql"
5.	Check database via sqlplus or your favorite sql editor.

Run the DBDifference.java

1.	Create a new Eclipse project and copy the java files into the project.
2.	Give access to oracle odbc driver (odbc14.jar) - add to classpath.
3. 	In DBDifference.java main method set the name of the databases to 
	compare - for example "compiere" (your installation) and "c253b" 
	You may want to set AD_ROLE_ID and AD_CLIENT_ID used for the generation
	of *_ACCESS entries for your clients admin (no need to change if you
	have one standard client)
4.	Run as Java application and copy the output into a textfile. This will
	take some minutes! Especially the comparison of the ad_elements take some time.
	Just wait for the 'done.' message :o)

CHECK THE GENERATED SCRIPT CAREFULLY!

You have to do this by hand but assisted by your favorite sql tool. The DBDifference.java
creates most sql statements and give you some hints for your check.
Sometimes it is not clear if a changed table or column is a customization, than you have
to check this. 
If a table, column, function ... is missing in the reference db it can be a customization 
that is obviously not in the reference but it could also be deleted by compiere from
one version to another.
To avoid the customization problem you could run the script against
a fresh compiere db.

APPLY THE SCRIPT TO YOUR DATABASE - BUT MAKE A BACKUP FIRST !
Split the script into at least 3 parts and run them seperatly.
First the structural changes (new, dropped and changed tables), second the new/changed
constraints, third the new/changed AD_* entries and then the rest of the script.

THE CLASSES ARE NOT MUCH TESTED YET - BUT AS RED1 SAID TO ME:
RELEASE EARLY - UPDATE OFTEN...

I hope you like it and give some feedback. 
