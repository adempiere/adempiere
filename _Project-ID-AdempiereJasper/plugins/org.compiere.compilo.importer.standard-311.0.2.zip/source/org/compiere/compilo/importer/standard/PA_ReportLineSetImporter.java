package org.compiere.compilo.importer.standard;

/**
 * @author Carlos Ruiz
 * 
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_PA_ReportLine;
import org.compiere.model.X_PA_ReportLineSet;
import org.compiere.model.X_PA_ReportSource;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class PA_ReportLineSetImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	<PA_ReportLineSet>
		<AD_Client_Value>GardenWorld</AD_Client_Value>
		<AD_Org_Value>0</AD_Org_Value>
		<IsActive>Y</IsActive>
		<Name>Balance Sheet Detail</Name>
		<Description>Balance Sheet Detail</Description>
		<Processing>N</Processing>
		<PA_ReportLine>
			<IsActive>Y</IsActive>
			<Name>11001</Name>
			<SeqNo>40</SeqNo>
			<Description>.           Cash</Description>
			<IsPrinted>Y</IsPrinted>
			<LineType_Name>Segment Value</LineType_Name>
			<PA_ReportSource>
				<IsActive>Y</IsActive>
				<Description>Test 1</Description>
				<ElementType_Name>Account</ElementType_Name>
				<C_ElementValue_Value>11001</C_ElementValue_Value>
			</PA_ReportSource>
		</PA_ReportLine>
	</PA_ReportLineSet>
	 * 
	 * pa_reportlineset_Node represents PA_ReportLineSet XML element.
	 * 
	 * Using XMLHelper.getString("Name", pa_reportlineset_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node pa_reportlineset_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, ImportException {
		
		Document outDocument = outElement.getOwnerDocument();
		Element resultpa_reportlineset = outDocument.createElement("PA_ReportLineSet");
		
		String name = null;
		int    PA_ReportLineSet_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		name = XMLHelper.getString("Name", pa_reportlineset_Node);
		log.info("Name = [" + name +"]");
		resultpa_reportlineset.appendChild(createNewTextElement("Name", ""+name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", pa_reportlineset_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		resultpa_reportlineset.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		CreatedBy_Name = XMLHelper.getString("CreatedBy_Name", pa_reportlineset_Node);
		log.info("CreatedBy_Name = [" + CreatedBy_Name +"]");
		resultpa_reportlineset.appendChild(createNewTextElement("CreatedBy_Name", ""+CreatedBy_Name, outDocument));
		
		log.info("_______________________________________________");
		
		// Search for PA_ReportLineSet by Name...
		PA_ReportLineSet_ID = XMLHelper.getIDbyName("PA_ReportLineSet", name, AD_Client_Value);
		log.info("PA_ReportLineSet_ID = " + PA_ReportLineSet_ID);
		resultpa_reportlineset.appendChild(createNewTextElement("PA_ReportLineSet_ID", ""+PA_ReportLineSet_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		resultpa_reportlineset.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		resultpa_reportlineset.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (name == null || "".equals(name) ||
			AD_Client_Value == null || "".equals(AD_Client_Value)) 
		{
			log.error("ERROR: Name or AD_Client_Value is null...");
			System.out.println("ERROR: Name or AD_Client_Value is null...");
			throw new ImportException("ERROR: Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		resultpa_reportlineset.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    X_PA_ReportLineSet pa_reportlineset = new X_PA_ReportLineSet(Env.getCtx(), PA_ReportLineSet_ID, null);

	    pa_reportlineset.setName(name);
	    
	    // from here the getString's and set's // generated

        String IsActive = XMLHelper.getString("IsActive", pa_reportlineset_Node);
        log.info("IsActive = " + IsActive);
        resultpa_reportlineset.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
        if (IsActive != null && !"".equals(IsActive)) {
                pa_reportlineset.setIsActive(IsActive.equals("Y") ? true : false);
        }


        String Description = XMLHelper.getString("Description", pa_reportlineset_Node);
        log.info("Description = " + Description);
        resultpa_reportlineset.appendChild(createNewTextElement("Description", ""+Description, outDocument));
        if (Description != null && !"".equals(Description)) {
                pa_reportlineset.setDescription(Description);
        }


        String Processing = XMLHelper.getString("Processing", pa_reportlineset_Node);
        log.info("Processing = " + Processing);
        resultpa_reportlineset.appendChild(createNewTextElement("Processing", ""+Processing, outDocument));
        if (Processing != null && !"".equals(Processing)) {
                pa_reportlineset.setProcessing(Processing.equals("Y") ? true : false);
        }


		// end of getString's and set's
		
		pa_reportlineset.save();
		
		NodeList pa_reportline_NodeList = XMLHelper.getNodeList("PA_ReportLine", pa_reportlineset_Node);
		for (int indx = 0; indx < pa_reportline_NodeList.getLength(); indx ++) {
			Node pa_reportline_Node = pa_reportline_NodeList.item(indx);
			
			Element resultpa_reportline = outDocument.createElement("PA_ReportLine");
			//process_AD_Role_OrgAccess(currentNode, resultRootElement);
			// Import pa_reportline
			X_PA_ReportLine pa_reportline = null;
			
			String pa_reportline_Name = XMLHelper.getString("Name", pa_reportline_Node);
			log.info("Name = " + pa_reportline_Name);
			resultpa_reportline.appendChild(createNewTextElement("Name", ""+pa_reportline_Name, outDocument));
			if (pa_reportline_Name != null && !"".equals(pa_reportline_Name)) {
					// Search for printFormatItem with such Name ...
					// It is not good to call non standard methods!!!
					name = XMLHelper.getString("Name", pa_reportline_Node);
					log.info("Name = [" + name +"]");
					resultpa_reportline.appendChild(createNewTextElement("Name", ""+name, outDocument));
					
					//printFormatItem = X_PA_ReportLine.getByPA_ReportLineSet_IDandAD_Process_Para_ID(Env.getCtx(), PA_ReportLineSet_ID, AD_Process_Para_ID, null);
					pa_reportline = getByPA_ReportLineSet_IDandName(Env.getCtx(), PA_ReportLineSet_ID, pa_reportline_Name, null);
					if (pa_reportline != null) {
						// Found existing one!!!
						
					} else {
						// Create new one
						pa_reportline = new X_PA_ReportLine(Env.getCtx(), 0, null);
						pa_reportline.setPA_ReportLineSet_ID(pa_reportlineset.getPA_ReportLineSet_ID());
						pa_reportline.setName(pa_reportline_Name);
					}
					
					// start get's and set's

	                String linIsActive = XMLHelper.getString("IsActive", pa_reportline_Node);
	                log.info("IsActive = " + linIsActive);
	                resultpa_reportline.appendChild(createNewTextElement("IsActive", ""+linIsActive, outDocument));
	                if (linIsActive != null && !"".equals(linIsActive)) {
	                        pa_reportline.setIsActive(linIsActive.equals("Y") ? true : false);
	                }


	                String SeqNo = XMLHelper.getString("SeqNo", pa_reportline_Node);
	                log.info("SeqNo = " + SeqNo);
	                resultpa_reportline.appendChild(createNewTextElement("SeqNo", ""+SeqNo, outDocument));
	                if (SeqNo != null && !"".equals(SeqNo) && !"null".equals(SeqNo)) {
	                    Integer inSeqNo = new Integer(SeqNo);
	                    pa_reportline.setSeqNo(inSeqNo.intValue());
	                }


	                String linDescription = XMLHelper.getString("Description", pa_reportline_Node);
	                log.info("Description = " + linDescription);
	                resultpa_reportline.appendChild(createNewTextElement("Description", ""+linDescription, outDocument));
	                if (linDescription != null && !"".equals(linDescription)) {
	                        pa_reportline.setDescription(linDescription);
	                }


	                String IsPrinted = XMLHelper.getString("IsPrinted", pa_reportline_Node);
	                log.info("IsPrinted = " + IsPrinted);
	                resultpa_reportline.appendChild(createNewTextElement("IsPrinted", ""+IsPrinted, outDocument));
	                if (IsPrinted != null && !"".equals(IsPrinted)) {
	                        pa_reportline.setIsPrinted(IsPrinted.equals("Y") ? true : false);
	                }


	                String LineType_Name = XMLHelper.getString("LineType_Name", pa_reportline_Node);
	                log.info("LineType_Name = " + LineType_Name);
	                resultpa_reportline.appendChild(createNewTextElement("LineType_Name", ""+LineType_Name, outDocument));
	                String LineType = XMLHelper.reverseReference("PA_Report LineType", LineType_Name);
	                if (LineType_Name != null && !"".equals(LineType_Name)
	                                && LineType != null && !"".equals(LineType)) {
	                        pa_reportline.setLineType(LineType);
	                }


	                String CalculationType_Name = XMLHelper.getString("CalculationType_Name", pa_reportline_Node);
	                log.info("CalculationType_Name = " + CalculationType_Name);
	                resultpa_reportline.appendChild(createNewTextElement("CalculationType_Name", ""+CalculationType_Name, outDocument));
	                String CalculationType = XMLHelper.reverseReference("PA_Report CalculationType", CalculationType_Name);
	                if (CalculationType_Name != null && !"".equals(CalculationType_Name)
	                                && CalculationType != null && !"".equals(CalculationType)) {
	                        pa_reportline.setCalculationType(CalculationType);
	                }


	                String Oper_1_Name = XMLHelper.getString("Oper_1_Name", pa_reportline_Node);
	                log.info("Oper_1_Name = " + Oper_1_Name);
	                resultpa_reportline.appendChild(createNewTextElement("Oper_1_Name", ""+Oper_1_Name, outDocument));
	                int Oper_1_ID = XMLHelper.getIDWithMasterAndColumn("PA_ReportLine", "Name", Oper_1_Name, "PA_ReportLineSet", PA_ReportLineSet_ID);
	                if (Oper_1_Name != null && !"".equals(Oper_1_Name)
	                                && 0 != Oper_1_ID ) {
	                        pa_reportline.setOper_1_ID(Oper_1_ID);
	                }


	                String Oper_2_Name = XMLHelper.getString("Oper_2_Name", pa_reportline_Node);
	                log.info("Oper_2_Name = " + Oper_2_Name);
	                resultpa_reportline.appendChild(createNewTextElement("Oper_2_Name", ""+Oper_2_Name, outDocument));
	                int Oper_2_ID = XMLHelper.getIDWithMasterAndColumn("PA_ReportLine", "Name", Oper_2_Name, "PA_ReportLineSet", PA_ReportLineSet_ID); 
	                if (Oper_2_Name != null && !"".equals(Oper_2_Name)
	                                && 0 != Oper_2_ID ) {
	                        pa_reportline.setOper_2_ID(Oper_2_ID);
	                }


	                String PostingType_Name = XMLHelper.getString("PostingType_Name", pa_reportline_Node);
	                log.info("PostingType_Name = " + PostingType_Name);
	                resultpa_reportline.appendChild(createNewTextElement("PostingType_Name", ""+PostingType_Name, outDocument));
	                String PostingType = XMLHelper.reverseReference("_Posting Type", PostingType_Name);
	                if (PostingType_Name != null && !"".equals(PostingType_Name)
	                                && PostingType != null && !"".equals(PostingType)) {
	                        pa_reportline.setPostingType(PostingType);
	                }


	                String GL_Budget_Name = XMLHelper.getString("GL_Budget_Name", pa_reportline_Node);
	                log.info("GL_Budget_Name = " + GL_Budget_Name);
	                resultpa_reportline.appendChild(createNewTextElement("GL_Budget_Name", ""+GL_Budget_Name, outDocument));
	                int GL_Budget_ID = XMLHelper.getIDWithColumn("GL_Budget", "Name", GL_Budget_Name, AD_Client_ID); 
	                if (GL_Budget_Name != null && !"".equals(GL_Budget_Name)
	                                && 0 != GL_Budget_ID ) {
	                        pa_reportline.setGL_Budget_ID(GL_Budget_ID);
	                }


	                String AmountType_Name = XMLHelper.getString("AmountType_Name", pa_reportline_Node);
	                log.info("AmountType_Name = " + AmountType_Name);
	                resultpa_reportline.appendChild(createNewTextElement("AmountType_Name", ""+AmountType_Name, outDocument));
	                String AmountType = XMLHelper.reverseReference("PA_Report AmountType", AmountType_Name);
	                if (AmountType_Name != null && !"".equals(AmountType_Name)
	                                && AmountType != null && !"".equals(AmountType)) {
	                        pa_reportline.setAmountType(AmountType);
	                }


					// end get's and set's

	                pa_reportline.save();
					int PA_ReportLine_ID = pa_reportline.getPA_ReportLine_ID();
					
	        		NodeList pa_reportsource_NodeList = XMLHelper.getNodeList("PA_ReportSource", pa_reportline_Node);

	        		for (int indx2 = 0; indx2 < pa_reportsource_NodeList.getLength(); indx2 ++) {
	        			Node pa_reportsource_Node = pa_reportsource_NodeList.item(indx2);
	        			
	        			Element resultpa_reportsource = outDocument.createElement("PA_ReportSource");
	        			//process_AD_Role_OrgAccess(currentNode, resultRootElement);
	        			// Import pa_reportsource
	        			X_PA_ReportSource pa_reportsource = null;
	        			
	        			// TODO: Currently only importing reportsource that has description (unique)
	        			
	        			String pa_reportsource_Description = XMLHelper.getString("Description", pa_reportsource_Node);
	        			log.info("Description = " + pa_reportsource_Description);
	        			resultpa_reportsource.appendChild(createNewTextElement("Description", ""+pa_reportsource_Description, outDocument));
	        			if (pa_reportsource_Description != null && !"".equals(pa_reportsource_Description)) {
	        					// Search for printFormatItem with such Name ...
	        					// It is not good to call non standard methods!!!
	    	        			String description = null;
	        					description = XMLHelper.getString("Description", pa_reportsource_Node);
	        					log.info("Description = [" + description +"]");
	        					resultpa_reportsource.appendChild(createNewTextElement("Description", ""+description, outDocument));
	        					
	        					//printFormatItem = X_PA_ReportSource.getByPA_ReportLine_IDandAD_Process_Para_ID(Env.getCtx(), PA_ReportLine_ID, AD_Process_Para_ID, null);
	        					// TODO: PA_ReportSource doesn't have Name, search by description, but it could be problematic because can be null, and is not ensured to be unique
	        					pa_reportsource = getByPA_ReportLine_IDandDescription(Env.getCtx(), PA_ReportLine_ID, pa_reportsource_Description, null);
	        					if (pa_reportsource != null) {
	        						// Found existing one!!!
	        						
	        					} else {
	        						// Create new one
	        						pa_reportsource = new X_PA_ReportSource(Env.getCtx(), 0, null);
	        						pa_reportsource.setPA_ReportLine_ID(pa_reportline.getPA_ReportLine_ID());
	        						pa_reportsource.setDescription(pa_reportsource_Description);
	        					}
	        					
	        					// start get's and set's

	        	                String srcIsActive = XMLHelper.getString("IsActive", pa_reportsource_Node);
	        	                log.info("IsActive = " + srcIsActive);
	        	                resultpa_reportsource.appendChild(createNewTextElement("IsActive", ""+srcIsActive, outDocument));
	        	                if (srcIsActive != null && !"".equals(srcIsActive)) {
	        	                        pa_reportsource.setIsActive(srcIsActive.equals("Y") ? true : false);
	        	                }


	        	                String ElementType_Name = XMLHelper.getString("ElementType_Name", pa_reportsource_Node);
	        	                log.info("ElementType_Name = " + ElementType_Name);
	        	                resultpa_reportsource.appendChild(createNewTextElement("ElementType_Name", ""+ElementType_Name, outDocument));
	        	                String ElementType = XMLHelper.reverseReference("C_AcctSchema ElementType", ElementType_Name);
	        	                if (ElementType_Name != null && !"".equals(ElementType_Name)
	        	                                && ElementType != null && !"".equals(ElementType)) {
	        	                        pa_reportsource.setElementType(ElementType);
	        	                }


	        	                String Org_Value = XMLHelper.getString("Org_Value", pa_reportsource_Node);
	        	                log.info("Org_Value = " + Org_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("Org_Value", ""+Org_Value, outDocument));
	        	                int Org_ID = XMLHelper.getIDWithColumn("AD_Org", "Value", Org_Value, AD_Client_ID); 
	        	                if (Org_Value != null && !"".equals(Org_Value)
	        	                                && 0 != Org_ID ) {
	        	                        pa_reportsource.setOrg_ID(Org_ID);
	        	                }


	        	                String C_ElementValue_Value = XMLHelper.getString("C_ElementValue_Value", pa_reportsource_Node);
	        	                log.info("C_ElementValue_Value = " + C_ElementValue_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_ElementValue_Value", ""+C_ElementValue_Value, outDocument));
	        	                int C_ElementValue_ID = XMLHelper.getIDWithColumn("C_ElementValue", "Value", C_ElementValue_Value, AD_Client_ID); 
	        	                if (C_ElementValue_Value != null && !"".equals(C_ElementValue_Value)
	        	                                && 0 != C_ElementValue_ID ) {
	        	                        pa_reportsource.setC_ElementValue_ID(C_ElementValue_ID);
	        	                }


	        	                String C_Project_Value = XMLHelper.getString("C_Project_Value", pa_reportsource_Node);
	        	                log.info("C_Project_Value = " + C_Project_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_Project_Value", ""+C_Project_Value, outDocument));
	        	                int C_Project_ID = XMLHelper.getIDWithColumn("C_Project", "Value", C_Project_Value, AD_Client_ID); 
	        	                if (C_Project_Value != null && !"".equals(C_Project_Value)
	        	                                && 0 != C_Project_ID ) {
	        	                        pa_reportsource.setC_Project_ID(C_Project_ID);
	        	                }


	        	                String C_BPartner_Value = XMLHelper.getString("C_BPartner_Value", pa_reportsource_Node);
	        	                log.info("C_BPartner_Value = " + C_BPartner_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_BPartner_Value", ""+C_BPartner_Value, outDocument));
	        	                int C_BPartner_ID = XMLHelper.getIDWithColumn("C_BPartner", "Value", C_BPartner_Value, AD_Client_ID); 
	        	                if (C_BPartner_Value != null && !"".equals(C_BPartner_Value)
	        	                                && 0 != C_BPartner_ID ) {
	        	                        pa_reportsource.setC_BPartner_ID(C_BPartner_ID);
	        	                }


	        	                String M_Product_Value = XMLHelper.getString("M_Product_Value", pa_reportsource_Node);
	        	                log.info("M_Product_Value = " + M_Product_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("M_Product_Value", ""+M_Product_Value, outDocument));
	        	                int M_Product_ID = XMLHelper.getIDWithColumn("M_Product", "Value", M_Product_Value, AD_Client_ID); 
	        	                if (M_Product_Value != null && !"".equals(M_Product_Value)
	        	                                && 0 != M_Product_ID ) {
	        	                        pa_reportsource.setM_Product_ID(M_Product_ID);
	        	                }


	        	                String C_Campaign_Value = XMLHelper.getString("C_Campaign_Value", pa_reportsource_Node);
	        	                log.info("C_Campaign_Value = " + C_Campaign_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_Campaign_Value", ""+C_Campaign_Value, outDocument));
	        	                int C_Campaign_ID = XMLHelper.getIDWithColumn("C_Campaign", "Value", C_Campaign_Value, AD_Client_ID); 
	        	                if (C_Campaign_Value != null && !"".equals(C_Campaign_Value)
	        	                                && 0 != C_Campaign_ID ) {
	        	                        pa_reportsource.setC_Campaign_ID(C_Campaign_ID);
	        	                }


	        	                /* TODO: Implement C_Location_ID (doesn't have unique id different from ID) 
	        	                String C_Location_ID = XMLHelper.getString("C_Location_ID", pa_reportsource_Node);
	        	                log.info("C_Location_ID = " + C_Location_ID);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_Location_ID", ""+C_Location_ID, outDocument));
	        	                if (C_Location_ID != null && !"".equals(C_Location_ID)) {
	        	                        pa_reportsource.setC_Location_ID(C_Location_ID);
	        	                }
	        	                */


	        	                String C_SalesRegion_Value = XMLHelper.getString("C_SalesRegion_Value", pa_reportsource_Node);
	        	                log.info("C_SalesRegion_Value = " + C_SalesRegion_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_SalesRegion_Value", ""+C_SalesRegion_Value, outDocument));
	        	                int C_SalesRegion_ID = XMLHelper.getIDWithColumn("C_SalesRegion", "Value", C_SalesRegion_Value, AD_Client_ID); 
	        	                if (C_SalesRegion_Value != null && !"".equals(C_SalesRegion_Value)
	        	                                && 0 != C_SalesRegion_ID ) {
	        	                        pa_reportsource.setC_SalesRegion_ID(C_SalesRegion_ID);
	        	                }


	        	                String C_Activity_Value = XMLHelper.getString("C_Activity_Value", pa_reportsource_Node);
	        	                log.info("C_Activity_Value = " + C_Activity_Value);
	        	                resultpa_reportsource.appendChild(createNewTextElement("C_Activity_Value", ""+C_Activity_Value, outDocument));
	        	                int C_Activity_ID = XMLHelper.getIDWithColumn("C_Activity", "Value", C_Activity_Value, AD_Client_ID); 
	        	                if (C_Activity_Value != null && !"".equals(C_Activity_Value)
	        	                                && 0 != C_Activity_ID ) {
	        	                        pa_reportsource.setC_Activity_ID(C_Activity_ID);
	        	                }



	        					// end get's and set's
	        					
	        					boolean resultSave = true;
	        					resultSave = pa_reportsource.save();
	        					
	        					
	        					
	        					log.info("--- RESULT SAVE[PA_ReportSource] = " + resultSave);
	        					resultpa_reportsource.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
	        					resultpa_reportline.appendChild(resultpa_reportsource);

	        			}
	        			
	        		}
	        		

					boolean resultSave = true;
					resultSave = pa_reportline.save();
					
					log.info("--- RESULT SAVE[PA_ReportLine] = " + resultSave);
					resultpa_reportline.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
					resultpa_reportlineset.appendChild(resultpa_reportline);

			}
			
		}
		
		boolean resultSave = true;
		resultSave = pa_reportlineset.save();
		log.info("--- RESULT SAVE = " + resultSave);
		resultpa_reportlineset.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(resultpa_reportlineset);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
	public static X_PA_ReportLine getByPA_ReportLineSet_IDandName (Properties ctx, int PA_ReportLineSet_ID, String Name, String trxName)
	{
		X_PA_ReportLine result = null;
		
		String sql = "SELECT * "
				   + "FROM " + X_PA_ReportLine.Table_Name + " "
				   + "WHERE "
				   + "     PA_ReportLineSet_ID=? "    // #1
				   + " AND Name=? " // #2
				   //+ " AND IsActive='Y' "
	    ;
		PreparedStatement pstmt = null;
		try
		{
			pstmt = DB.prepareStatement (sql, trxName);
			pstmt.setInt(1, PA_ReportLineSet_ID);
			pstmt.setString(2, Name);
			
			ResultSet rs = pstmt.executeQuery ();
			if (rs.next ())
				result = new X_PA_ReportLine (ctx, rs, trxName);
			
			rs.close ();
			pstmt.close ();
			pstmt = null;
		}
		catch (Exception e)
		{
			System.out.println(e);
		} finally {
			if (pstmt != null)
				try { pstmt.close (); } catch (Exception ex) { pstmt = null;}
		}
				
		return result;
	}

	public static X_PA_ReportSource getByPA_ReportLine_IDandDescription (Properties ctx, int PA_ReportLine_ID, String Description, String trxName)
	{
		X_PA_ReportSource result = null;
		
		String sql = "SELECT * "
				   + "FROM " + X_PA_ReportSource.Table_Name + " "
				   + "WHERE "
				   + "     PA_ReportLine_ID=? "    // #1
				   + " AND Description=? " // #2
				   //+ " AND IsActive='Y' "
	    ;
		PreparedStatement pstmt = null;
		try
		{
			pstmt = DB.prepareStatement (sql, trxName);
			pstmt.setInt(1, PA_ReportLine_ID);
			pstmt.setString(2, Description);
			
			ResultSet rs = pstmt.executeQuery ();
			if (rs.next ())
				result = new X_PA_ReportSource (ctx, rs, trxName);
			
			rs.close ();
			pstmt.close ();
			pstmt = null;
		}
		catch (Exception e)
		{
			System.out.println(e);
		} finally {
			if (pstmt != null)
				try { pstmt.close (); } catch (Exception ex) { pstmt = null;}
		}
				
		return result;
	}

}