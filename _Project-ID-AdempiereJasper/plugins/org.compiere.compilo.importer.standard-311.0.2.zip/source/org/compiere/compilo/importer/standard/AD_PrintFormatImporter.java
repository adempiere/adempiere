package org.compiere.compilo.importer.standard;

/**
 * @author Carlos Ruiz
 * 
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_AD_PrintFormat;
import org.compiere.model.X_AD_PrintFormatItem;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class AD_PrintFormatImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	<AD_PrintFormat>
		<AD_Client_Value>GardenWorld</AD_Client_Value>
		<AD_Org_Value>HQ</AD_Org_Value>
		<IsActive>Y</IsActive>
		<Name>Invoice LineTax FCS</Name>
		<Description>Invoice Line&amp;Tax Lines for FCS</Description>
		<IsTableBased>N</IsTableBased>
		<IsForm>N</IsForm>
		<AD_Table_Name>C_Invoice_LineTax_v</AD_Table_Name>
		<AD_PrintPaper_Name>Letter Portrait</AD_PrintPaper_Name>
		<AD_PrintColor_Name>Black</AD_PrintColor_Name>
		<AD_PrintFont_Name>SansSerif 11</AD_PrintFont_Name>
		<IsStandardHeaderFooter>Y</IsStandardHeaderFooter>
		<HeaderMargin>0</HeaderMargin>
		<FooterMargin>0</FooterMargin>
		<CreateCopy>N</CreateCopy>
		<AD_PrintTableFormat_Name>Standard Document</AD_PrintTableFormat_Name>
		<IsDefault>N</IsDefault>
		<AD_PrintFormatItem>
			<IsActive>Y</IsActive>
			<AD_PrintFormat_Name>Invoice LineTax</AD_PrintFormat_Name>
			<Name>Tax</Name>
			<PrintName>Tax</PrintName>
			<IsPrinted>N</IsPrinted>
			<PrintAreaType_Name>Content</PrintAreaType_Name>
			<SeqNo>0</SeqNo>
			<PrintFormatType_Name>Field</PrintFormatType_Name>
			<AD_Column_ColumnName>Tax</AD_Column_ColumnName>
			<IsRelativePosition>Y</IsRelativePosition>
			<IsNextLine>N</IsNextLine>
			<XSpace>0</XSpace>
			<YSpace>0</YSpace>
			<XPosition>0</XPosition>
			<YPosition>0</YPosition>
			<MaxWidth>0</MaxWidth>
			<IsHeightOneLine>N</IsHeightOneLine>
			<MaxHeight>0</MaxHeight>
			<FieldAlignmentType_Name>Leading (left)</FieldAlignmentType_Name>
			<LineAlignmentType_Name>None</LineAlignmentType_Name>
			<IsOrderBy>N</IsOrderBy>
			<SortNo>0</SortNo>
			<IsGroupBy>N</IsGroupBy>
			<IsPageBreak>N</IsPageBreak>
			<IsSummarized>N</IsSummarized>
			<ImageIsAttached>N</ImageIsAttached>
			<IsAveraged>N</IsAveraged>
			<IsCounted>N</IsCounted>
			<IsSetNLPosition>N</IsSetNLPosition>
			<IsSuppressNull>N</IsSuppressNull>
			<BelowColumn>null</BelowColumn>
			<IsFixedWidth>N</IsFixedWidth>
			<IsNextPage>N</IsNextPage>
			<IsMinCalc>N</IsMinCalc>
			<IsMaxCalc>N</IsMaxCalc>
			<IsRunningTotal>N</IsRunningTotal>
			<RunningTotalLines>null</RunningTotalLines>
			<IsVarianceCalc>N</IsVarianceCalc>
			<IsDeviationCalc>N</IsDeviationCalc>
			<IsFilledRectangle>N</IsFilledRectangle>
			<LineWidth>null</LineWidth>
			<ArcDiameter>null</ArcDiameter>
			<IsCentrallyMaintained>Y</IsCentrallyMaintained>
			<IsImageField>N</IsImageField>
		</AD_PrintFormatItem>
	</AD_PrintFormat>
	 * 
	 * AD_PrintFormat_Node represents AD_PrintFormat XML element.
	 * 
	 * Using XMLHelper.getString("Name", AD_PrintFormat_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node ad_printformat_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, ImportException {
		
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_PrintFormat");
		
		String name = null;
		int    AD_PrintFormat_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		name = XMLHelper.getString("Name", ad_printformat_Node);
		log.info("Name = [" + name +"]");
		result.appendChild(createNewTextElement("Name", ""+name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", ad_printformat_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		CreatedBy_Name = XMLHelper.getString("CreatedBy_Name", ad_printformat_Node);
		log.info("CreatedBy_Name = [" + CreatedBy_Name +"]");
		result.appendChild(createNewTextElement("CreatedBy_Name", ""+CreatedBy_Name, outDocument));
		
		log.info("_______________________________________________");
		
		// Search for AD_PrintFormat by Name...
		AD_PrintFormat_ID = XMLHelper.getIDbyName("AD_PrintFormat", name, AD_Client_Value);
		log.info("AD_PrintFormat_ID = " + AD_PrintFormat_ID);
		result.appendChild(createNewTextElement("AD_PrintFormat_ID", ""+AD_PrintFormat_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (name == null || "".equals(name) ||
			AD_Client_Value == null || "".equals(AD_Client_Value)) 
		{
			log.error("ERROR: Name or AD_Client_Value is null...");
			System.out.println("ERROR: Name or AD_Client_Value is null...");
			throw new ImportException("ERROR: Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    X_AD_PrintFormat ad_printformat = new X_AD_PrintFormat(Env.getCtx(), AD_PrintFormat_ID, null);

	    ad_printformat.setName(name);
	    
	    // from here the getString's and set's // generated

        String IsActive = XMLHelper.getString("IsActive", ad_printformat_Node);
        log.info("IsActive = " + IsActive);
        result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
        if (IsActive != null && !"".equals(IsActive)) {
                ad_printformat.setIsActive(IsActive.equals("Y") ? true : false);
        }


        String Description = XMLHelper.getString("Description", ad_printformat_Node);
        log.info("Description = " + Description);
        result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
        if (Description != null && !"".equals(Description)) {
                ad_printformat.setDescription(Description);
        }


        String IsTableBased = XMLHelper.getString("IsTableBased", ad_printformat_Node);
        log.info("IsTableBased = " + IsTableBased);
        result.appendChild(createNewTextElement("IsTableBased", ""+IsTableBased, outDocument));
        if (IsTableBased != null && !"".equals(IsTableBased)) {
                ad_printformat.setIsTableBased(IsTableBased.equals("Y") ? true : false);
        }


        String IsForm = XMLHelper.getString("IsForm", ad_printformat_Node);
        log.info("IsForm = " + IsForm);
        result.appendChild(createNewTextElement("IsForm", ""+IsForm, outDocument));
        if (IsForm != null && !"".equals(IsForm)) {
                ad_printformat.setIsForm(IsForm.equals("Y") ? true : false);
        }


        String AD_Table_Name = XMLHelper.getString("AD_Table_Name", ad_printformat_Node);
        log.info("AD_Table_Name = " + AD_Table_Name);
        result.appendChild(createNewTextElement("AD_Table_Name", ""+AD_Table_Name, outDocument));
        int AD_Table_ID = XMLHelper.getIDWithColumn("AD_Table", "Name", AD_Table_Name, AD_Client_ID); 
        if (AD_Table_Name != null && !"".equals(AD_Table_Name)
                        && 0 != AD_Table_ID ) {
                ad_printformat.setAD_Table_ID(AD_Table_ID);
        }


        String AD_PrintPaper_Name = XMLHelper.getString("AD_PrintPaper_Name", ad_printformat_Node);
        log.info("AD_PrintPaper_Name = " + AD_PrintPaper_Name);
        result.appendChild(createNewTextElement("AD_PrintPaper_Name", ""+AD_PrintPaper_Name, outDocument));
        int AD_PrintPaper_ID = XMLHelper.getIDWithColumn("AD_PrintPaper", "Name", AD_PrintPaper_Name, AD_Client_ID); 
        if (AD_PrintPaper_Name != null && !"".equals(AD_PrintPaper_Name)
                        && 0 != AD_PrintPaper_ID ) {
                ad_printformat.setAD_PrintPaper_ID(AD_PrintPaper_ID);
        }


        String AD_PrintColor_Name = XMLHelper.getString("AD_PrintColor_Name", ad_printformat_Node);
        log.info("AD_PrintColor_Name = " + AD_PrintColor_Name);
        result.appendChild(createNewTextElement("AD_PrintColor_Name", ""+AD_PrintColor_Name, outDocument));
        int AD_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", AD_PrintColor_Name, AD_Client_ID); 
        if (AD_PrintColor_Name != null && !"".equals(AD_PrintColor_Name)
                        && 0 != AD_PrintColor_ID ) {
                ad_printformat.setAD_PrintColor_ID(AD_PrintColor_ID);
        }


        String AD_PrintFont_Name = XMLHelper.getString("AD_PrintFont_Name", ad_printformat_Node);
        log.info("AD_PrintFont_Name = " + AD_PrintFont_Name);
        result.appendChild(createNewTextElement("AD_PrintFont_Name", ""+AD_PrintFont_Name, outDocument));
        int AD_PrintFont_ID = XMLHelper.getIDWithColumn("AD_PrintFont", "Name", AD_PrintFont_Name, AD_Client_ID); 
        if (AD_PrintFont_Name != null && !"".equals(AD_PrintFont_Name)
                        && 0 != AD_PrintFont_ID ) {
                ad_printformat.setAD_PrintFont_ID(AD_PrintFont_ID);
        }


        String IsStandardHeaderFooter = XMLHelper.getString("IsStandardHeaderFooter", ad_printformat_Node);
        log.info("IsStandardHeaderFooter = " + IsStandardHeaderFooter);
        result.appendChild(createNewTextElement("IsStandardHeaderFooter", ""+IsStandardHeaderFooter, outDocument));
        if (IsStandardHeaderFooter != null && !"".equals(IsStandardHeaderFooter)) {
                ad_printformat.setIsStandardHeaderFooter(IsStandardHeaderFooter.equals("Y") ? true : false);
        }


        String HeaderMargin = XMLHelper.getString("HeaderMargin", ad_printformat_Node);
        log.info("HeaderMargin = " + HeaderMargin);
        result.appendChild(createNewTextElement("HeaderMargin", ""+HeaderMargin, outDocument));
        if (HeaderMargin != null && !"".equals(HeaderMargin) && !"null".equals(HeaderMargin)) {
            Integer inHeaderMargin = new Integer(HeaderMargin);
            ad_printformat.setHeaderMargin(inHeaderMargin.intValue());
        }


        String FooterMargin = XMLHelper.getString("FooterMargin", ad_printformat_Node);
        log.info("FooterMargin = " + FooterMargin);
        result.appendChild(createNewTextElement("FooterMargin", ""+FooterMargin, outDocument));
        if (FooterMargin != null && !"".equals(FooterMargin) && !"null".equals(FooterMargin)) {
            Integer inFooterMargin = new Integer(FooterMargin);
            ad_printformat.setFooterMargin(inFooterMargin.intValue());
        }


        String CreateCopy = XMLHelper.getString("CreateCopy", ad_printformat_Node);
        log.info("CreateCopy = " + CreateCopy);
        result.appendChild(createNewTextElement("CreateCopy", ""+CreateCopy, outDocument));
        if (CreateCopy != null && !"".equals(CreateCopy)) {
                ad_printformat.setCreateCopy(CreateCopy);
        }


        String AD_ReportView_Name = XMLHelper.getString("AD_ReportView_Name", ad_printformat_Node);
        log.info("AD_ReportView_Name = " + AD_ReportView_Name);
        result.appendChild(createNewTextElement("AD_ReportView_Name", ""+AD_ReportView_Name, outDocument));
        int AD_ReportView_ID = XMLHelper.getIDWithColumn("AD_ReportView", "Name", AD_ReportView_Name, AD_Client_ID); 
        if (AD_ReportView_Name != null && !"".equals(AD_ReportView_Name)
                        && 0 != AD_ReportView_ID ) {
                ad_printformat.setAD_ReportView_ID(AD_ReportView_ID);
        }


        String AD_PrintTableFormat_Name = XMLHelper.getString("AD_PrintTableFormat_Name", ad_printformat_Node);
        log.info("AD_PrintTableFormat_Name = " + AD_PrintTableFormat_Name);
        result.appendChild(createNewTextElement("AD_PrintTableFormat_Name", ""+AD_PrintTableFormat_Name, outDocument));
        int AD_PrintTableFormat_ID = XMLHelper.getIDWithColumn("AD_PrintTableFormat", "Name", AD_PrintTableFormat_Name, AD_Client_ID); 
        if (AD_PrintTableFormat_Name != null && !"".equals(AD_PrintTableFormat_Name)
                        && 0 != AD_PrintTableFormat_ID ) {
                ad_printformat.setAD_PrintTableFormat_ID(AD_PrintTableFormat_ID);
        }


        String PrinterName = XMLHelper.getString("PrinterName", ad_printformat_Node);
        log.info("PrinterName = " + PrinterName);
        result.appendChild(createNewTextElement("PrinterName", ""+PrinterName, outDocument));
        if (PrinterName != null && !"".equals(PrinterName)) {
                ad_printformat.setPrinterName(PrinterName);
        }


        String IsDefault = XMLHelper.getString("IsDefault", ad_printformat_Node);
        log.info("IsDefault = " + IsDefault);
        result.appendChild(createNewTextElement("IsDefault", ""+IsDefault, outDocument));
        if (IsDefault != null && !"".equals(IsDefault)) {
                ad_printformat.setIsDefault(IsDefault.equals("Y") ? true : false);
        }



		// end of getString's and set's
		
		// TODO - we need to call printFormat.save() else when printFormat is new it throws exception when tries to get AD_PrintFormat_ID
		ad_printformat.save();
		
		NodeList ad_printformatitem_NodeList = XMLHelper.getNodeList("AD_PrintFormatItem", ad_printformat_Node);
		for (int indx = 0; indx < ad_printformatitem_NodeList.getLength(); indx ++) {
			Node ad_printformatitem_Node = ad_printformatitem_NodeList.item(indx);
			
			Element resultprintFormatItem = outDocument.createElement("AD_PrintFormatItem");
			//process_AD_Role_OrgAccess(currentNode, resultRootElement);
			// Import AD_PrintFormatItem
			X_AD_PrintFormatItem ad_printformatitem = null;
			
			String AD_PrintFormatItem_Name = XMLHelper.getString("Name", ad_printformatitem_Node);
			log.info("AD_PrintFormatItem_Name = " + AD_PrintFormatItem_Name);
			resultprintFormatItem.appendChild(createNewTextElement("AD_PrintFormatItem_Name", ""+AD_PrintFormatItem_Name, outDocument));
			if (AD_PrintFormatItem_Name != null && !"".equals(AD_PrintFormatItem_Name)) {
					// Search for printFormatItem with such Name ...
					// It is not good to call non standard methods!!!
					name = XMLHelper.getString("Name", ad_printformatitem_Node);
					log.info("Name = [" + name +"]");
					resultprintFormatItem.appendChild(createNewTextElement("Name", ""+name, outDocument));
					
					//printFormatItem = X_AD_PrintFormatItem.getByAD_PrintFormat_IDandAD_Process_Para_ID(Env.getCtx(), AD_PrintFormat_ID, AD_Process_Para_ID, null);
					ad_printformatitem = getByAD_PrintFormat_IDandName(Env.getCtx(), AD_PrintFormat_ID, AD_PrintFormatItem_Name, null);
					if (ad_printformatitem != null) {
						// Found existing one!!!
						
					} else {
						// Create new one
						ad_printformatitem = new X_AD_PrintFormatItem(Env.getCtx(), 0, null);
						ad_printformatitem.setAD_PrintFormat_ID(ad_printformat.getAD_PrintFormat_ID());
						ad_printformatitem.setName(AD_PrintFormatItem_Name);
					}
					
					// start get's and set's

	                String iIsActive = XMLHelper.getString("IsActive", ad_printformatitem_Node);
	                log.info("IsActive = " + iIsActive);
	                resultprintFormatItem.appendChild(createNewTextElement("IsActive", ""+iIsActive, outDocument));
	                if (iIsActive != null && !"".equals(iIsActive)) {
	                        ad_printformatitem.setIsActive(iIsActive.equals("Y") ? true : false);
	                }


	                String PrintName = XMLHelper.getString("PrintName", ad_printformatitem_Node);
	                log.info("PrintName = " + PrintName);
	                resultprintFormatItem.appendChild(createNewTextElement("PrintName", ""+PrintName, outDocument));
	                if (PrintName != null && !"".equals(PrintName)) {
	                        ad_printformatitem.setPrintName(PrintName);
	                }


	                String IsPrinted = XMLHelper.getString("IsPrinted", ad_printformatitem_Node);
	                log.info("IsPrinted = " + IsPrinted);
	                resultprintFormatItem.appendChild(createNewTextElement("IsPrinted", ""+IsPrinted, outDocument));
	                if (IsPrinted != null && !"".equals(IsPrinted)) {
	                        ad_printformatitem.setIsPrinted(IsPrinted.equals("Y") ? true : false);
	                }


	                String PrintAreaType_Name = XMLHelper.getString("PrintAreaType_Name", ad_printformatitem_Node);
	                log.info("PrintAreaType_Name = " + PrintAreaType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("PrintAreaType_Name", ""+PrintAreaType_Name, outDocument));
	                String PrintAreaType = XMLHelper.reverseReference("AD_Print Area", PrintAreaType_Name);
	                if (PrintAreaType_Name != null && !"".equals(PrintAreaType_Name)
	                                && PrintAreaType != null && !"".equals(PrintAreaType)) {
	                        ad_printformatitem.setPrintAreaType(PrintAreaType);
	                }


	                String SeqNo = XMLHelper.getString("SeqNo", ad_printformatitem_Node);
	                log.info("SeqNo = " + SeqNo);
	                resultprintFormatItem.appendChild(createNewTextElement("SeqNo", ""+SeqNo, outDocument));
	                if (SeqNo != null && !"".equals(SeqNo) && !"null".equals(SeqNo)) {
	                    Integer inSeqNo = new Integer(SeqNo);
	                    ad_printformatitem.setSeqNo(inSeqNo.intValue());
	                }


	                String PrintFormatType_Name = XMLHelper.getString("PrintFormatType_Name", ad_printformatitem_Node);
	                log.info("PrintFormatType_Name = " + PrintFormatType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("PrintFormatType_Name", ""+PrintFormatType_Name, outDocument));
	                String PrintFormatType = XMLHelper.reverseReference("AD_Print Format Type", PrintFormatType_Name);
	                if (PrintFormatType_Name != null && !"".equals(PrintFormatType_Name)
	                                && PrintFormatType != null && !"".equals(PrintFormatType)) {
	                        ad_printformatitem.setPrintFormatType(PrintFormatType);
	                }


	                String AD_Column_ColumnName = XMLHelper.getString("AD_Column_ColumnName", ad_printformatitem_Node);
	                log.info("AD_Column_ColumnName = " + AD_Column_ColumnName);
	                resultprintFormatItem.appendChild(createNewTextElement("AD_Column_ColumnName", ""+AD_Column_ColumnName, outDocument));
	                int AD_Column_ID = XMLHelper.getIDWithMasterAndColumn("AD_Column", "ColumnName", AD_Column_ColumnName, "AD_Table", AD_Table_ID); 
	                if (AD_Column_ColumnName != null && !"".equals(AD_Column_ColumnName)
	                                && 0 != AD_Column_ID ) {
	                        ad_printformatitem.setAD_Column_ID(AD_Column_ID);
	                }


	                String AD_PrintFormatChild_Name = XMLHelper.getString("AD_PrintFormatChild_Name", ad_printformatitem_Node);
	                log.info("AD_PrintFormatChild_Name = " + AD_PrintFormatChild_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("AD_PrintFormatChild_Name", ""+AD_PrintFormatChild_Name, outDocument));
	                int AD_PrintFormatChild_ID = XMLHelper.getIDWithColumn("AD_PrintFormat", "Name", AD_PrintFormatChild_Name, AD_Client_ID); 
	                if (AD_PrintFormatChild_Name != null && !"".equals(AD_PrintFormatChild_Name)
	                                && 0 != AD_PrintFormatChild_ID ) {
	                        ad_printformatitem.setAD_PrintFormatChild_ID(AD_PrintFormatChild_ID);
	                }


	                String IsRelativePosition = XMLHelper.getString("IsRelativePosition", ad_printformatitem_Node);
	                log.info("IsRelativePosition = " + IsRelativePosition);
	                resultprintFormatItem.appendChild(createNewTextElement("IsRelativePosition", ""+IsRelativePosition, outDocument));
	                if (IsRelativePosition != null && !"".equals(IsRelativePosition)) {
	                        ad_printformatitem.setIsRelativePosition(IsRelativePosition.equals("Y") ? true : false);
	                }


	                String IsNextLine = XMLHelper.getString("IsNextLine", ad_printformatitem_Node);
	                log.info("IsNextLine = " + IsNextLine);
	                resultprintFormatItem.appendChild(createNewTextElement("IsNextLine", ""+IsNextLine, outDocument));
	                if (IsNextLine != null && !"".equals(IsNextLine)) {
	                        ad_printformatitem.setIsNextLine(IsNextLine.equals("Y") ? true : false);
	                }


	                String XSpace = XMLHelper.getString("XSpace", ad_printformatitem_Node);
	                log.info("XSpace = " + XSpace);
	                resultprintFormatItem.appendChild(createNewTextElement("XSpace", ""+XSpace, outDocument));
	                if (XSpace != null && !"".equals(XSpace) && !"null".equals(XSpace)) {
	                    Integer inXSpace = new Integer(XSpace);
	                    ad_printformatitem.setXSpace(inXSpace.intValue());
	                }


	                String YSpace = XMLHelper.getString("YSpace", ad_printformatitem_Node);
	                log.info("YSpace = " + YSpace);
	                resultprintFormatItem.appendChild(createNewTextElement("YSpace", ""+YSpace, outDocument));
	                if (YSpace != null && !"".equals(YSpace) && !"null".equals(YSpace)) {
	                    Integer inYSpace = new Integer(YSpace);
	                    ad_printformatitem.setYSpace(inYSpace.intValue());
	                }


	                String XPosition = XMLHelper.getString("XPosition", ad_printformatitem_Node);
	                log.info("XPosition = " + XPosition);
	                resultprintFormatItem.appendChild(createNewTextElement("XPosition", ""+XPosition, outDocument));
	                if (XPosition != null && !"".equals(XPosition) && !"null".equals(XPosition)) {
	                    Integer inXPosition = new Integer(XPosition);
	                    ad_printformatitem.setXPosition(inXPosition.intValue());
	                }


	                String YPosition = XMLHelper.getString("YPosition", ad_printformatitem_Node);
	                log.info("YPosition = " + YPosition);
	                resultprintFormatItem.appendChild(createNewTextElement("YPosition", ""+YPosition, outDocument));
	                if (YPosition != null && !"".equals(YPosition) && !"null".equals(YPosition)) {
	                    Integer inYPosition = new Integer(YPosition);
	                    ad_printformatitem.setYPosition(inYPosition.intValue());
	                }


	                String MaxWidth = XMLHelper.getString("MaxWidth", ad_printformatitem_Node);
	                log.info("MaxWidth = " + MaxWidth);
	                resultprintFormatItem.appendChild(createNewTextElement("MaxWidth", ""+MaxWidth, outDocument));
	                if (MaxWidth != null && !"".equals(MaxWidth) && !"null".equals(MaxWidth)) {
	                    Integer inMaxWidth = new Integer(MaxWidth);
	                    ad_printformatitem.setMaxWidth(inMaxWidth.intValue());
	                }


	                String IsHeightOneLine = XMLHelper.getString("IsHeightOneLine", ad_printformatitem_Node);
	                log.info("IsHeightOneLine = " + IsHeightOneLine);
	                resultprintFormatItem.appendChild(createNewTextElement("IsHeightOneLine", ""+IsHeightOneLine, outDocument));
	                if (IsHeightOneLine != null && !"".equals(IsHeightOneLine)) {
	                        ad_printformatitem.setIsHeightOneLine(IsHeightOneLine.equals("Y") ? true : false);
	                }


	                String MaxHeight = XMLHelper.getString("MaxHeight", ad_printformatitem_Node);
	                log.info("MaxHeight = " + MaxHeight);
	                resultprintFormatItem.appendChild(createNewTextElement("MaxHeight", ""+MaxHeight, outDocument));
	                if (MaxHeight != null && !"".equals(MaxHeight) && !"null".equals(MaxHeight)) {
	                    Integer inMaxHeight = new Integer(MaxHeight);
	                    ad_printformatitem.setMaxHeight(inMaxHeight.intValue());
	                }


	                String FieldAlignmentType_Name = XMLHelper.getString("FieldAlignmentType_Name", ad_printformatitem_Node);
	                log.info("FieldAlignmentType_Name = " + FieldAlignmentType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("FieldAlignmentType_Name", ""+FieldAlignmentType_Name, outDocument));
	                String FieldAlignmentType = XMLHelper.reverseReference("AD_Print Field Alignment", FieldAlignmentType_Name);
	                if (FieldAlignmentType_Name != null && !"".equals(FieldAlignmentType_Name)
	                                && FieldAlignmentType != null && !"".equals(FieldAlignmentType)) {
	                        ad_printformatitem.setFieldAlignmentType(FieldAlignmentType);
	                }


	                String LineAlignmentType_Name = XMLHelper.getString("LineAlignmentType_Name", ad_printformatitem_Node);
	                log.info("LineAlignmentType_Name = " + LineAlignmentType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("LineAlignmentType_Name", ""+LineAlignmentType_Name, outDocument));
	                String LineAlignmentType = XMLHelper.reverseReference("AD_Print Line Alignment", LineAlignmentType_Name);
	                if (LineAlignmentType_Name != null && !"".equals(LineAlignmentType_Name)
	                                && LineAlignmentType != null && !"".equals(LineAlignmentType)) {
	                        ad_printformatitem.setLineAlignmentType(LineAlignmentType);
	                }


	                String iAD_PrintColor_Name = XMLHelper.getString("AD_PrintColor_Name", ad_printformatitem_Node);
	                log.info("AD_PrintColor_Name = " + iAD_PrintColor_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("AD_PrintColor_Name", ""+iAD_PrintColor_Name, outDocument));
	                int iAD_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", iAD_PrintColor_Name, AD_Client_ID); 
	                if (iAD_PrintColor_Name != null && !"".equals(iAD_PrintColor_Name)
	                                && 0 != iAD_PrintColor_ID ) {
	                        ad_printformatitem.setAD_PrintColor_ID(iAD_PrintColor_ID);
	                }


	                String iAD_PrintFont_Name = XMLHelper.getString("AD_PrintFont_Name", ad_printformatitem_Node);
	                log.info("AD_PrintFont_Name = " + iAD_PrintFont_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("AD_PrintFont_Name", ""+iAD_PrintFont_Name, outDocument));
	                int iAD_PrintFont_ID = XMLHelper.getIDWithColumn("AD_PrintFont", "Name", iAD_PrintFont_Name, AD_Client_ID); 
	                if (iAD_PrintFont_Name != null && !"".equals(iAD_PrintFont_Name)
	                                && 0 != iAD_PrintFont_ID ) {
	                        ad_printformatitem.setAD_PrintFont_ID(iAD_PrintFont_ID);
	                }


	                String IsOrderBy = XMLHelper.getString("IsOrderBy", ad_printformatitem_Node);
	                log.info("IsOrderBy = " + IsOrderBy);
	                resultprintFormatItem.appendChild(createNewTextElement("IsOrderBy", ""+IsOrderBy, outDocument));
	                if (IsOrderBy != null && !"".equals(IsOrderBy)) {
	                        ad_printformatitem.setIsOrderBy(IsOrderBy.equals("Y") ? true : false);
	                }


	                String SortNo = XMLHelper.getString("SortNo", ad_printformatitem_Node);
	                log.info("SortNo = " + SortNo);
	                resultprintFormatItem.appendChild(createNewTextElement("SortNo", ""+SortNo, outDocument));
	                if (SortNo != null && !"".equals(SortNo) && !"null".equals(SortNo)) {
	                    Integer inSortNo = new Integer(SortNo);
	                    ad_printformatitem.setSortNo(inSortNo.intValue());
	                }


	                String IsGroupBy = XMLHelper.getString("IsGroupBy", ad_printformatitem_Node);
	                log.info("IsGroupBy = " + IsGroupBy);
	                resultprintFormatItem.appendChild(createNewTextElement("IsGroupBy", ""+IsGroupBy, outDocument));
	                if (IsGroupBy != null && !"".equals(IsGroupBy)) {
	                        ad_printformatitem.setIsGroupBy(IsGroupBy.equals("Y") ? true : false);
	                }


	                String IsPageBreak = XMLHelper.getString("IsPageBreak", ad_printformatitem_Node);
	                log.info("IsPageBreak = " + IsPageBreak);
	                resultprintFormatItem.appendChild(createNewTextElement("IsPageBreak", ""+IsPageBreak, outDocument));
	                if (IsPageBreak != null && !"".equals(IsPageBreak)) {
	                        ad_printformatitem.setIsPageBreak(IsPageBreak.equals("Y") ? true : false);
	                }


	                String IsSummarized = XMLHelper.getString("IsSummarized", ad_printformatitem_Node);
	                log.info("IsSummarized = " + IsSummarized);
	                resultprintFormatItem.appendChild(createNewTextElement("IsSummarized", ""+IsSummarized, outDocument));
	                if (IsSummarized != null && !"".equals(IsSummarized)) {
	                        ad_printformatitem.setIsSummarized(IsSummarized.equals("Y") ? true : false);
	                }


	                String ImageIsAttached = XMLHelper.getString("ImageIsAttached", ad_printformatitem_Node);
	                log.info("ImageIsAttached = " + ImageIsAttached);
	                resultprintFormatItem.appendChild(createNewTextElement("ImageIsAttached", ""+ImageIsAttached, outDocument));
	                if (ImageIsAttached != null && !"".equals(ImageIsAttached)) {
	                        ad_printformatitem.setImageIsAttached(ImageIsAttached.equals("Y") ? true : false);
	                }


	                String ImageURL = XMLHelper.getString("ImageURL", ad_printformatitem_Node);
	                log.info("ImageURL = " + ImageURL);
	                resultprintFormatItem.appendChild(createNewTextElement("ImageURL", ""+ImageURL, outDocument));
	                if (ImageURL != null && !"".equals(ImageURL)) {
	                        ad_printformatitem.setImageURL(ImageURL);
	                }


	                String IsAveraged = XMLHelper.getString("IsAveraged", ad_printformatitem_Node);
	                log.info("IsAveraged = " + IsAveraged);
	                resultprintFormatItem.appendChild(createNewTextElement("IsAveraged", ""+IsAveraged, outDocument));
	                if (IsAveraged != null && !"".equals(IsAveraged)) {
	                        ad_printformatitem.setIsAveraged(IsAveraged.equals("Y") ? true : false);
	                }


	                String IsCounted = XMLHelper.getString("IsCounted", ad_printformatitem_Node);
	                log.info("IsCounted = " + IsCounted);
	                resultprintFormatItem.appendChild(createNewTextElement("IsCounted", ""+IsCounted, outDocument));
	                if (IsCounted != null && !"".equals(IsCounted)) {
	                        ad_printformatitem.setIsCounted(IsCounted.equals("Y") ? true : false);
	                }


	                String IsSetNLPosition = XMLHelper.getString("IsSetNLPosition", ad_printformatitem_Node);
	                log.info("IsSetNLPosition = " + IsSetNLPosition);
	                resultprintFormatItem.appendChild(createNewTextElement("IsSetNLPosition", ""+IsSetNLPosition, outDocument));
	                if (IsSetNLPosition != null && !"".equals(IsSetNLPosition)) {
	                        ad_printformatitem.setIsSetNLPosition(IsSetNLPosition.equals("Y") ? true : false);
	                }


	                String IsSuppressNull = XMLHelper.getString("IsSuppressNull", ad_printformatitem_Node);
	                log.info("IsSuppressNull = " + IsSuppressNull);
	                resultprintFormatItem.appendChild(createNewTextElement("IsSuppressNull", ""+IsSuppressNull, outDocument));
	                if (IsSuppressNull != null && !"".equals(IsSuppressNull)) {
	                        ad_printformatitem.setIsSuppressNull(IsSuppressNull.equals("Y") ? true : false);
	                }


	                String BelowColumn = XMLHelper.getString("BelowColumn", ad_printformatitem_Node);
	                log.info("BelowColumn = " + BelowColumn);
	                resultprintFormatItem.appendChild(createNewTextElement("BelowColumn", ""+BelowColumn, outDocument));
	                if (BelowColumn != null && !"".equals(BelowColumn) && !"null".equals(BelowColumn)) {
	                    Integer inBelowColumn = new Integer(BelowColumn);
	                    ad_printformatitem.setBelowColumn(inBelowColumn.intValue());
	                }


	                String AD_PrintGraph_Name = XMLHelper.getString("AD_PrintGraph_Name", ad_printformatitem_Node);
	                log.info("AD_PrintGraph_Name = " + AD_PrintGraph_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("AD_PrintGraph_Name", ""+AD_PrintGraph_Name, outDocument));
	                int AD_PrintGraph_ID = XMLHelper.getIDWithColumn("AD_PrintGraph", "Name", AD_PrintGraph_Name, AD_Client_ID); 
	                if (AD_PrintGraph_Name != null && !"".equals(AD_PrintGraph_Name)
	                                && 0 != AD_PrintGraph_ID ) {
	                        ad_printformatitem.setAD_PrintGraph_ID(AD_PrintGraph_ID);
	                }


	                String IsFixedWidth = XMLHelper.getString("IsFixedWidth", ad_printformatitem_Node);
	                log.info("IsFixedWidth = " + IsFixedWidth);
	                resultprintFormatItem.appendChild(createNewTextElement("IsFixedWidth", ""+IsFixedWidth, outDocument));
	                if (IsFixedWidth != null && !"".equals(IsFixedWidth)) {
	                        ad_printformatitem.setIsFixedWidth(IsFixedWidth.equals("Y") ? true : false);
	                }


	                String IsNextPage = XMLHelper.getString("IsNextPage", ad_printformatitem_Node);
	                log.info("IsNextPage = " + IsNextPage);
	                resultprintFormatItem.appendChild(createNewTextElement("IsNextPage", ""+IsNextPage, outDocument));
	                if (IsNextPage != null && !"".equals(IsNextPage)) {
	                        ad_printformatitem.setIsNextPage(IsNextPage.equals("Y") ? true : false);
	                }


	                String PrintNameSuffix = XMLHelper.getString("PrintNameSuffix", ad_printformatitem_Node);
	                log.info("PrintNameSuffix = " + PrintNameSuffix);
	                resultprintFormatItem.appendChild(createNewTextElement("PrintNameSuffix", ""+PrintNameSuffix, outDocument));
	                if (PrintNameSuffix != null && !"".equals(PrintNameSuffix)) {
	                        ad_printformatitem.setPrintNameSuffix(PrintNameSuffix);
	                }


	                String IsMinCalc = XMLHelper.getString("IsMinCalc", ad_printformatitem_Node);
	                log.info("IsMinCalc = " + IsMinCalc);
	                resultprintFormatItem.appendChild(createNewTextElement("IsMinCalc", ""+IsMinCalc, outDocument));
	                if (IsMinCalc != null && !"".equals(IsMinCalc)) {
	                        ad_printformatitem.setIsMinCalc(IsMinCalc.equals("Y") ? true : false);
	                }


	                String IsMaxCalc = XMLHelper.getString("IsMaxCalc", ad_printformatitem_Node);
	                log.info("IsMaxCalc = " + IsMaxCalc);
	                resultprintFormatItem.appendChild(createNewTextElement("IsMaxCalc", ""+IsMaxCalc, outDocument));
	                if (IsMaxCalc != null && !"".equals(IsMaxCalc)) {
	                        ad_printformatitem.setIsMaxCalc(IsMaxCalc.equals("Y") ? true : false);
	                }


	                String IsRunningTotal = XMLHelper.getString("IsRunningTotal", ad_printformatitem_Node);
	                log.info("IsRunningTotal = " + IsRunningTotal);
	                resultprintFormatItem.appendChild(createNewTextElement("IsRunningTotal", ""+IsRunningTotal, outDocument));
	                if (IsRunningTotal != null && !"".equals(IsRunningTotal)) {
	                        ad_printformatitem.setIsRunningTotal(IsRunningTotal.equals("Y") ? true : false);
	                }


	                String RunningTotalLines = XMLHelper.getString("RunningTotalLines", ad_printformatitem_Node);
	                log.info("RunningTotalLines = " + RunningTotalLines);
	                resultprintFormatItem.appendChild(createNewTextElement("RunningTotalLines", ""+RunningTotalLines, outDocument));
	                if (RunningTotalLines != null && !"".equals(RunningTotalLines) && !"null".equals(RunningTotalLines)) {
	                    Integer inRunningTotalLines = new Integer(RunningTotalLines);
	                    ad_printformatitem.setRunningTotalLines(inRunningTotalLines.intValue());
	                }


	                String IsVarianceCalc = XMLHelper.getString("IsVarianceCalc", ad_printformatitem_Node);
	                log.info("IsVarianceCalc = " + IsVarianceCalc);
	                resultprintFormatItem.appendChild(createNewTextElement("IsVarianceCalc", ""+IsVarianceCalc, outDocument));
	                if (IsVarianceCalc != null && !"".equals(IsVarianceCalc)) {
	                        ad_printformatitem.setIsVarianceCalc(IsVarianceCalc.equals("Y") ? true : false);
	                }


	                String IsDeviationCalc = XMLHelper.getString("IsDeviationCalc", ad_printformatitem_Node);
	                log.info("IsDeviationCalc = " + IsDeviationCalc);
	                resultprintFormatItem.appendChild(createNewTextElement("IsDeviationCalc", ""+IsDeviationCalc, outDocument));
	                if (IsDeviationCalc != null && !"".equals(IsDeviationCalc)) {
	                        ad_printformatitem.setIsDeviationCalc(IsDeviationCalc.equals("Y") ? true : false);
	                }


	                String IsFilledRectangle = XMLHelper.getString("IsFilledRectangle", ad_printformatitem_Node);
	                log.info("IsFilledRectangle = " + IsFilledRectangle);
	                resultprintFormatItem.appendChild(createNewTextElement("IsFilledRectangle", ""+IsFilledRectangle, outDocument));
	                if (IsFilledRectangle != null && !"".equals(IsFilledRectangle)) {
	                        ad_printformatitem.setIsFilledRectangle(IsFilledRectangle.equals("Y") ? true : false);
	                }


	                String LineWidth = XMLHelper.getString("LineWidth", ad_printformatitem_Node);
	                log.info("LineWidth = " + LineWidth);
	                resultprintFormatItem.appendChild(createNewTextElement("LineWidth", ""+LineWidth, outDocument));
	                if (LineWidth != null && !"".equals(LineWidth) && !"null".equals(LineWidth)) {
	                    Integer inLineWidth = new Integer(LineWidth);
	                    ad_printformatitem.setLineWidth(inLineWidth.intValue());
	                }


	                String ArcDiameter = XMLHelper.getString("ArcDiameter", ad_printformatitem_Node);
	                log.info("ArcDiameter = " + ArcDiameter);
	                resultprintFormatItem.appendChild(createNewTextElement("ArcDiameter", ""+ArcDiameter, outDocument));
	                if (ArcDiameter != null && !"".equals(ArcDiameter) && !"null".equals(ArcDiameter)) {
	                    Integer inArcDiameter = new Integer(ArcDiameter);
	                    ad_printformatitem.setArcDiameter(inArcDiameter.intValue());
	                }


	                String ShapeType_Name = XMLHelper.getString("ShapeType_Name", ad_printformatitem_Node);
	                log.info("ShapeType_Name = " + ShapeType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("ShapeType_Name", ""+ShapeType_Name, outDocument));
	                String ShapeType = XMLHelper.reverseReference("AD_PrintFormatItem ShapeType", ShapeType_Name);
	                if (ShapeType_Name != null && !"".equals(ShapeType_Name)
	                                && ShapeType != null && !"".equals(ShapeType)) {
	                        ad_printformatitem.setShapeType(ShapeType);
	                }


	                String IsCentrallyMaintained = XMLHelper.getString("IsCentrallyMaintained", ad_printformatitem_Node);
	                log.info("IsCentrallyMaintained = " + IsCentrallyMaintained);
	                resultprintFormatItem.appendChild(createNewTextElement("IsCentrallyMaintained", ""+IsCentrallyMaintained, outDocument));
	                if (IsCentrallyMaintained != null && !"".equals(IsCentrallyMaintained)) {
	                        ad_printformatitem.setIsCentrallyMaintained(IsCentrallyMaintained.equals("Y") ? true : false);
	                }


	                String IsImageField = XMLHelper.getString("IsImageField", ad_printformatitem_Node);
	                log.info("IsImageField = " + IsImageField);
	                resultprintFormatItem.appendChild(createNewTextElement("IsImageField", ""+IsImageField, outDocument));
	                if (IsImageField != null && !"".equals(IsImageField)) {
	                        ad_printformatitem.setIsImageField(IsImageField.equals("Y") ? true : false);
	                }


	                String BarcodeType_Name = XMLHelper.getString("BarcodeType_Name", ad_printformatitem_Node);
	                log.info("BarcodeType_Name = " + BarcodeType_Name);
	                resultprintFormatItem.appendChild(createNewTextElement("BarcodeType_Name", ""+BarcodeType_Name, outDocument));
	                String BarcodeType = XMLHelper.reverseReference("AD_PrintFormatItem BarcodeType", BarcodeType_Name);
	                if (BarcodeType_Name != null && !"".equals(BarcodeType_Name)
	                                && BarcodeType != null && !"".equals(BarcodeType)) {
	                        //ad_printformatitem.setBarcodeType(BarcodeType); // TODO - Trifon this must be removed if it exists in 2.5.3d!!!
	                }

					// end get's and set's
					
					boolean resultSave = true;
					resultSave = ad_printformatitem.save();
					log.info("--- RESULT SAVE[printFormatItem] = " + resultSave);
					resultprintFormatItem.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
					result.appendChild(resultprintFormatItem);

			}
			
		}
		
		boolean resultSave = true;
		resultSave = ad_printformat.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
	public static X_AD_PrintFormatItem getByAD_PrintFormat_IDandName (Properties ctx, int AD_PrintFormat_ID, String Name, String trxName)
	{
		X_AD_PrintFormatItem result = null;
		
		String sql = "SELECT * "
				   + "FROM " + X_AD_PrintFormatItem.Table_Name + " "
				   + "WHERE "
				   + "     AD_PrintFormat_ID=? "    // #1
				   + " AND Name=? " // #2
				   //+ " AND IsActive='Y' "
	    ;
		PreparedStatement pstmt = null;
		try
		{
			pstmt = DB.prepareStatement (sql, trxName);
			pstmt.setInt(1, AD_PrintFormat_ID);
			pstmt.setString(2, Name);
			
			ResultSet rs = pstmt.executeQuery ();
			if (rs.next ())
				result = new X_AD_PrintFormatItem (ctx, rs, trxName);
			
			rs.close ();
			pstmt.close ();
			pstmt = null;
		}
		catch (Exception e)
		{
			System.out.println(e);
		} finally {
			if (pstmt != null)
				try { pstmt.close (); } catch (Exception ex) { pstmt = null;}
		}
				
		return result;
	}

}