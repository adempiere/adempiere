package org.compiere.compilo.importer.standard;

/**
 * @author Carlos Ruiz - globalqss
 * 
 */
import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_PA_Report;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class PA_ReportImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	<PA_Report>
		<AD_Client_Value>GardenWorld</AD_Client_Value>
		<AD_Org_Value>0</AD_Org_Value>
		<IsActive>Y</IsActive>
		<Name>Balance sheet Detail</Name>
		<Description>Balance sheet Detail</Description>
		<PA_ReportLineSet_Name>Balance Sheet Detail</PA_ReportLineSet_Name>
		<PA_ReportColumnSet_Name>Balance Sheet Detail</PA_ReportColumnSet_Name>
		<C_AcctSchema_Name>GardenWorld UN/31 Australian Dollar</C_AcctSchema_Name>
		<C_Calendar_Name>GardenWorld Calendar</C_Calendar_Name>
		<Processing>N</Processing>
		<AD_PrintFormat_Name>Balance sheet Detail</AD_PrintFormat_Name>
		<ListSources>N</ListSources>
		<ListTrx>N</ListTrx>
	</PA_Report>
	 * 
	 * pa_report_Node represents C_Cause XML element.
	 * 
	 * Using XMLHelper.getString("Name", pa_report_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node pa_report_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("PA_Report");
		
		String PA_Report_Name = null;
		int    PA_Report_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		PA_Report_Name = XMLHelper.getString("Name", pa_report_Node);
		log.info("PA_Report_Name = [" + PA_Report_Name +"]");
		result.appendChild(createNewTextElement("PA_Report_Name", ""+PA_Report_Name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", pa_report_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", pa_report_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for PA_Report by Name...
		PA_Report_ID = XMLHelper.getIDbyName("PA_Report", PA_Report_Name, AD_Client_Value);
		log.info("PA_Report_ID = " + PA_Report_ID);
		result.appendChild(createNewTextElement("PA_Report_ID", ""+PA_Report_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (PA_Report_Name == null || "".equals(PA_Report_Name) || 
				AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: PA_Report_Name or AD_Client_Value is null...");
			System.out.println("ERROR: PA_Report_Name or AD_Client_Value is null...");
			throw new org.compiere.compilo.importer.core.ImportException("PA_Report_Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//pa_report.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		X_PA_Report pa_report = new X_PA_Report(Env.getCtx(), PA_Report_ID, null);
		
		pa_report.setName(PA_Report_Name);
		pa_report.setAD_Org_ID(AD_Org_ID);
		//pa_report.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));

	    // from here the getString's and set's // generated

        String IsActive = XMLHelper.getString("IsActive", pa_report_Node);
        log.info("IsActive = " + IsActive);
        result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
        if (IsActive != null && !"".equals(IsActive)) {
                pa_report.setIsActive(IsActive.equals("Y") ? true : false);
        }


        String Description = XMLHelper.getString("Description", pa_report_Node);
        log.info("Description = " + Description);
        result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
        if (Description != null && !"".equals(Description)) {
                pa_report.setDescription(Description);
        }


        String PA_ReportLineSet_Name = XMLHelper.getString("PA_ReportLineSet_Name", pa_report_Node);
        log.info("PA_ReportLineSet_Name = " + PA_ReportLineSet_Name);
        result.appendChild(createNewTextElement("PA_ReportLineSet_Name", ""+PA_ReportLineSet_Name, outDocument));
        int PA_ReportLineSet_ID = XMLHelper.getIDWithColumn("PA_ReportLineSet", "Name", PA_ReportLineSet_Name, AD_Client_ID); 
        if (PA_ReportLineSet_Name != null && !"".equals(PA_ReportLineSet_Name)
                        && 0 != PA_ReportLineSet_ID ) {
                pa_report.setPA_ReportLineSet_ID(PA_ReportLineSet_ID);
        }


        String PA_ReportColumnSet_Name = XMLHelper.getString("PA_ReportColumnSet_Name", pa_report_Node);
        log.info("PA_ReportColumnSet_Name = " + PA_ReportColumnSet_Name);
        result.appendChild(createNewTextElement("PA_ReportColumnSet_Name", ""+PA_ReportColumnSet_Name, outDocument));
        int PA_ReportColumnSet_ID = XMLHelper.getIDWithColumn("PA_ReportColumnSet", "Name", PA_ReportColumnSet_Name, AD_Client_ID); 
        if (PA_ReportColumnSet_Name != null && !"".equals(PA_ReportColumnSet_Name)
                        && 0 != PA_ReportColumnSet_ID ) {
                pa_report.setPA_ReportColumnSet_ID(PA_ReportColumnSet_ID);
        }


        String C_AcctSchema_Name = XMLHelper.getString("C_AcctSchema_Name", pa_report_Node);
        log.info("C_AcctSchema_Name = " + C_AcctSchema_Name);
        result.appendChild(createNewTextElement("C_AcctSchema_Name", ""+C_AcctSchema_Name, outDocument));
        int C_AcctSchema_ID = XMLHelper.getIDWithColumn("C_AcctSchema", "Name", C_AcctSchema_Name, AD_Client_ID); 
        if (C_AcctSchema_Name != null && !"".equals(C_AcctSchema_Name)
                        && 0 != C_AcctSchema_ID ) {
                pa_report.setC_AcctSchema_ID(C_AcctSchema_ID);
        }


        String C_Calendar_Name = XMLHelper.getString("C_Calendar_Name", pa_report_Node);
        log.info("C_Calendar_Name = " + C_Calendar_Name);
        result.appendChild(createNewTextElement("C_Calendar_Name", ""+C_Calendar_Name, outDocument));
        int C_Calendar_ID = XMLHelper.getIDWithColumn("C_Calendar", "Name", C_Calendar_Name, AD_Client_ID); 
        if (C_Calendar_Name != null && !"".equals(C_Calendar_Name)
                        && 0 != C_Calendar_ID ) {
                pa_report.setC_Calendar_ID(C_Calendar_ID);
        }


        String Processing = XMLHelper.getString("Processing", pa_report_Node);
        log.info("Processing = " + Processing);
        result.appendChild(createNewTextElement("Processing", ""+Processing, outDocument));
        if (Processing != null && !"".equals(Processing)) {
                pa_report.setProcessing(Processing.equals("Y") ? true : false);
        }

        String AD_PrintFormat_Name = XMLHelper.getString("AD_PrintFormat_Name", pa_report_Node);
        log.info("AD_PrintFormat_Name = " + AD_PrintFormat_Name);
        result.appendChild(createNewTextElement("AD_PrintFormat_Name", ""+AD_PrintFormat_Name, outDocument));
        int AD_PrintFormat_ID = XMLHelper.getIDWithColumn("AD_PrintFormat", "Name", AD_PrintFormat_Name, AD_Client_ID); 
        if (AD_PrintFormat_Name != null && !"".equals(AD_PrintFormat_Name)
                        && 0 != AD_PrintFormat_ID ) {
                pa_report.setAD_PrintFormat_ID(AD_PrintFormat_ID);
        }


        String ListSources = XMLHelper.getString("ListSources", pa_report_Node);
        log.info("ListSources = " + ListSources);
        result.appendChild(createNewTextElement("ListSources", ""+ListSources, outDocument));
        if (ListSources != null && !"".equals(ListSources)) {
                pa_report.setListSources(ListSources.equals("Y") ? true : false);
        }


        String ListTrx = XMLHelper.getString("ListTrx", pa_report_Node);
        log.info("ListTrx = " + ListTrx);
        result.appendChild(createNewTextElement("ListTrx", ""+ListTrx, outDocument));
        if (ListTrx != null && !"".equals(ListTrx)) {
                pa_report.setListTrx(ListTrx.equals("Y") ? true : false);
        }

		// end of getString's and set's
	
		boolean resultSave = pa_report.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
