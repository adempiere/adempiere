package org.compiere.compilo.importer.standard;

import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.MUser;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class AD_UserImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
  <AD_User>
    <AD_Client_Value>GardenWorld</AD_Client_Value>
    <AD_Org_Value>0</AD_Org_Value>
    <IsActive>Y</IsActive>
    <Name>User1</Name>
    <Description>Account for User 1</Description>
    <Password>pass</Password>
    <Email>account@example.com</Email>
    <EMailUser>me@me.org</EMailUser>
    <EMailUserPW>pass</EMailUserPW>
    <C_Greeting_Name>Mr.</C_Greeting_Name>
    <NotificationType>E</NotificationType>
    <IsFullBPAccess>Y</IsFullBPAccess>
  </AD_User>

	 * 
	 * AD_User_Node represents AD_User XML element.
	 * 
	 * Using XMLHelper.getString("Name", AD_User_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node ad_User_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_User");
		
		String AD_User_Name = null;
		int    AD_User_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		AD_User_Name = XMLHelper.getString("Name", ad_User_Node);
		log.info("Name = [" + AD_User_Name +"]");
		result.appendChild(createNewTextElement("Name", ""+AD_User_Name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", ad_User_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", ad_User_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for AD_Role by Name...
		AD_User_ID = XMLHelper.getIDbyName("AD_User", AD_User_Name, AD_Client_Value);
		log.info("AD_User_ID = " + AD_User_ID);
		result.appendChild(createNewTextElement("AD_User_ID", ""+AD_User_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (AD_User_Name == null || "".equals(AD_User_Name) || 
			AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: AD_User_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_User_Name or AD_Client_Value is null...");
			throw new ImportException("AD_User_Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		MUser adUser = new MUser(Env.getCtx(), AD_User_ID, null);
		
		adUser.setName(AD_User_Name);
		adUser.setAD_Org_ID(AD_Org_ID);
		//adRole.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		
		String IsActive = XMLHelper.getString("IsActive", ad_User_Node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
		if (IsActive != null && !"".equals(IsActive)) {
			adUser.setIsActive(IsActive.equals("Y") ? true : false);
		}

		String Description = XMLHelper.getString("Description", ad_User_Node);
		log.info("Description = " + Description);
		result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
		if (Description != null && !"".equals(Description)) {
			adUser.setDescription(Description);
		}
		
		String Password = XMLHelper.getString("Password", ad_User_Node);
		log.info("Password = " + Password);
		result.appendChild(createNewTextElement("Password", ""+Password, outDocument));
		if (Password != null && !"".equals(Password)) {
			adUser.setPassword(Password);
		}
		
		String EMail = XMLHelper.getString("EMail", ad_User_Node);
		log.info("EMail = " + EMail);
		result.appendChild(createNewTextElement("EMail", ""+Password, outDocument));
		if (EMail != null && !"".equals(EMail)) {
			adUser.setEMail(EMail);
		}
		
		String Supervisor_Name = XMLHelper.getString("Supervisor_Name", ad_User_Node);
		log.info("Supervisor_Name = " + Supervisor_Name);
		result.appendChild(createNewTextElement("Supervisor_Name", ""+Supervisor_Name, outDocument));
		int Supervisor_ID = XMLHelper.getIDbyName("AD_User", Supervisor_Name, AD_Client_Value); 
		if (Supervisor_Name != null && !"".equals(Supervisor_Name)
				&& 0 != Supervisor_ID ) {
			adUser.setSupervisor_ID(Supervisor_ID);
		}
		
		String C_BPartner_Value = XMLHelper.getString("C_BPartner_Value", ad_User_Node);
		log.info("C_BPartner_Value = " + C_BPartner_Value);
		result.appendChild(createNewTextElement("C_BPartner_Value", ""+C_BPartner_Value, outDocument));
		int C_BPartner_ID = XMLHelper.getIDbyValue("C_BPartner", C_BPartner_Value, AD_Client_Value); 
		if (C_BPartner_Value != null && !"".equals(C_BPartner_Value)
				&& 0 != C_BPartner_ID ) {
			adUser.setC_BPartner_ID(C_BPartner_ID);
		}
		
		String EMailUser = XMLHelper.getString("EMailUser", ad_User_Node);
		log.info("EMailUser = " + EMailUser);
		result.appendChild(createNewTextElement("EMailUser", ""+EMailUser, outDocument));
		if (EMailUser != null && !"".equals(EMailUser)) {
			adUser.setEMailUser(EMailUser);
		}
		
		String EMailUserPW = XMLHelper.getString("EMailUserPW", ad_User_Node);
		log.info("EMailUserPW = " + EMailUserPW);
		result.appendChild(createNewTextElement("EMailUserPW", ""+EMailUserPW, outDocument));
		if (EMailUserPW != null && !"".equals(EMailUserPW)) {
			adUser.setEMailUserPW(EMailUserPW);
		}
		
		String C_BPartner_Location_Name = XMLHelper.getString("C_BPartner_Location_Name", ad_User_Node);
		log.info("C_BPartner_Location_Name = " + C_BPartner_Location_Name);
		result.appendChild(createNewTextElement("C_BPartner_Location_Name", ""+C_BPartner_Location_Name, outDocument));
		int C_BPartner_Location_ID = XMLHelper.getIDbyName("C_BPartner_Location", C_BPartner_Location_Name, AD_Client_Value); 
		if (C_BPartner_Location_Name != null && !"".equals(C_BPartner_Location_Name)
				&& 0 != C_BPartner_Location_ID ) {
			adUser.setC_BPartner_Location_ID(C_BPartner_Location_ID);
		}
		
		String C_Greeting_Name = XMLHelper.getString("C_Greeting_Name", ad_User_Node);
		log.info("C_Greeting_Name = " + C_Greeting_Name);
		result.appendChild(createNewTextElement("C_Greeting_Name", ""+C_Greeting_Name, outDocument));
		int C_Greeting_ID = XMLHelper.getIDbyName("C_Greeting", C_Greeting_Name, AD_Client_Value); 
		if (C_Greeting_Name != null && !"".equals(C_Greeting_Name)
				&& 0 != C_Greeting_ID ) {
			adUser.setC_Greeting_ID(C_Greeting_ID);
		}
		
		String Title = XMLHelper.getString("Title", ad_User_Node);
		log.info("Title = " + Title);
		result.appendChild(createNewTextElement("Title", ""+Title, outDocument));
		if (Title != null && !"".equals(Title)) {
			adUser.setTitle(Title);
		}
		
		String Comments = XMLHelper.getString("Comments", ad_User_Node);
		log.info("Comments = " + Comments);
		result.appendChild(createNewTextElement("Comments", ""+Comments, outDocument));
		if (Comments != null && !"".equals(Comments)) {
			adUser.setComments(Comments);
		}
		
		String Phone = XMLHelper.getString("Phone", ad_User_Node);
		log.info("Phone = " + Phone);
		result.appendChild(createNewTextElement("Phone", ""+Phone, outDocument));
		if (Phone != null && !"".equals(Phone)) {
			adUser.setPhone(Phone);
		}
		
		String Phone2 = XMLHelper.getString("Phone2", ad_User_Node);
		log.info("Phone2 = " + Phone2);
		result.appendChild(createNewTextElement("Phone2", ""+Phone2, outDocument));
		if (Phone2 != null && !"".equals(Phone2)) {
			adUser.setPhone2(Phone2);
		}
		
		String Fax = XMLHelper.getString("Fax", ad_User_Node);
		log.info("Fax = " + Fax);
		result.appendChild(createNewTextElement("Fax", ""+Fax, outDocument));
		if (Fax != null && !"".equals(Fax)) {
			adUser.setFax(Fax);
		}
		
		// TODO - Trifon develop this import !!!
/*		String LastContact = XMLHelper.getString("LastContact", ad_User_Node);
		log.info("LastContact = " + LastContact);
		result.appendChild(createNewTextElement("LastContact", ""+LastContact, outDocument));
		if (LastContact != null && !"".equals(LastContact)) {
			adUser.setLastContact(LastContact);
		}
*/
		String LastResult = XMLHelper.getString("LastResult", ad_User_Node);
		log.info("LastResult = " + LastResult);
		result.appendChild(createNewTextElement("LastResult", ""+LastResult, outDocument));
		if (LastResult != null && !"".equals(LastResult)) {
			adUser.setLastResult(LastResult);
		}
		
		// TODO - Trifon develop this import !!!
/*		String Birthday = XMLHelper.getString("Birthday", ad_User_Node);
		log.info("Birthday = " + Birthday);
		result.appendChild(createNewTextElement("Birthday", ""+Birthday, outDocument));
		if (Birthday != null && !"".equals(Birthday)) {
			adUser.setBirthday(Birthday);
		}
*/
		
		String AD_OrgTrx_Value = XMLHelper.getString("AD_OrgTrx_Value", ad_User_Node);
		log.info("AD_OrgTrx_Value = " + AD_OrgTrx_Value);
		result.appendChild(createNewTextElement("AD_OrgTrx_Value", ""+AD_OrgTrx_Value, outDocument));
		int AD_OrgTrx_ID = XMLHelper.getIDbyValue("AD_Org", AD_OrgTrx_Value, AD_Client_Value); 
		if (AD_OrgTrx_Value != null && !"".equals(AD_OrgTrx_Value)
				&& 0 != AD_OrgTrx_ID ) {
			adUser.setAD_OrgTrx_ID(AD_OrgTrx_ID);
		}
		
		String EMailVerify = XMLHelper.getString("EMailVerify", ad_User_Node);
		log.info("EMailVerify = " + EMailVerify);
		result.appendChild(createNewTextElement("EMailVerify", ""+EMailVerify, outDocument));
		if (EMailVerify != null && !"".equals(EMailVerify)) {
			adUser.setEMailVerify(EMailVerify);
		}
		
		// TODO - Trifon develop import functionality
/*		String EMailVerifyDate = XMLHelper.getString("EMailVerifyDate", ad_User_Node);
		log.info("EMailVerifyDate = " + EMailVerifyDate);
		result.appendChild(createNewTextElement("EMailVerifyDate", ""+EMailVerifyDate, outDocument));
		if (EMailVerifyDate != null && !"".equals(EMailVerifyDate)) {
			adUser.setEMailVerifyDate(EMailVerifyDate);
		}
*/
		
		String NotificationType = XMLHelper.getString("NotificationType", ad_User_Node);
		log.info("NotificationType = " + NotificationType);
		result.appendChild(createNewTextElement("NotificationType", ""+NotificationType, outDocument));
		if (NotificationType != null && !"".equals(NotificationType)) {
			adUser.setNotificationType(NotificationType);
		}
		
		String IsFullBPAccess = XMLHelper.getString("IsFullBPAccess", ad_User_Node);
		log.info("IsFullBPAccess = " + IsFullBPAccess);
		result.appendChild(createNewTextElement("IsFullBPAccess", ""+IsFullBPAccess, outDocument));
		if (IsFullBPAccess != null && !"".equals(IsFullBPAccess)) {
			adUser.setIsFullBPAccess(IsFullBPAccess.equals("Y") ? true : false);
		}
		
		String C_Job_Name = XMLHelper.getString("C_Job_Name", ad_User_Node);
		log.info("C_Job_Name = " + C_Job_Name);
		result.appendChild(createNewTextElement("C_Job_Name", ""+C_Job_Name, outDocument));
		int C_Job_ID = XMLHelper.getIDbyName("C_Job", C_Job_Name, AD_Client_Value); 
		if (C_Job_Name != null && !"".equals(C_Job_Name)
				&& 0 != C_Job_ID ) {
			adUser.setC_Job_ID(C_Job_ID);
		}
		
		String LDAPUser = XMLHelper.getString("LDAPUser", ad_User_Node);
		log.info("LDAPUser = " + LDAPUser);
		result.appendChild(createNewTextElement("LDAPUser", ""+LDAPUser, outDocument));
		if (LDAPUser != null && !"".equals(LDAPUser)) {
			adUser.setLDAPUser(LDAPUser);
		}
		
		String ConnectionProfile = XMLHelper.getString("ConnectionProfile", ad_User_Node);
		log.info("ConnectionProfile = " + ConnectionProfile);
		result.appendChild(createNewTextElement("ConnectionProfile", ""+ConnectionProfile, outDocument));
		if (ConnectionProfile != null && !"".equals(ConnectionProfile)) {
			adUser.setConnectionProfile(ConnectionProfile);
		}

		boolean resultSave = adUser.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
