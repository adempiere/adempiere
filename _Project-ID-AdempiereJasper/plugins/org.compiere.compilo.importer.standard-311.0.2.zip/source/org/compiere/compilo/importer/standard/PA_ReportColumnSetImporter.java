package org.compiere.compilo.importer.standard;

/**
 * @author Carlos Ruiz
 * 
 */
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_PA_ReportColumnSet;
import org.compiere.model.X_PA_ReportColumn;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class PA_ReportColumnSetImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	<PA_ReportColumnSet>
		<IsActive>Y</IsActive>
		<Name>Balance Sheet Detail</Name>
		<Description>Balance Sheet Detail</Description>
		<Processing>N</Processing>
		<PA_ReportColumn>
			<IsActive>Y</IsActive>
			<Name>This Year</Name>
			<SeqNo>10</SeqNo>
			<Description>This Year</Description>
			<IsPrinted>Y</IsPrinted>
			<PostingType_Name>Actual</PostingType_Name>
			<ColumnType_Name>Relative Period</ColumnType_Name>
			<RelativePeriod>0</RelativePeriod>
			<CalculationType_Name>Add (Op1+Op2)</CalculationType_Name>
			<AmountType_Name>Year Balance</AmountType_Name>
			<IsAdhocConversion>N</IsAdhocConversion>
		</PA_ReportColumn>
	</PA_ReportColumnSet>
	 * 
	 * pa_reportcolumnset_Node represents PA_ReportColumnSet XML element.
	 * 
	 * Using XMLHelper.getString("Name", pa_reportcolumnset_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node pa_reportcolumnset_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, ImportException {
		
		Document outDocument = outElement.getOwnerDocument();
		Element resultpa_reportcolumnset = outDocument.createElement("PA_ReportColumnSet");
		
		String name = null;
		int    PA_ReportColumnSet_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		name = XMLHelper.getString("Name", pa_reportcolumnset_Node);
		log.info("Name = [" + name +"]");
		resultpa_reportcolumnset.appendChild(createNewTextElement("Name", ""+name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", pa_reportcolumnset_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		resultpa_reportcolumnset.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		CreatedBy_Name = XMLHelper.getString("CreatedBy_Name", pa_reportcolumnset_Node);
		log.info("CreatedBy_Name = [" + CreatedBy_Name +"]");
		resultpa_reportcolumnset.appendChild(createNewTextElement("CreatedBy_Name", ""+CreatedBy_Name, outDocument));
		
		log.info("_______________________________________________");
		
		// Search for PA_ReportColumnSet by Name...
		PA_ReportColumnSet_ID = XMLHelper.getIDbyName("PA_ReportColumnSet", name, AD_Client_Value);
		log.info("PA_ReportColumnSet_ID = " + PA_ReportColumnSet_ID);
		resultpa_reportcolumnset.appendChild(createNewTextElement("PA_ReportColumnSet_ID", ""+PA_ReportColumnSet_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		resultpa_reportcolumnset.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		resultpa_reportcolumnset.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (name == null || "".equals(name) ||
			AD_Client_Value == null || "".equals(AD_Client_Value)) 
		{
			log.error("ERROR: Name or AD_Client_Value is null...");
			System.out.println("ERROR: Name or AD_Client_Value is null...");
			throw new ImportException("ERROR: Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		resultpa_reportcolumnset.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    X_PA_ReportColumnSet pa_reportcolumnset = new X_PA_ReportColumnSet(Env.getCtx(), PA_ReportColumnSet_ID, null);

	    pa_reportcolumnset.setName(name);
	    
	    // from here the getString's and set's // generated

        String IsActive = XMLHelper.getString("IsActive", pa_reportcolumnset_Node);
        log.info("IsActive = " + IsActive);
        resultpa_reportcolumnset.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
        if (IsActive != null && !"".equals(IsActive)) {
                pa_reportcolumnset.setIsActive(IsActive.equals("Y") ? true : false);
        }


        String Description = XMLHelper.getString("Description", pa_reportcolumnset_Node);
        log.info("Description = " + Description);
        resultpa_reportcolumnset.appendChild(createNewTextElement("Description", ""+Description, outDocument));
        if (Description != null && !"".equals(Description)) {
                pa_reportcolumnset.setDescription(Description);
        }


        String Processing = XMLHelper.getString("Processing", pa_reportcolumnset_Node);
        log.info("Processing = " + Processing);
        resultpa_reportcolumnset.appendChild(createNewTextElement("Processing", ""+Processing, outDocument));
        if (Processing != null && !"".equals(Processing)) {
                pa_reportcolumnset.setProcessing(Processing.equals("Y") ? true : false);
        }

		// end of getString's and set's
		
		pa_reportcolumnset.save();
		
		NodeList pa_reportcolumn_NodeList = XMLHelper.getNodeList("PA_ReportColumn", pa_reportcolumnset_Node);
		for (int indx = 0; indx < pa_reportcolumn_NodeList.getLength(); indx ++) {
			Node pa_reportcolumn_Node = pa_reportcolumn_NodeList.item(indx);
			
			Element resultpa_reportcolumn = outDocument.createElement("PA_ReportColumn");
			//process_AD_Role_OrgAccess(currentNode, resultRootElement);
			// Import pa_reportcolumn
			X_PA_ReportColumn pa_reportcolumn = null;
			
			String pa_reportcolumn_Name = XMLHelper.getString("Name", pa_reportcolumn_Node);
			log.info("Name = " + pa_reportcolumn_Name);
			resultpa_reportcolumn.appendChild(createNewTextElement("Name", ""+pa_reportcolumn_Name, outDocument));
			if (pa_reportcolumn_Name != null && !"".equals(pa_reportcolumn_Name)) {
					// Search for printFormatItem with such Name ...
					// It is not good to call non standard methods!!!
					name = XMLHelper.getString("Name", pa_reportcolumn_Node);
					log.info("Name = [" + name +"]");
					resultpa_reportcolumn.appendChild(createNewTextElement("Name", ""+name, outDocument));
					
					//printFormatItem = X_PA_ReportColumn.getByPA_ReportColumnSet_IDandAD_Process_Para_ID(Env.getCtx(), PA_ReportColumnSet_ID, AD_Process_Para_ID, null);
					pa_reportcolumn = getByPA_ReportColumnSet_IDandName(Env.getCtx(), PA_ReportColumnSet_ID, pa_reportcolumn_Name, null);
					if (pa_reportcolumn != null) {
						// Found existing one!!!
						
					} else {
						// Create new one
						pa_reportcolumn = new X_PA_ReportColumn(Env.getCtx(), 0, null);
						pa_reportcolumn.setPA_ReportColumnSet_ID(pa_reportcolumnset.getPA_ReportColumnSet_ID());
						pa_reportcolumn.setName(pa_reportcolumn_Name);
					}
					
					// start get's and set's

	                String colIsActive = XMLHelper.getString("IsActive", pa_reportcolumn_Node);
	                log.info("IsActive = " + colIsActive);
	                resultpa_reportcolumn.appendChild(createNewTextElement("IsActive", ""+colIsActive, outDocument));
	                if (colIsActive != null && !"".equals(colIsActive)) {
	                        pa_reportcolumn.setIsActive(colIsActive.equals("Y") ? true : false);
	                }


	                String SeqNo = XMLHelper.getString("SeqNo", pa_reportcolumn_Node);
	                log.info("SeqNo = " + SeqNo);
	                resultpa_reportcolumn.appendChild(createNewTextElement("SeqNo", ""+SeqNo, outDocument));
	                if (SeqNo != null && !"".equals(SeqNo) && !"null".equals(SeqNo)) {
	                    Integer inSeqNo = new Integer(SeqNo);
	                    pa_reportcolumn.setSeqNo(inSeqNo.intValue());
	                }


	                String colDescription = XMLHelper.getString("Description", pa_reportcolumn_Node);
	                log.info("Description = " + colDescription);
	                resultpa_reportcolumn.appendChild(createNewTextElement("Description", ""+colDescription, outDocument));
	                if (colDescription != null && !"".equals(colDescription)) {
	                        pa_reportcolumn.setDescription(colDescription);
	                }


	                String IsPrinted = XMLHelper.getString("IsPrinted", pa_reportcolumn_Node);
	                log.info("IsPrinted = " + IsPrinted);
	                resultpa_reportcolumn.appendChild(createNewTextElement("IsPrinted", ""+IsPrinted, outDocument));
	                if (IsPrinted != null && !"".equals(IsPrinted)) {
	                        pa_reportcolumn.setIsPrinted(IsPrinted.equals("Y") ? true : false);
	                }


	                String PostingType_Name = XMLHelper.getString("PostingType_Name", pa_reportcolumn_Node);
	                log.info("PostingType_Name = " + PostingType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("PostingType_Name", ""+PostingType_Name, outDocument));
	                String PostingType = XMLHelper.reverseReference("_Posting Type", PostingType_Name);
	                if (PostingType_Name != null && !"".equals(PostingType_Name)
	                                && PostingType != null && !"".equals(PostingType)) {
	                        pa_reportcolumn.setPostingType(PostingType);
	                }


	                String GL_Budget_Name = XMLHelper.getString("GL_Budget_Name", pa_reportcolumn_Node);
	                log.info("GL_Budget_Name = " + GL_Budget_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("GL_Budget_Name", ""+GL_Budget_Name, outDocument));
	                int GL_Budget_ID = XMLHelper.getIDWithColumn("GL_Budget", "Name", GL_Budget_Name, AD_Client_ID); 
	                if (GL_Budget_Name != null && !"".equals(GL_Budget_Name)
	                                && 0 != GL_Budget_ID ) {
	                        pa_reportcolumn.setGL_Budget_ID(GL_Budget_ID);
	                }


	                String ColumnType_Name = XMLHelper.getString("ColumnType_Name", pa_reportcolumn_Node);
	                log.info("ColumnType_Name = " + ColumnType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("ColumnType_Name", ""+ColumnType_Name, outDocument));
	                String ColumnType = XMLHelper.reverseReference("PA_Report ColumnType", ColumnType_Name);
	                if (ColumnType_Name != null && !"".equals(ColumnType_Name)
	                                && ColumnType != null && !"".equals(ColumnType)) {
	                        pa_reportcolumn.setColumnType(ColumnType);
	                }


	                String RelativePeriod = XMLHelper.getString("RelativePeriod", pa_reportcolumn_Node);
	                log.info("RelativePeriod = " + RelativePeriod);
	                resultpa_reportcolumn.appendChild(createNewTextElement("RelativePeriod", ""+RelativePeriod, outDocument));
	                if (RelativePeriod != null && !"".equals(RelativePeriod) && !"null".equals(RelativePeriod)) {
	                    BigDecimal bdRelativePeriod = new BigDecimal(RelativePeriod);
	                    pa_reportcolumn.setRelativePeriod(bdRelativePeriod);
	                }


	                String CurrencyType_Name = XMLHelper.getString("CurrencyType_Name", pa_reportcolumn_Node);
	                log.info("CurrencyType_Name = " + CurrencyType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("CurrencyType_Name", ""+CurrencyType_Name, outDocument));
	                String CurrencyType = XMLHelper.reverseReference("PA_Report CurrencyType", CurrencyType_Name);
	                if (CurrencyType_Name != null && !"".equals(CurrencyType_Name)
	                                && CurrencyType != null && !"".equals(CurrencyType)) {
	                        pa_reportcolumn.setCurrencyType(CurrencyType);
	                }


	                String CalculationType_Name = XMLHelper.getString("CalculationType_Name", pa_reportcolumn_Node);
	                log.info("CalculationType_Name = " + CalculationType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("CalculationType_Name", ""+CalculationType_Name, outDocument));
	                String CalculationType = XMLHelper.reverseReference("PA_Report CalculationType", CalculationType_Name);
	                if (CalculationType_Name != null && !"".equals(CalculationType_Name)
	                                && CalculationType != null && !"".equals(CalculationType)) {
	                        pa_reportcolumn.setCalculationType(CalculationType);
	                }


	                String AmountType_Name = XMLHelper.getString("AmountType_Name", pa_reportcolumn_Node);
	                log.info("AmountType_Name = " + AmountType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("AmountType_Name", ""+AmountType_Name, outDocument));
	                String AmountType = XMLHelper.reverseReference("PA_Report AmountType", AmountType_Name);
	                if (AmountType_Name != null && !"".equals(AmountType_Name)
	                                && AmountType != null && !"".equals(AmountType)) {
	                        pa_reportcolumn.setAmountType(AmountType);
	                }


	        		String C_Currency_Iso_Code = XMLHelper.getString("C_Currency_Iso_Code", pa_reportcolumn_Node);
	        		log.info("C_Currency_Iso_Code = " + C_Currency_Iso_Code);
	        		resultpa_reportcolumn.appendChild(createNewTextElement("C_Currency_Iso_Code", ""+C_Currency_Iso_Code, outDocument));
	        		int C_Currency_ID = XMLHelper.getIDWithColumn("C_Currency", "Iso_Code", C_Currency_Iso_Code, AD_Client_ID); 
	        		if (C_Currency_Iso_Code != null && !"".equals(C_Currency_Iso_Code)
	        				&& 0 != C_Currency_ID ) {
	        			pa_reportcolumn.setC_Currency_ID(C_Currency_ID);
	        		}
	        		

	        		String IsAdhocConversion = XMLHelper.getString("IsAdhocConversion", pa_reportcolumn_Node);
	                log.info("IsAdhocConversion = " + IsAdhocConversion);
	                resultpa_reportcolumn.appendChild(createNewTextElement("IsAdhocConversion", ""+IsAdhocConversion, outDocument));
	                if (IsAdhocConversion != null && !"".equals(IsAdhocConversion)) {
	                        pa_reportcolumn.setIsAdhocConversion(IsAdhocConversion.equals("Y") ? true : false);
	                }

	                // TODO: Possible problems because Compiere doesnt ensure the uniqueness of name inside the report

	                String Oper_1_Name = XMLHelper.getString("Oper_1_Name", pa_reportcolumn_Node);
	                log.info("Oper_1_Name = " + Oper_1_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("Oper_1_Name", ""+Oper_1_Name, outDocument));
	                int Oper_1_ID = XMLHelper.getIDWithMasterAndColumn("PA_ReportColumn", "Name", Oper_1_Name, "PA_ReportColumnSet", PA_ReportColumnSet_ID);
	                if (Oper_1_Name != null && !"".equals(Oper_1_Name)
	                                && 0 != Oper_1_ID ) {
	                        pa_reportcolumn.setOper_1_ID(Oper_1_ID);
	                }


	                String Oper_2_Name = XMLHelper.getString("Oper_2_Name", pa_reportcolumn_Node);
	                log.info("Oper_2_Name = " + Oper_2_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("Oper_2_Name", ""+Oper_2_Name, outDocument));
	                int Oper_2_ID = XMLHelper.getIDWithMasterAndColumn("PA_ReportColumn", "Name", Oper_2_Name, "PA_ReportColumnSet", PA_ReportColumnSet_ID); 
	                if (Oper_2_Name != null && !"".equals(Oper_2_Name)
	                                && 0 != Oper_2_ID ) {
	                        pa_reportcolumn.setOper_2_ID(Oper_2_ID);
	                }


	                String ElementType_Name = XMLHelper.getString("ElementType_Name", pa_reportcolumn_Node);
	                log.info("ElementType_Name = " + ElementType_Name);
	                resultpa_reportcolumn.appendChild(createNewTextElement("ElementType_Name", ""+ElementType_Name, outDocument));
	                String ElementType = XMLHelper.reverseReference("C_AcctSchema ElementType", ElementType_Name);
	                if (ElementType_Name != null && !"".equals(ElementType_Name)
	                                && ElementType != null && !"".equals(ElementType)) {
	                        pa_reportcolumn.setElementType(ElementType);
	                }


	                String Org_Value = XMLHelper.getString("Org_Value", pa_reportcolumn_Node);
	                log.info("Org_Value = " + Org_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("Org_Value", ""+Org_Value, outDocument));
	                int Org_ID = XMLHelper.getIDWithColumn("AD_Org", "Value", Org_Value, AD_Client_ID); 
	                if (Org_Value != null && !"".equals(Org_Value)
	                                && 0 != Org_ID ) {
	                        pa_reportcolumn.setOrg_ID(Org_ID);
	                }


	                String C_ElementValue_Value = XMLHelper.getString("C_ElementValue_Value", pa_reportcolumn_Node);
	                log.info("C_ElementValue_Value = " + C_ElementValue_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_ElementValue_Value", ""+C_ElementValue_Value, outDocument));
	                int C_ElementValue_ID = XMLHelper.getIDWithColumn("C_ElementValue", "Value", C_ElementValue_Value, AD_Client_ID); 
	                if (C_ElementValue_Value != null && !"".equals(C_ElementValue_Value)
	                                && 0 != C_ElementValue_ID ) {
	                        pa_reportcolumn.setC_ElementValue_ID(C_ElementValue_ID);
	                }


	                String C_Project_Value = XMLHelper.getString("C_Project_Value", pa_reportcolumn_Node);
	                log.info("C_Project_Value = " + C_Project_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_Project_Value", ""+C_Project_Value, outDocument));
	                int C_Project_ID = XMLHelper.getIDWithColumn("C_Project", "Value", C_Project_Value, AD_Client_ID); 
	                if (C_Project_Value != null && !"".equals(C_Project_Value)
	                                && 0 != C_Project_ID ) {
	                        pa_reportcolumn.setC_Project_ID(C_Project_ID);
	                }


	                String C_BPartner_Value = XMLHelper.getString("C_BPartner_Value", pa_reportcolumn_Node);
	                log.info("C_BPartner_Value = " + C_BPartner_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_BPartner_Value", ""+C_BPartner_Value, outDocument));
	                int C_BPartner_ID = XMLHelper.getIDWithColumn("C_BPartner", "Value", C_BPartner_Value, AD_Client_ID); 
	                if (C_BPartner_Value != null && !"".equals(C_BPartner_Value)
	                                && 0 != C_BPartner_ID ) {
	                        pa_reportcolumn.setC_BPartner_ID(C_BPartner_ID);
	                }


	                String M_Product_Value = XMLHelper.getString("M_Product_Value", pa_reportcolumn_Node);
	                log.info("M_Product_Value = " + M_Product_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("M_Product_Value", ""+M_Product_Value, outDocument));
	                int M_Product_ID = XMLHelper.getIDWithColumn("M_Product", "Value", M_Product_Value, AD_Client_ID); 
	                if (M_Product_Value != null && !"".equals(M_Product_Value)
	                                && 0 != M_Product_ID ) {
	                        pa_reportcolumn.setM_Product_ID(M_Product_ID);
	                }


	                String C_Campaign_Value = XMLHelper.getString("C_Campaign_Value", pa_reportcolumn_Node);
	                log.info("C_Campaign_Value = " + C_Campaign_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_Campaign_Value", ""+C_Campaign_Value, outDocument));
	                int C_Campaign_ID = XMLHelper.getIDWithColumn("C_Campaign", "Value", C_Campaign_Value, AD_Client_ID); 
	                if (C_Campaign_Value != null && !"".equals(C_Campaign_Value)
	                                && 0 != C_Campaign_ID ) {
	                        pa_reportcolumn.setC_Campaign_ID(C_Campaign_ID);
	                }


	                /* TODO: Implement C_Location_ID (doesn't have unique id different from ID) 
	                String C_Location_ID = XMLHelper.getString("C_Location_ID", pa_reportcolumn_Node);
	                log.info("C_Location_ID = " + C_Location_ID);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_Location_ID", ""+C_Location_ID, outDocument));
	                if (C_Location_ID != null && !"".equals(C_Location_ID)) {
	                        pa_reportcolumn.setC_Location_ID(C_Location_ID);
	                }
	                */


	                String C_SalesRegion_Value = XMLHelper.getString("C_SalesRegion_Value", pa_reportcolumn_Node);
	                log.info("C_SalesRegion_Value = " + C_SalesRegion_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_SalesRegion_Value", ""+C_SalesRegion_Value, outDocument));
	                int C_SalesRegion_ID = XMLHelper.getIDWithColumn("C_SalesRegion", "Value", C_SalesRegion_Value, AD_Client_ID); 
	                if (C_SalesRegion_Value != null && !"".equals(C_SalesRegion_Value)
	                                && 0 != C_SalesRegion_ID ) {
	                        pa_reportcolumn.setC_SalesRegion_ID(C_SalesRegion_ID);
	                }


	                String C_Activity_Value = XMLHelper.getString("C_Activity_Value", pa_reportcolumn_Node);
	                log.info("C_Activity_Value = " + C_Activity_Value);
	                resultpa_reportcolumn.appendChild(createNewTextElement("C_Activity_Value", ""+C_Activity_Value, outDocument));
	                int C_Activity_ID = XMLHelper.getIDWithColumn("C_Activity", "Value", C_Activity_Value, AD_Client_ID); 
	                if (C_Activity_Value != null && !"".equals(C_Activity_Value)
	                                && 0 != C_Activity_ID ) {
	                        pa_reportcolumn.setC_Activity_ID(C_Activity_ID);
	                }


					// end get's and set's
					
					boolean resultSave = true;
					resultSave = pa_reportcolumn.save();
					log.info("--- RESULT SAVE[PA_ReportColumn] = " + resultSave);
					resultpa_reportcolumn.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
					resultpa_reportcolumnset.appendChild(resultpa_reportcolumn);

			}
			
		}
		
		boolean resultSave = true;
		resultSave = pa_reportcolumnset.save();
		log.info("--- RESULT SAVE = " + resultSave);
		resultpa_reportcolumnset.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(resultpa_reportcolumnset);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
	public static X_PA_ReportColumn getByPA_ReportColumnSet_IDandName (Properties ctx, int PA_ReportColumnSet_ID, String Name, String trxName)
	{
		X_PA_ReportColumn result = null;
		
		String sql = "SELECT * "
				   + "FROM " + X_PA_ReportColumn.Table_Name + " "
				   + "WHERE "
				   + "     PA_ReportColumnSet_ID=? "    // #1
				   + " AND Name=? " // #2
				   //+ " AND IsActive='Y' "
	    ;
		PreparedStatement pstmt = null;
		try
		{
			pstmt = DB.prepareStatement (sql, trxName);
			pstmt.setInt(1, PA_ReportColumnSet_ID);
			pstmt.setString(2, Name);
			
			ResultSet rs = pstmt.executeQuery ();
			if (rs.next ())
				result = new X_PA_ReportColumn (ctx, rs, trxName);
			
			rs.close ();
			pstmt.close ();
			pstmt = null;
		}
		catch (Exception e)
		{
			System.out.println(e);
		} finally {
			if (pstmt != null)
				try { pstmt.close (); } catch (Exception ex) { pstmt = null;}
		}
				
		return result;
	}

}