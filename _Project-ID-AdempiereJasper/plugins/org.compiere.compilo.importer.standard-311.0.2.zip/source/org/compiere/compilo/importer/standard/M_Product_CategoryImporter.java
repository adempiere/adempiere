package org.compiere.compilo.importer.standard;

import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.compiere.model.MProductCategory;

public class M_Product_CategoryImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	 * <M_Product_Category>
	 *   <AD_Client_Value>GardenWorld</AD_Client_Value>
	 *   <AD_Org_Value>0</AD_Org_Value>
	 *   <CreatedBy_Name>SuperUser</CreatedBy_Name>
	 *   <IsActive>Y</IsActive>
	 *   <Name>Standard</Name>
	 *   <Value>Standard</Value>
	 *   <Description>Example description</Description>
	 *   <MMPolicy></MMPolicy>
	 *   <IsDefault>N</IsDefault>
	 *   <IsSelfService>Y</IsSelfService>
	 *   <PlannedMargin>0.0</PlannedMargin>
	 *   <A_Asset_Group_Name></A_Asset_Group_Name>
	 *   <AD_PrintColor_Name></AD_PrintColor_Name>
	 * </M_Product_Category>
	 * 
	 * M_Product_Category_Node represents M_Product_Category XML element.
	 * 
	 * Using XMLHelper.getString("Name", M_Product_Category_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node M_Product_Category_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, ImportException {
		
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("M_Product_Category");
		
		String name = null;
		String value = null;
		int    M_Product_Category_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		name = XMLHelper.getString("Name", M_Product_Category_Node);
		log.info("Name = [" + name +"]");
		result.appendChild(createNewTextElement("Name", ""+name, outDocument));
		
		value = XMLHelper.getString("Value", M_Product_Category_Node);
		log.info("Value = [" + value +"]");
		result.appendChild(createNewTextElement("Value", ""+value, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", M_Product_Category_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		CreatedBy_Name = XMLHelper.getString("CreatedBy_Name", M_Product_Category_Node);
		log.info("CreatedBy_Name = [" + CreatedBy_Name +"]");
		result.appendChild(createNewTextElement("CreatedBy_Name", ""+CreatedBy_Name, outDocument));
		
		log.info("_______________________________________________");
		
		if (value != null && !"".equals(value)) {
			// Search for M_Product_Category_ID by Value...
			M_Product_Category_ID = XMLHelper.getIDbyValue("M_Product_Category", value, AD_Client_Value);
		}
		log.info("M_Product_Category_ID = " + M_Product_Category_ID);
		result.appendChild(createNewTextElement("M_Product_Category", ""+M_Product_Category_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		String PlannedMargin = XMLHelper.getString("PlannedMargin", M_Product_Category_Node);
		log.info("PlannedMargin = " + PlannedMargin);
		result.appendChild(createNewTextElement("PlannedMargin", ""+PlannedMargin, outDocument));
		
		if (value == null || "".equals(value) ||
			name == null || "".equals(name) ||
			AD_Client_Value == null || "".equals(AD_Client_Value) ||
			PlannedMargin == null || "".equals(PlannedMargin)
			) 
		{
			log.error("ERROR: M_Product_Category_Name or M_Product_Category_Value or AD_Client_Value or PlannedMargin is null...");
			System.out.println("ERROR: M_Product_Category_Name or M_Product_Category_Value or AD_Client_Value or PlannedMargin is null...");
			throw new ImportException("ERROR: M_Product_Category_Name or M_Product_Category_Value or AD_Client_Value or PlannedMargin is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    MProductCategory productCategory = new MProductCategory(Env.getCtx(), M_Product_Category_ID, null);
		
		productCategory.setName(name);
		productCategory.setAD_Org_ID(AD_Org_ID);
		
		if (value != null && !"".equals(value)) {
			productCategory.setValue(value);
		}
		
		String IsActive = XMLHelper.getString("IsActive", M_Product_Category_Node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
		if (IsActive != null && !"".equals(IsActive)) {
			productCategory.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String Description = XMLHelper.getString("Description", M_Product_Category_Node);
		log.info("Description = " + Description);
		result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
		if (Description != null && !"".equals(Description)) {
			productCategory.setDescription(Description);
		}
		
		String MMPolicy = XMLHelper.getString("MMPolicy", M_Product_Category_Node);
		log.info("MMPolicy = " + MMPolicy);
		result.appendChild(createNewTextElement("MMPolicy", ""+MMPolicy, outDocument));
		if (MMPolicy != null && !"".equals(MMPolicy)) {
			productCategory.setMMPolicy(MMPolicy);
		}
		
		String IsDefault = XMLHelper.getString("IsDefault", M_Product_Category_Node);
		log.info("IsDefault = " + IsDefault);
		result.appendChild(createNewTextElement("IsDefault", ""+IsDefault, outDocument));
		if (IsDefault != null && !"".equals(IsDefault)) {
			productCategory.setIsDefault(IsDefault.equals("Y") ? true : false);
		}
		
		String IsSelfService = XMLHelper.getString("IsSelfService", M_Product_Category_Node);
		log.info("IsSelfService = " + IsSelfService);
		result.appendChild(createNewTextElement("IsSelfService", ""+IsSelfService, outDocument));
		if (IsSelfService != null && !"".equals(IsSelfService)) {
			productCategory.setIsSelfService(IsSelfService.equals("Y") ? true : false);
		}
		
		BigDecimal plannedMargin = null;
		try {
			if (PlannedMargin != null && !"".equals(PlannedMargin)) {
				plannedMargin = new BigDecimal(PlannedMargin);
				log.info("PlannedMarginBigDecimal = " + plannedMargin);
				result.appendChild(createNewTextElement("PlannedMarginBigDecimal", ""+plannedMargin, outDocument));
				
				productCategory.setPlannedMargin(plannedMargin);
			}
		} catch (NumberFormatException ex) {
			log.info("PlannedMarginBigDecimal = throw exception " + ex.toString());
			result.appendChild(createNewTextElement("PlannedMarginBigDecimal", ""+ex.toString(), outDocument));
		}
		
		String A_Asset_Group_Name = XMLHelper.getString("A_Asset_Group_Name", M_Product_Category_Node);
		log.info("A_Asset_Group_Name = " + A_Asset_Group_Name);
		result.appendChild(createNewTextElement("A_Asset_Group_Name", ""+A_Asset_Group_Name, outDocument));
		int A_Asset_Group_ID = XMLHelper.getIDbyName("A_Asset_Group", A_Asset_Group_Name, AD_Client_Value); 
		if (A_Asset_Group_Name != null && !"".equals(A_Asset_Group_Name)
				&& 0 != A_Asset_Group_ID ) {
			productCategory.setA_Asset_Group_ID(A_Asset_Group_ID);
		}
		
		String AD_PrintColor_Name = XMLHelper.getString("AD_PrintColor_Name", M_Product_Category_Node);
		log.info("AD_PrintColor_Name = " + AD_PrintColor_Name);
		result.appendChild(createNewTextElement("AD_PrintColor_Name", ""+AD_PrintColor_Name, outDocument));
		int AD_PrintColor_ID = XMLHelper.getIDbyName("AD_PrintColor", AD_PrintColor_Name, AD_Client_Value); 
		if (AD_PrintColor_Name != null && !"".equals(AD_PrintColor_Name)
				&& 0 != AD_PrintColor_ID ) {
			productCategory.setAD_PrintColor_ID(AD_PrintColor_ID);
		}
		
		boolean resultSave = true;
		resultSave = productCategory.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
