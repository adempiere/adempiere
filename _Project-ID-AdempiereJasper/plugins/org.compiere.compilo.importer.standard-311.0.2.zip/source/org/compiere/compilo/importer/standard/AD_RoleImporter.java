package org.compiere.compilo.importer.standard;

import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_AD_Role;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class AD_RoleImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	 * <C_Cause>
	 *   <AD_Client_Value>GardenWorld</AD_Client_Value>
	 *   <AD_Org_Value>0</AD_Org_Value>
	 *   <CreatedBy_Name>SuperUser</CreatedBy_Name>
	 *   <Name>Cash Debit</Name>
	 *   <Value>1000000</Value>
	 *   <IsSoTrx>Y</IsSoTrx>
	 * </C_Cause>
	 * 
	 * C_Cause_Node represents C_Cause XML element.
	 * 
	 * Using XMLHelper.getString("Name", C_Cause_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node ad_Role_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_Role");
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		AD_Role_Name = XMLHelper.getString("Name", ad_Role_Node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");
		result.appendChild(createNewTextElement("AD_Role_Name", ""+AD_Role_Name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", ad_Role_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", ad_Role_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		result.appendChild(createNewTextElement("AD_Role_ID", ""+AD_Role_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (AD_Role_Name == null || "".equals(AD_Role_Name) || 
				AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: AD_Role_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Role_Name or AD_Client_Value is null...");
			throw new org.compiere.compilo.importer.core.ImportException("AD_Role_Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		X_AD_Role adRole = new X_AD_Role(Env.getCtx(), AD_Role_ID, null);
		
		adRole.setName(AD_Role_Name);
		adRole.setAD_Org_ID(AD_Org_ID);
		//adRole.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		
		String UserLevel = XMLHelper.getString("UserLevel", ad_Role_Node);
		log.info("UserLevel = " + UserLevel);
		result.appendChild(createNewTextElement("UserLevel", ""+UserLevel, outDocument));
		if (UserLevel != null && !"".equals(UserLevel)) {
			adRole.setUserLevel(UserLevel);
		}
		
		String Description = XMLHelper.getString("Description", ad_Role_Node);
		log.info("Description = " + Description);
		result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
		if (Description != null && !"".equals(Description)) {
			adRole.setDescription(Description);
		}
		
		String C_Currency_Iso_Code = XMLHelper.getString("C_Currency_Iso_Code", ad_Role_Node);
		log.info("C_Currency_Iso_Code = " + C_Currency_Iso_Code);
		result.appendChild(createNewTextElement("C_Currency_Iso_Code", ""+C_Currency_Iso_Code, outDocument));
		int C_Currency_ID = XMLHelper.getIDWithColumn("C_Currency", "Iso_Code", C_Currency_Iso_Code, AD_Client_ID); 
		if (C_Currency_Iso_Code != null && !"".equals(C_Currency_Iso_Code)
				&& 0 != C_Currency_ID ) {
			adRole.setC_Currency_ID(C_Currency_ID);
		}
		
		String AmtApproval = XMLHelper.getString("AmtApproval", ad_Role_Node);
		log.info("AmtApproval = " + AmtApproval);
		result.appendChild(createNewTextElement("AmtApproval", ""+AmtApproval, outDocument));
		BigDecimal amt = new BigDecimal(AmtApproval);
		if (AmtApproval != null && !"".equals(AmtApproval)) {
			adRole.setAmtApproval(amt);
		}
		
		String IsManual = XMLHelper.getString("IsManual", ad_Role_Node);
		log.info("IsManual = " + IsManual);
		result.appendChild(createNewTextElement("IsManual", ""+IsManual, outDocument));
		if (IsManual != null && !"".equals(IsManual)) {
			adRole.setIsManual(IsManual.equals("Y") ? true : false);
		}
		
		String AD_Tree_Menu_Name = XMLHelper.getString("AD_Tree_Menu_Name", ad_Role_Node);
		log.info("AD_Tree_Menu_Name = " + AD_Tree_Menu_Name);
		result.appendChild(createNewTextElement("AD_Tree_Menu_Name", ""+AD_Tree_Menu_Name, outDocument));
		int AD_Tree_Menu_ID = XMLHelper.getIDbyName("AD_Tree", AD_Tree_Menu_Name, AD_Client_Value); 
		if (AD_Tree_Menu_Name != null && !"".equals(AD_Tree_Menu_Name)
				&& 0 != AD_Tree_Menu_ID ) {
			adRole.setAD_Tree_Menu_ID(AD_Tree_Menu_ID);
		}
		
		String IsShowAcct = XMLHelper.getString("IsShowAcct", ad_Role_Node);
		log.info("IsShowAcct = " + IsShowAcct);
		result.appendChild(createNewTextElement("IsShowAcct", ""+IsShowAcct, outDocument));
		if (IsShowAcct != null && !"".equals(IsShowAcct)) {
			adRole.setIsShowAcct(IsShowAcct.equals("Y") ? true : false);
		}
		
		String IsPersonalLock = XMLHelper.getString("IsPersonalLock", ad_Role_Node);
		log.info("IsPersonalLock = " + IsPersonalLock);
		result.appendChild(createNewTextElement("IsPersonalLock", ""+IsPersonalLock, outDocument));
		if (IsPersonalLock != null && !"".equals(IsPersonalLock)) {
			adRole.setIsPersonalLock(IsPersonalLock.equals("Y") ? true : false);
		}
		
		String IsPersonalAccess = XMLHelper.getString("IsPersonalAccess", ad_Role_Node);
		log.info("IsPersonalAccess = " + IsPersonalAccess);
		result.appendChild(createNewTextElement("IsPersonalAccess", ""+IsPersonalAccess, outDocument));
		if (IsPersonalAccess != null && !"".equals(IsPersonalAccess)) {
			adRole.setIsPersonalAccess(IsPersonalAccess.equals("Y") ? true : false);
		}
		
		String IsCanExport = XMLHelper.getString("IsCanExport", ad_Role_Node);
		log.info("IsCanExport = " + IsCanExport);
		result.appendChild(createNewTextElement("IsCanExport", ""+IsCanExport, outDocument));
		if (IsCanExport != null && !"".equals(IsCanExport)) {
			adRole.setIsCanExport(IsCanExport.equals("Y") ? true : false);
		}
		
		String IsCanReport = XMLHelper.getString("IsCanReport", ad_Role_Node);
		log.info("IsCanReport = " + IsCanReport);
		result.appendChild(createNewTextElement("IsCanReport", ""+IsCanReport, outDocument));
		if (IsCanReport != null && !"".equals(IsCanReport)) {
			adRole.setIsCanReport(IsCanReport.equals("Y") ? true : false);
		}
		
		String Supervisor_Name = XMLHelper.getString("Supervisor_Name", ad_Role_Node);
		log.info("Supervisor_Name = " + Supervisor_Name);
		result.appendChild(createNewTextElement("Supervisor_Name", ""+Supervisor_Name, outDocument));
		int Supervisor_ID = XMLHelper.getIDbyName("AD_User", Supervisor_Name, AD_Client_Value); 
		if (Supervisor_Name != null && !"".equals(Supervisor_Name)
				&& 0 != Supervisor_ID ) {
			adRole.setSupervisor_ID(Supervisor_ID);
		}
		
		String IsCanApproveOwnDoc = XMLHelper.getString("IsCanApproveOwnDoc", ad_Role_Node);
		log.info("IsCanApproveOwnDoc = " + IsCanApproveOwnDoc);
		result.appendChild(createNewTextElement("IsCanApproveOwnDoc", ""+IsCanApproveOwnDoc, outDocument));
		if (IsCanApproveOwnDoc != null && !"".equals(IsCanApproveOwnDoc)) {
			adRole.setIsCanApproveOwnDoc(IsCanApproveOwnDoc.equals("Y") ? true : false);
		}
		
		String IsAccessAllOrgs = XMLHelper.getString("IsAccessAllOrgs", ad_Role_Node);
		log.info("IsAccessAllOrgs = " + IsAccessAllOrgs);
		result.appendChild(createNewTextElement("IsAccessAllOrgs", ""+IsAccessAllOrgs, outDocument));
		if (IsAccessAllOrgs != null && !"".equals(IsAccessAllOrgs)) {
			adRole.setIsAccessAllOrgs(IsAccessAllOrgs.equals("Y") ? true : false);
		}
		
		String IsChangeLog = XMLHelper.getString("IsChangeLog", ad_Role_Node);
		log.info("IsChangeLog = " + IsChangeLog);
		result.appendChild(createNewTextElement("IsChangeLog", ""+IsChangeLog, outDocument));
		if (IsChangeLog != null && !"".equals(IsChangeLog)) {
			adRole.setIsChangeLog(IsChangeLog.equals("Y") ? true : false);
		}
		
		String PreferenceType = XMLHelper.getString("PreferenceType", ad_Role_Node);
		log.info("PreferenceType = " + PreferenceType);
		result.appendChild(createNewTextElement("PreferenceType", ""+PreferenceType, outDocument));
		if (PreferenceType != null && !"".equals(PreferenceType)) {
			adRole.setPreferenceType(PreferenceType);
		}
		
		String OverwritePriceLimit = XMLHelper.getString("OverwritePriceLimit", ad_Role_Node);
		log.info("OverwritePriceLimit = " + OverwritePriceLimit);
		result.appendChild(createNewTextElement("OverwritePriceLimit", ""+OverwritePriceLimit, outDocument));
		if (OverwritePriceLimit != null && !"".equals(OverwritePriceLimit)) {
			adRole.setOverwritePriceLimit(OverwritePriceLimit.equals("Y") ? true : false);
		}
		
		String IsUseUserOrgAccess = XMLHelper.getString("IsUseUserOrgAccess", ad_Role_Node);
		log.info("IsUseUserOrgAccess = " + IsUseUserOrgAccess);
		result.appendChild(createNewTextElement("IsUseUserOrgAccess", ""+IsUseUserOrgAccess, outDocument));
		if (IsUseUserOrgAccess != null && !"".equals(IsUseUserOrgAccess)) {
			adRole.setIsUseUserOrgAccess(IsUseUserOrgAccess.equals("Y") ? true : false);
		}
		
		String AD_Tree_Org_Name = XMLHelper.getString("AD_Tree_Org_Name", ad_Role_Node);
		log.info("AD_Tree_Org_Name = " + AD_Tree_Org_Name);
		result.appendChild(createNewTextElement("AD_Tree_Org_Name", ""+AD_Tree_Org_Name, outDocument));
		int AD_Tree_Org_ID = XMLHelper.getIDbyName("AD_Tree", AD_Tree_Org_Name, AD_Client_Value); 
		if (AD_Tree_Org_Name != null && !"".equals(AD_Tree_Org_Name)
				&& 0 != AD_Tree_Org_ID ) {
			adRole.setAD_Tree_Org_ID(AD_Tree_Org_ID);
		}
		
		// From Compiere version 2.5.3
		
		String ConfirmQueryRecords = XMLHelper.getString("ConfirmQueryRecords", ad_Role_Node);
		log.info("ConfirmQueryRecords = " + ConfirmQueryRecords);
		result.appendChild(createNewTextElement("ConfirmQueryRecords", ""+ConfirmQueryRecords, outDocument));
		if (ConfirmQueryRecords != null && !"".equals(ConfirmQueryRecords)) {
			adRole.setConfirmQueryRecords(Integer.parseInt(ConfirmQueryRecords));
		}
		
		String MaxQueryRecords = XMLHelper.getString("MaxQueryRecords", ad_Role_Node);
		log.info("MaxQueryRecords = " + MaxQueryRecords);
		result.appendChild(createNewTextElement("MaxQueryRecords", ""+MaxQueryRecords, outDocument));
		if (MaxQueryRecords != null && !"".equals(MaxQueryRecords)) {
			adRole.setMaxQueryRecords(Integer.parseInt(MaxQueryRecords));
		}
		
		String ConnectionProfile = XMLHelper.getString("ConnectionProfile", ad_Role_Node);
		log.info("ConnectionProfile = " + ConnectionProfile);
		result.appendChild(createNewTextElement("ConnectionProfile", ""+ConnectionProfile, outDocument));
		if (ConnectionProfile != null && !"".equals(ConnectionProfile)) {
			adRole.setConnectionProfile(ConnectionProfile);
		}

		boolean resultSave = adRole.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
