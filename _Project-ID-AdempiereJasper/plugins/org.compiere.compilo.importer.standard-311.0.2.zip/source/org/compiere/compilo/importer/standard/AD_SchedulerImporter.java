package org.compiere.compilo.importer.standard;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.MScheduler;
import org.compiere.model.X_AD_Scheduler_Para;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class AD_SchedulerImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	 * <AD_Scheduler>
		  <AD_Client_Value>Tetrabourse</AD_Client_Value>
		  <AD_Org_Value>0</AD_Org_Value>
		  <AD_Process_Value>Calulate_Acct_Percent</AD_Process_Value>
		  <CreatedBy_Name>TBAdmin</CreatedBy_Name>
		  <UpdatedBy_Name>System</UpdatedBy_Name>
		  <DateLastRun>2006-07-15</DateLastRun>
		  <DateNextRun>2006-08-12</DateNextRun>
		  <Frequency>28</Frequency>
		  ...
	 * </AD_Scheduler>
	 * 
	 * AD_Scheduler_Node represents AD_Scheduler XML element.
	 * 
	 * Using XMLHelper.getString("Name", AD_Scheduler_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node AD_Scheduler_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, ImportException {
		
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_Scheduler");
		
		String name = null;
		int    AD_Scheduler_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Process_Value = null;
		int    AD_Process_ID = 0;
		
		name = XMLHelper.getString("Name", AD_Scheduler_Node);
		log.info("Name = [" + name +"]");
		result.appendChild(createNewTextElement("Name", ""+name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Scheduler_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		CreatedBy_Name = XMLHelper.getString("CreatedBy_Name", AD_Scheduler_Node);
		log.info("CreatedBy_Name = [" + CreatedBy_Name +"]");
		result.appendChild(createNewTextElement("CreatedBy_Name", ""+CreatedBy_Name, outDocument));
		
		AD_Process_Value = XMLHelper.getString("AD_Process_Value", AD_Scheduler_Node);
		log.info("AD_Process_Value = [" + AD_Process_Value +"]");
		result.appendChild(createNewTextElement("AD_Process_Value", ""+AD_Process_Value, outDocument));
		
		log.info("_______________________________________________");
		
		// Search for AD_Scheduler by Name...
		AD_Scheduler_ID = XMLHelper.getIDbyName("AD_Scheduler", name, AD_Client_Value);
		log.info("AD_Scheduler_ID = " + AD_Scheduler_ID);
		result.appendChild(createNewTextElement("AD_Scheduler_ID", ""+AD_Scheduler_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("Description", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		// Search for AD_Process_ID by Value...
		AD_Process_ID = XMLHelper.getIDbyValue("AD_Process", AD_Process_Value, AD_Client_Value);
		log.info("AD_Process_ID = " + AD_Process_ID);
		result.appendChild(createNewTextElement("AD_Process_ID", ""+AD_Process_ID, outDocument));
		
		if (AD_Process_Value == null || "".equals(AD_Process_Value) ||
			name == null || "".equals(name) ||
			AD_Client_Value == null || "".equals(AD_Client_Value)) 
		{
			log.error("ERROR: Name or AD_Process_Value or AD_Client_Value is null...");
			System.out.println("ERROR: Name or AD_Process_Value or AD_Client_Value is null...");
			throw new ImportException("ERROR: Name or AD_Process_Value or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    MScheduler scheduler = new MScheduler(Env.getCtx(), AD_Scheduler_ID, null);

	    scheduler.setName(name);
	    scheduler.setAD_Process_ID(AD_Process_ID);
	    
	    SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd"); // 2006-07-15
    	ParsePosition pos = new ParsePosition(0);
    	
		String DateLastRunStr = XMLHelper.getString("DateLastRun", AD_Scheduler_Node);
		log.info("DateLastRun = " + DateLastRunStr);
		result.appendChild(createNewTextElement("DateLastRun", ""+DateLastRunStr, outDocument));
		if (DateLastRunStr != null && !"".equals(DateLastRunStr)) {
        	Date date = formatter.parse(DateLastRunStr, pos);
        	result.appendChild(createNewTextElement("ParsedDateLastRun", ""+date, outDocument));
        	if (date != null) {
        		scheduler.setDateLastRun(new Timestamp(date.getTime()));
        	}
		}

		String DateNextRunStr = XMLHelper.getString("DateNextRun", AD_Scheduler_Node);
		log.info("DateNextRun = " + DateNextRunStr);
		result.appendChild(createNewTextElement("DateNextRun", ""+DateNextRunStr, outDocument));
		if (DateNextRunStr != null && !"".equals(DateNextRunStr)) {
			pos = new ParsePosition(0);
        	Date date = formatter.parse(DateNextRunStr, pos);
        	result.appendChild(createNewTextElement("ParsedDateNextRun", ""+date, outDocument));
        	if (date != null) {
        		scheduler.setDateNextRun(new Timestamp(date.getTime()));
        	}
		}

		Double Frequency = XMLHelper.getNumber("Frequency", AD_Scheduler_Node);
		log.info("Frequency = " + Frequency);
		result.appendChild(createNewTextElement("Frequency", ""+Frequency, outDocument));
		if (Frequency != null) {
        	scheduler.setFrequency(Frequency.intValue());
		}
		
		String FrequencyType = XMLHelper.getString("FrequencyType", AD_Scheduler_Node);
		log.info("FrequencyType = " + FrequencyType);
		result.appendChild(createNewTextElement("FrequencyType", ""+FrequencyType, outDocument));
		if (FrequencyType != null && !"".equals(FrequencyType)) {
			scheduler.setFrequencyType(FrequencyType);
		}
		
		String IsActive = XMLHelper.getString("IsActive", AD_Scheduler_Node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
		if (IsActive != null && !"".equals(IsActive)) {
			scheduler.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		Double KeepLogDays = XMLHelper.getNumber("KeepLogDays", AD_Scheduler_Node);
		log.info("KeepLogDays = " + KeepLogDays);
		result.appendChild(createNewTextElement("KeepLogDays", ""+KeepLogDays, outDocument));
		if (KeepLogDays != null) {
        	scheduler.setKeepLogDays(KeepLogDays.intValue());
		}
		
		Double MonthDay = XMLHelper.getNumber("MonthDay", AD_Scheduler_Node);
		log.info("MonthDay = " + MonthDay);
		result.appendChild(createNewTextElement("MonthDay", ""+MonthDay, outDocument));
		if (MonthDay != null) {
        	scheduler.setMonthDay(MonthDay.intValue());
		}
		
		String ScheduleType = XMLHelper.getString("ScheduleType", AD_Scheduler_Node);
		log.info("ScheduleType = " + ScheduleType);
		result.appendChild(createNewTextElement("ScheduleType", ""+ScheduleType, outDocument));
		if (ScheduleType != null && !"".equals(ScheduleType)) {
			scheduler.setScheduleType(ScheduleType);
		}
		
		String Supervisor_Name = XMLHelper.getString("Supervisor_Name", AD_Scheduler_Node);
		log.info("Supervisor_Name = " + Supervisor_Name);
		result.appendChild(createNewTextElement("Supervisor_Name", ""+Supervisor_Name, outDocument));
		if (Supervisor_Name != null && !"".equals(Supervisor_Name)) {
			int Supervisor_ID = XMLHelper.getIDbyName("AD_User", Supervisor_Name, AD_Client_Value);
			log.info("Supervisor_ID = " + Supervisor_ID);
			result.appendChild(createNewTextElement("Supervisor_ID", ""+Supervisor_ID, outDocument));
			if (Supervisor_ID != 0) {
				scheduler.setSupervisor_ID(Supervisor_ID);
			}
		}
		
		// TODO - we need to call scheduler.save() else when scheduler is new it throws exception when tries to get AD_Scheduler_ID
		scheduler.save();
		
		NodeList AD_Scheduler_Para_NodeList = XMLHelper.getNodeList("AD_Scheduler_Para", AD_Scheduler_Node);
		for (int indx = 0; indx < AD_Scheduler_Para_NodeList.getLength(); indx ++) {
			Node AD_Scheduler_ParaNode = AD_Scheduler_Para_NodeList.item(indx);
			
			Element resultScheduler_Para = outDocument.createElement("AD_Scheduler_Para");
			//process_AD_Role_OrgAccess(currentNode, resultRootElement);
			// Import AD_Scheduler_Para
			X_AD_Scheduler_Para schedulerPara = null;
			
			String AD_Process_Para_Name = XMLHelper.getString("AD_Process_Para_Name", AD_Scheduler_ParaNode);
			log.info("AD_Process_Para_Name = " + AD_Process_Para_Name);
			resultScheduler_Para.appendChild(createNewTextElement("AD_Process_Para_Name", ""+AD_Process_Para_Name, outDocument));
			if (AD_Process_Para_Name != null && !"".equals(AD_Process_Para_Name)) {
				int AD_Process_Para_ID = XMLHelper.getIDWithMasterAndColumn("AD_Process_Para", "Name", AD_Process_Para_Name, "AD_Process", scheduler.getAD_Process_ID());
				log.info("AD_Process_Para_ID = " + AD_Process_Para_ID);
				resultScheduler_Para.appendChild(createNewTextElement("AD_Process_Para_ID", ""+AD_Process_Para_ID, outDocument));
				
				if (AD_Process_Para_ID != 0) {
					// Search for Scheduler_Para with such Process_Para...
					// It is not good to call non standard methods!!!
					//schedulerPara = MSchedulerPara.getByAD_Scheduler_IDandAD_Process_Para_ID(Env.getCtx(), AD_Scheduler_ID, AD_Process_Para_ID, null);
					schedulerPara = getByAD_Scheduler_IDandAD_Process_Para_ID(Env.getCtx(), AD_Scheduler_ID, AD_Process_Para_ID, null);
					if (schedulerPara != null) {
						// Found existing one!!!
						
					} else {
						// Create new one
						schedulerPara = new X_AD_Scheduler_Para(Env.getCtx(), 0, null);
						schedulerPara.setAD_Scheduler_ID(scheduler.getAD_Scheduler_ID());
						schedulerPara.setAD_Process_Para_ID(AD_Process_Para_ID);
					}

					String Description = XMLHelper.getString("Description", AD_Scheduler_ParaNode);
					log.info("Description = " + Description);
					resultScheduler_Para.appendChild(createNewTextElement("Description", ""+Description, outDocument));
					if (Description != null && !"".equals(Description)) {
						schedulerPara.setDescription(Description);
					}
					
					String IsActiveSP = XMLHelper.getString("IsActive", AD_Scheduler_ParaNode);
					log.info("IsActive = " + IsActiveSP);
					resultScheduler_Para.appendChild(createNewTextElement("IsActive", ""+IsActiveSP, outDocument));
					if (IsActiveSP != null && !"".equals(IsActiveSP)) {
						schedulerPara.setIsActive(IsActiveSP.equals("Y") ? true : false);
					}
					
					String ParameterDefault = XMLHelper.getString("ParameterDefault", AD_Scheduler_ParaNode);
					log.info("ParameterDefault = " + ParameterDefault);
					resultScheduler_Para.appendChild(createNewTextElement("ParameterDefault", ""+ParameterDefault, outDocument));
					if (ParameterDefault != null && !"".equals(ParameterDefault)) {
						schedulerPara.setParameterDefault(ParameterDefault);
					}
					
					boolean resultSave = true;
					resultSave = schedulerPara.save();
					log.info("--- RESULT SAVE[schedulerPara] = " + resultSave);
					resultScheduler_Para.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
					result.appendChild(resultScheduler_Para);

				} else {
					log.error("ERROR: Can't find Process_Para with Name = ["+AD_Process_Para_Name+"]");
					System.out.println("ERROR: Can't find Process_Para with Name = ["+AD_Process_Para_Name+"]");
					throw new ImportException("ERROR: Can't find Process_Para with Name = ["+AD_Process_Para_Name+"]");
				}
								
			} else {
				log.error("ERROR: Process_Para_Name is Mandatory!");
				System.out.println("ERROR: Process_Para_Name is Mandatory!");
				throw new ImportException("ERROR: Process_Para_Name is Mandatory!");
			}
			
		}
		
		boolean resultSave = true;
		resultSave = scheduler.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
	public static X_AD_Scheduler_Para getByAD_Scheduler_IDandAD_Process_Para_ID (Properties ctx, int AD_Scheduler_ID, int AD_Process_Para_ID, String trxName)
	{
		X_AD_Scheduler_Para result = null;
		
		String sql = "SELECT * "
				   + "FROM " + X_AD_Scheduler_Para.Table_Name + " "
				   + "WHERE "
				   + "     AD_Scheduler_ID=? "    // #1
				   + " AND AD_Process_Para_ID=? " // #2
				   //+ " AND IsActive='Y' "
	    ;
		PreparedStatement pstmt = null;
		try
		{
			pstmt = DB.prepareStatement (sql, trxName);
			pstmt.setInt(1, AD_Scheduler_ID);
			pstmt.setInt(2, AD_Process_Para_ID);
			
			ResultSet rs = pstmt.executeQuery ();
			if (rs.next ())
				result = new X_AD_Scheduler_Para (ctx, rs, trxName);
			
			rs.close ();
			pstmt.close ();
			pstmt = null;
		}
		catch (Exception e)
		{
			System.out.println(e);
		} finally {
			if (pstmt != null)
				try { pstmt.close (); } catch (Exception ex) { pstmt = null;}
		}
				
		return result;
	}

}
