package org.compiere.compilo.importer.standard;

/**
 * @author Carlos Ruiz
 * 
 */
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.X_AD_PrintTableFormat;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class AD_PrintTableFormatImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
  	<AD_PrintTableFormat>
		<AD_Client_Value>GardenWorld</AD_Client_Value>
		<AD_Org_Value>0</AD_Org_Value>
		<IsActive>Y</IsActive>
		<HdrTextFG_PrintColor_Name>Black</HdrTextFG_PrintColor_Name>
		<HdrTextBG_PrintColor_Name>White</HdrTextBG_PrintColor_Name>
		<HdrLine_PrintColor_ID>100</HdrLine_PrintColor_ID>
		<HdrLine_PrintColor_Name>Black</HdrLine_PrintColor_Name>
		<FunctBG_PrintColor_Name>White</FunctBG_PrintColor_Name>
		<FunctFG_PrintColor_Name>Black</FunctFG_PrintColor_Name>
		<Line_PrintColor_Name>Gray light</Line_PrintColor_Name>
		<Description>Vertical Lines; Black; Default Fonts</Description>
		<IsPaintBoundaryLines>N</IsPaintBoundaryLines>
		<IsPaintHLines>N</IsPaintHLines>
		<IsPaintVLines>Y</IsPaintVLines>
		<IsPrintFunctionSymbols>N</IsPrintFunctionSymbols>
		<Name>Test on Load with XML2AD</Name>
		<IsDefault>N</IsDefault>
		<ImageIsAttached>N</ImageIsAttached>
		<HdrStroke>2</HdrStroke>
		<LineStroke>1</LineStroke>
		<HdrStrokeType_Name>Solid Line</HdrStrokeType_Name>
		<LineStrokeType_Name>Solid Line</LineStrokeType_Name>
		<IsPaintHeaderLines>Y</IsPaintHeaderLines>
	</AD_PrintTableFormat>
	 * 
	 * AD_PrintTableFormat_Node represents C_Cause XML element.
	 * 
	 * Using XMLHelper.getString("Name", AD_PrintTableFormat_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node ad_PrintTableFormat_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_PrintTableFormat");
		
		String AD_PrintTableFormat_Name = null;
		int    AD_PrintTableFormat_ID = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		AD_PrintTableFormat_Name = XMLHelper.getString("Name", ad_PrintTableFormat_Node);
		log.info("AD_PrintTableFormat_Name = [" + AD_PrintTableFormat_Name +"]");
		result.appendChild(createNewTextElement("AD_PrintTableFormat_Name", ""+AD_PrintTableFormat_Name, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", ad_PrintTableFormat_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", ad_PrintTableFormat_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for AD_PrintTableFormat by Name...
		AD_PrintTableFormat_ID = XMLHelper.getIDbyName("AD_PrintTableFormat", AD_PrintTableFormat_Name, AD_Client_Value);
		log.info("AD_PrintTableFormat_ID = " + AD_PrintTableFormat_ID);
		result.appendChild(createNewTextElement("AD_PrintTableFormat_ID", ""+AD_PrintTableFormat_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (AD_PrintTableFormat_Name == null || "".equals(AD_PrintTableFormat_Name) || 
				AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: AD_PrintTableFormat_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_PrintTableFormat_Name or AD_Client_Value is null...");
			throw new org.compiere.compilo.importer.core.ImportException("AD_PrintTableFormat_Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adPrintTableFormat.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		X_AD_PrintTableFormat adPrintTableFormat = new X_AD_PrintTableFormat(Env.getCtx(), AD_PrintTableFormat_ID, null);
		
		adPrintTableFormat.setName(AD_PrintTableFormat_Name);
		adPrintTableFormat.setAD_Org_ID(AD_Org_ID);
		//adPrintTableFormat.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		
		String IsActive = XMLHelper.getString("IsActive", ad_PrintTableFormat_Node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
		if (IsActive != null && !"".equals(IsActive)) {
			adPrintTableFormat.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String Hdr_PrintFont_Name = XMLHelper.getString("Hdr_PrintFont_Name", ad_PrintTableFormat_Node);
		log.info("Hdr_PrintFont_Name = " + Hdr_PrintFont_Name);
		result.appendChild(createNewTextElement("Hdr_PrintFont_Name", ""+Hdr_PrintFont_Name, outDocument));
		int Hdr_PrintFont_ID = XMLHelper.getIDWithColumn("AD_PrintFont", "Name", Hdr_PrintFont_Name, AD_Client_ID); 
		if (Hdr_PrintFont_Name != null && !"".equals(Hdr_PrintFont_Name)
				&& 0 != Hdr_PrintFont_ID ) {
			adPrintTableFormat.setHdr_PrintFont_ID(Hdr_PrintFont_ID);
		}
		
		String HdrTextFG_PrintColor_Name = XMLHelper.getString("HdrTextFG_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("HdrTextFG_PrintColor_Name = " + HdrTextFG_PrintColor_Name);
		result.appendChild(createNewTextElement("HdrTextFG_PrintColor_Name", ""+HdrTextFG_PrintColor_Name, outDocument));
		int HdrTextFG_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", HdrTextFG_PrintColor_Name, AD_Client_ID); 
		if (HdrTextFG_PrintColor_Name != null && !"".equals(HdrTextFG_PrintColor_Name)
				&& 0 != HdrTextFG_PrintColor_ID ) {
			adPrintTableFormat.setHdrTextFG_PrintColor_ID(HdrTextFG_PrintColor_ID);
		}
		
		String HdrTextBG_PrintColor_Name = XMLHelper.getString("HdrTextBG_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("HdrTextBG_PrintColor_Name = " + HdrTextBG_PrintColor_Name);
		result.appendChild(createNewTextElement("HdrTextBG_PrintColor_Name", ""+HdrTextBG_PrintColor_Name, outDocument));
		int HdrTextBG_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", HdrTextBG_PrintColor_Name, AD_Client_ID); 
		if (HdrTextBG_PrintColor_Name != null && !"".equals(HdrTextBG_PrintColor_Name)
				&& 0 != HdrTextBG_PrintColor_ID ) {
			adPrintTableFormat.setHdrTextBG_PrintColor_ID(HdrTextBG_PrintColor_ID);
		}
		
		String HdrLine_PrintColor_Name = XMLHelper.getString("HdrLine_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("HdrLine_PrintColor_Name = " + HdrLine_PrintColor_Name);
		result.appendChild(createNewTextElement("HdrLine_PrintColor_Name", ""+HdrLine_PrintColor_Name, outDocument));
		int HdrLine_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", HdrLine_PrintColor_Name, AD_Client_ID); 
		if (HdrLine_PrintColor_Name != null && !"".equals(HdrLine_PrintColor_Name)
				&& 0 != HdrLine_PrintColor_ID ) {
			adPrintTableFormat.setHdrLine_PrintColor_ID(HdrLine_PrintColor_ID);
		}
		
		String Funct_PrintFont_Name = XMLHelper.getString("Funct_PrintFont_Name", ad_PrintTableFormat_Node);
		log.info("Funct_PrintFont_Name = " + Funct_PrintFont_Name);
		result.appendChild(createNewTextElement("Funct_PrintFont_Name", ""+Funct_PrintFont_Name, outDocument));
		int Funct_PrintFont_ID = XMLHelper.getIDWithColumn("AD_PrintFont", "Name", Funct_PrintFont_Name, AD_Client_ID); 
		if (Funct_PrintFont_Name != null && !"".equals(Funct_PrintFont_Name)
				&& 0 != Funct_PrintFont_ID ) {
			adPrintTableFormat.setFunct_PrintFont_ID(Funct_PrintFont_ID);
		}
		
		String FunctBG_PrintColor_Name = XMLHelper.getString("FunctBG_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("FunctBG_PrintColor_Name = " + FunctBG_PrintColor_Name);
		result.appendChild(createNewTextElement("FunctBG_PrintColor_Name", ""+FunctBG_PrintColor_Name, outDocument));
		int FunctBG_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", FunctBG_PrintColor_Name, AD_Client_ID); 
		if (FunctBG_PrintColor_Name != null && !"".equals(FunctBG_PrintColor_Name)
				&& 0 != FunctBG_PrintColor_ID ) {
			adPrintTableFormat.setFunctBG_PrintColor_ID(FunctBG_PrintColor_ID);
		}
		
		String FunctFG_PrintColor_Name = XMLHelper.getString("FunctFG_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("FunctFG_PrintColor_Name = " + FunctFG_PrintColor_Name);
		result.appendChild(createNewTextElement("FunctFG_PrintColor_Name", ""+FunctFG_PrintColor_Name, outDocument));
		int FunctFG_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", FunctFG_PrintColor_Name, AD_Client_ID); 
		if (FunctFG_PrintColor_Name != null && !"".equals(FunctFG_PrintColor_Name)
				&& 0 != FunctFG_PrintColor_ID ) {
			adPrintTableFormat.setFunctFG_PrintColor_ID(FunctFG_PrintColor_ID);
		}
		
		String Line_PrintColor_Name = XMLHelper.getString("Line_PrintColor_Name", ad_PrintTableFormat_Node);
		log.info("Line_PrintColor_Name = " + Line_PrintColor_Name);
		result.appendChild(createNewTextElement("Line_PrintColor_Name", ""+Line_PrintColor_Name, outDocument));
		int Line_PrintColor_ID = XMLHelper.getIDWithColumn("AD_PrintColor", "Name", Line_PrintColor_Name, AD_Client_ID); 
		if (Line_PrintColor_Name != null && !"".equals(Line_PrintColor_Name)
				&& 0 != Line_PrintColor_ID ) {
			adPrintTableFormat.setLine_PrintColor_ID(Line_PrintColor_ID);
		}
		
		String Description = XMLHelper.getString("Description", ad_PrintTableFormat_Node);
		log.info("Description = " + Description);
		result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
		if (Description != null && !"".equals(Description)) {
			adPrintTableFormat.setDescription(Description);
		}
		
		String IsPaintBoundaryLines = XMLHelper.getString("IsPaintBoundaryLines", ad_PrintTableFormat_Node);
		log.info("IsPaintBoundaryLines = " + IsPaintBoundaryLines);
		result.appendChild(createNewTextElement("IsPaintBoundaryLines", ""+IsPaintBoundaryLines, outDocument));
		if (IsPaintBoundaryLines != null && !"".equals(IsPaintBoundaryLines)) {
			adPrintTableFormat.setIsPaintBoundaryLines(IsPaintBoundaryLines.equals("Y") ? true : false);
		}
		
		String IsPaintHLines = XMLHelper.getString("IsPaintHLines", ad_PrintTableFormat_Node);
		log.info("IsPaintHLines = " + IsPaintHLines);
		result.appendChild(createNewTextElement("IsPaintHLines", ""+IsPaintHLines, outDocument));
		if (IsPaintHLines != null && !"".equals(IsPaintHLines)) {
			adPrintTableFormat.setIsPaintHLines(IsPaintHLines.equals("Y") ? true : false);
		}
		
		String IsPaintVLines = XMLHelper.getString("IsPaintVLines", ad_PrintTableFormat_Node);
		log.info("IsPaintVLines = " + IsPaintVLines);
		result.appendChild(createNewTextElement("IsPaintVLines", ""+IsPaintVLines, outDocument));
		if (IsPaintVLines != null && !"".equals(IsPaintVLines)) {
			adPrintTableFormat.setIsPaintVLines(IsPaintVLines.equals("Y") ? true : false);
		}
		
		String IsPrintFunctionSymbols = XMLHelper.getString("IsPrintFunctionSymbols", ad_PrintTableFormat_Node);
		log.info("IsPrintFunctionSymbols = " + IsPrintFunctionSymbols);
		result.appendChild(createNewTextElement("IsPrintFunctionSymbols", ""+IsPrintFunctionSymbols, outDocument));
		if (IsPrintFunctionSymbols != null && !"".equals(IsPrintFunctionSymbols)) {
			adPrintTableFormat.setIsPrintFunctionSymbols(IsPrintFunctionSymbols.equals("Y") ? true : false);
		}
		
		String IsDefault = XMLHelper.getString("IsDefault", ad_PrintTableFormat_Node);
		log.info("IsDefault = " + IsDefault);
		result.appendChild(createNewTextElement("IsDefault", ""+IsDefault, outDocument));
		if (IsDefault != null && !"".equals(IsDefault)) {
			adPrintTableFormat.setIsDefault(IsDefault.equals("Y") ? true : false);
		}
		
		String ImageURL = XMLHelper.getString("ImageURL", ad_PrintTableFormat_Node);
		log.info("ImageURL = " + ImageURL);
		result.appendChild(createNewTextElement("ImageURL", ""+ImageURL, outDocument));
		if (ImageURL != null && !"".equals(ImageURL)) {
			adPrintTableFormat.setImageURL(ImageURL);
		}
		
		String HeaderLeft = XMLHelper.getString("HeaderLeft", ad_PrintTableFormat_Node);
		log.info("HeaderLeft = " + HeaderLeft);
		result.appendChild(createNewTextElement("HeaderLeft", ""+HeaderLeft, outDocument));
		if (HeaderLeft != null && !"".equals(HeaderLeft)) {
			adPrintTableFormat.setHeaderLeft(HeaderLeft);
		}
		
		String HeaderCenter = XMLHelper.getString("HeaderCenter", ad_PrintTableFormat_Node);
		log.info("HeaderCenter = " + HeaderCenter);
		result.appendChild(createNewTextElement("HeaderCenter", ""+HeaderCenter, outDocument));
		if (HeaderCenter != null && !"".equals(HeaderCenter)) {
			adPrintTableFormat.setHeaderCenter(HeaderCenter);
		}
		
		String HeaderRight = XMLHelper.getString("HeaderRight", ad_PrintTableFormat_Node);
		log.info("HeaderRight = " + HeaderRight);
		result.appendChild(createNewTextElement("HeaderRight", ""+HeaderRight, outDocument));
		if (HeaderRight != null && !"".equals(HeaderRight)) {
			adPrintTableFormat.setHeaderRight(HeaderRight);
		}
		
		String FooterLeft = XMLHelper.getString("FooterLeft", ad_PrintTableFormat_Node);
		log.info("FooterLeft = " + FooterLeft);
		result.appendChild(createNewTextElement("FooterLeft", ""+FooterLeft, outDocument));
		if (FooterLeft != null && !"".equals(FooterLeft)) {
			adPrintTableFormat.setFooterLeft(FooterLeft);
		}
		
		String FooterCenter = XMLHelper.getString("FooterCenter", ad_PrintTableFormat_Node);
		log.info("FooterCenter = " + FooterCenter);
		result.appendChild(createNewTextElement("FooterCenter", ""+FooterCenter, outDocument));
		if (FooterCenter != null && !"".equals(FooterCenter)) {
			adPrintTableFormat.setFooterCenter(FooterCenter);
		}
		
		String FooterRight = XMLHelper.getString("FooterRight", ad_PrintTableFormat_Node);
		log.info("FooterRight = " + FooterRight);
		result.appendChild(createNewTextElement("FooterRight", ""+FooterRight, outDocument));
		if (FooterRight != null && !"".equals(FooterRight)) {
			adPrintTableFormat.setFooterRight(FooterRight);
		}
		
		String ImageIsAttached = XMLHelper.getString("ImageIsAttached", ad_PrintTableFormat_Node);
		log.info("ImageIsAttached = " + ImageIsAttached);
		result.appendChild(createNewTextElement("ImageIsAttached", ""+ImageIsAttached, outDocument));
		if (ImageIsAttached != null && !"".equals(ImageIsAttached)) {
			adPrintTableFormat.setImageIsAttached(ImageIsAttached.equals("Y") ? true : false);
		}
		
		String HdrStroke = XMLHelper.getString("HdrStroke", ad_PrintTableFormat_Node);
		log.info("HdrStroke = " + HdrStroke);
		result.appendChild(createNewTextElement("HdrStroke", ""+HdrStroke, outDocument));
		BigDecimal bdHdrStroke = new BigDecimal(HdrStroke);
		if (HdrStroke != null && !"".equals(HdrStroke)) {
			adPrintTableFormat.setHdrStroke(bdHdrStroke);
		}
		
		String LineStroke = XMLHelper.getString("LineStroke", ad_PrintTableFormat_Node);
		log.info("LineStroke = " + LineStroke);
		result.appendChild(createNewTextElement("LineStroke", ""+LineStroke, outDocument));
		BigDecimal bdLineStroke = new BigDecimal(LineStroke);
		if (LineStroke != null && !"".equals(LineStroke)) {
			adPrintTableFormat.setLineStroke(bdLineStroke);
		}

		String HdrStrokeType_Name = XMLHelper.getString("HdrStrokeType_Name", ad_PrintTableFormat_Node);
		log.info("HdrStrokeType_Name = " + HdrStrokeType_Name);
		result.appendChild(createNewTextElement("HdrStrokeType_Name", ""+HdrStrokeType_Name, outDocument));
		String HdrStrokeType = XMLHelper.reverseReference("AD_PrintTableFormat Stroke", HdrStrokeType_Name);
		if (HdrStrokeType_Name != null && !"".equals(HdrStrokeType_Name)
				&& HdrStrokeType != null && !"".equals(HdrStrokeType)) {
			adPrintTableFormat.setHdrStrokeType(HdrStrokeType);
		}
		
		String LineStrokeType_Name = XMLHelper.getString("LineStrokeType_Name", ad_PrintTableFormat_Node);
		log.info("LineStrokeType_Name = " + LineStrokeType_Name);
		result.appendChild(createNewTextElement("LineStrokeType_Name", ""+LineStrokeType_Name, outDocument));
		String LineStrokeType = XMLHelper.reverseReference("AD_PrintTableFormat Stroke", LineStrokeType_Name);
		if (LineStrokeType_Name != null && !"".equals(LineStrokeType_Name)
				&& LineStrokeType != null && !"".equals(LineStrokeType)) {
			adPrintTableFormat.setLineStrokeType(LineStrokeType);
		}
		
		String IsPaintHeaderLines = XMLHelper.getString("IsPaintHeaderLines", ad_PrintTableFormat_Node);
		log.info("IsPaintHeaderLines = " + IsPaintHeaderLines);
		result.appendChild(createNewTextElement("IsPaintHeaderLines", ""+IsPaintHeaderLines, outDocument));
		if (IsPaintHeaderLines != null && !"".equals(IsPaintHeaderLines)) {
			adPrintTableFormat.setIsPaintHeaderLines(IsPaintHeaderLines.equals("Y") ? true : false);
		}
		
		boolean resultSave = adPrintTableFormat.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
