package org.compiere.compilo.importer.standard;

import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.MLanguage;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class AD_LanguageImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	 * 	<AD_Language>
	 *		<AD_Client_Value>System</AD_Client_Value>
	 *		<AD_Org_Value>0</AD_Org_Value>
	 *		<AD_Language>bg_BG</AD_Language>
	 *      <CountryCode>BG</CountryCode>
	 *		<Name>Bulgarian (Bulgaria)</Name>
	 *      <IsActive>Y</IsActive>
	 *      <IsBaseLanguage>N</IsBaseLanguage>
	 *      <IsDecimalPoint>N</IsDecimalPoint>
	 *      <IsSystemLanguage>N</IsSystemLanguage>
	 *      <LanguageISO>bg</LanguageISO>
	 *      <TimePattern></TimePattern>
	 *      <DatePattern></DatePattern>
	 *	</AD_Language>
	 * 	
	 * ad_Language_Node represents AD_Language XML element.
	 * 
	 * Using XMLHelper.getString("Name", ad_Language_Node); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node ad_Language_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("AD_Language");
		
		String AD_Language = null;
		String AD_Language_Name  = null;
		int    AD_Language_ID    = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		AD_Language_Name = XMLHelper.getString("Name", ad_Language_Node);
		log.info("Name = [" + AD_Language_Name +"]");
		result.appendChild(createNewTextElement("Name", ""+AD_Language_Name, outDocument));
		
		AD_Language = XMLHelper.getString("AD_Language", ad_Language_Node);
		log.info("AD_Language = [" + AD_Language +"]");
		result.appendChild(createNewTextElement("AD_Language", ""+AD_Language, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", ad_Language_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", ad_Language_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for AD_Language by AD_Language...
		AD_Language_ID = XMLHelper.getIDWithColumn("AD_Language", "AD_Language", AD_Language, AD_Client_ID);
		log.info("AD_Language_ID = " + AD_Language_ID);
		result.appendChild(createNewTextElement("AD_Language_ID", ""+AD_Language_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (AD_Language == null || "".equals(AD_Language) ||
				AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: AD_Language or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Language or AD_Client_Value is null...");
			throw new ImportException("AD_Language or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		MLanguage language = new MLanguage(Env.getCtx(), AD_Language_ID, null);
		
		language.setAD_Language(AD_Language);
		if (AD_Language_Name != null && !"".equals(AD_Language_Name)) {
			language.setName(AD_Language_Name);	
		}
		language.setAD_Org_ID(AD_Org_ID);
		//adRole.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		
		String CountryCode = XMLHelper.getString("CountryCode", ad_Language_Node);
		log.info("CountryCode = " + CountryCode);
		result.appendChild(createNewTextElement("CountryCode", ""+CountryCode, outDocument));
		if (CountryCode != null && !"".equals(CountryCode)) {
			language.setCountryCode(CountryCode);
		}
		
		String IsActive = XMLHelper.getString("IsActive", ad_Language_Node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", ""+IsActive, outDocument));
		if (IsActive != null && !"".equals(IsActive)) {
			language.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsBaseLanguage = XMLHelper.getString("IsBaseLanguage", ad_Language_Node);
		log.info("IsBaseLanguage = " + IsBaseLanguage);
		result.appendChild(createNewTextElement("IsBaseLanguage", ""+IsBaseLanguage, outDocument));
		if (IsBaseLanguage != null && !"".equals(IsBaseLanguage)) {
			language.setIsBaseLanguage(IsBaseLanguage.equals("Y") ? true : false);
		}
		
		String IsDecimalPoint = XMLHelper.getString("IsDecimalPoint", ad_Language_Node);
		log.info("IsDecimalPoint = " + IsDecimalPoint);
		result.appendChild(createNewTextElement("IsDecimalPoint", ""+IsDecimalPoint, outDocument));
		if (IsDecimalPoint != null && !"".equals(IsDecimalPoint)) {
			language.setIsDecimalPoint(IsDecimalPoint.equals("Y") ? true : false);
		}
		
		String IsSystemLanguage = XMLHelper.getString("IsSystemLanguage", ad_Language_Node);
		log.info("IsSystemLanguage = " + IsSystemLanguage);
		result.appendChild(createNewTextElement("IsSystemLanguage", ""+IsSystemLanguage, outDocument));
		if (IsSystemLanguage != null && !"".equals(IsSystemLanguage)) {
			language.setIsSystemLanguage(IsSystemLanguage.equals("Y") ? true : false);
		}
		
		String LanguageISO = XMLHelper.getString("LanguageISO", ad_Language_Node);
		log.info("LanguageISO = " + LanguageISO);
		result.appendChild(createNewTextElement("LanguageISO", ""+LanguageISO, outDocument));
		if (LanguageISO != null && !"".equals(LanguageISO)) {
			language.setLanguageISO(LanguageISO);
		}
		
		String TimePattern = XMLHelper.getString("TimePattern", ad_Language_Node);
		log.info("TimePattern = " + TimePattern);
		result.appendChild(createNewTextElement("TimePattern", ""+TimePattern, outDocument));
		if (TimePattern != null && !"".equals(TimePattern)) {
			language.setTimePattern(TimePattern);
		}
		
		String DatePattern = XMLHelper.getString("DatePattern", ad_Language_Node);
		log.info("DatePattern = " + DatePattern);
		result.appendChild(createNewTextElement("DatePattern", ""+DatePattern, outDocument));
		if (DatePattern != null && !"".equals(DatePattern)) {
			language.setDatePattern(DatePattern);
		}
		
		boolean resultSave = language.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
