package org.compiere.compilo.importer.standard;

import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.MBPGroup;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

public class C_BP_GroupImporter extends TableImporter {

	
	/*
	 * Aim of this plugin is to import record having this structure:
	 * 
	 * 	<C_BP_Group>
	 *		<AD_Client_Value>GardenWorld</AD_Client_Value>
	 *		<AD_Org_Value>0</AD_Org_Value>
	 *		<Value>Standard</Value>
	 *		<Name>Standard Customers</Name>
	 *		<IsDefault>Y</IsDefault>
	 *		<IsConfidentialInfo>N</IsConfidentialInfo>
	 *	</C_BP_Group>
	 * 	
	 *  <C_BP_Group>
	 *		<AD_Client_Value>GardenWorld</AD_Client_Value>
	 *		<AD_Org_Value>HQ</AD_Org_Value>
	 *		<Value>Vendor</Value>
	 *		<Name>Vendors</Name>
	 *		<IsDefault>N</IsDefault>
	 *		<AD_PrintColor_Name>Magenta</AD_PrintColor_Name>
	 *		<IsConfidentialInfo>N</IsConfidentialInfo>
	 *	</C_BP_Group>
	 *
	 * c_BP_Group_Node represents C_BP_Group XML element.
	 * 
	 * Using XMLHelper.getString("Name", C_BP_Group); 
	 *  developer can get value of XML element "Name".
	 *  
	 *  (non-Javadoc)
	 * @see org.compiere.compilo.importer.core.TableImporter#importTable(org.w3c.dom.Node, org.w3c.dom.Element)
	 */
	public void importTable(Node c_BP_Group_Node, Element outElement) throws DOMException, SQLException, XPathExpressionException, org.compiere.compilo.importer.core.ImportException {
	
		Document outDocument = outElement.getOwnerDocument();
		Element result = outDocument.createElement("C_BP_Group");
		
		String C_BP_Group_Value = null;
		String C_BP_Group_Name  = null;
		int    C_BP_Group_ID    = 0;
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
		
		C_BP_Group_Name = XMLHelper.getString("Name", c_BP_Group_Node);
		log.info("C_BP_Group_Name = [" + C_BP_Group_Name +"]");
		result.appendChild(createNewTextElement("C_BP_Group_Name", ""+C_BP_Group_Name, outDocument));
		
		C_BP_Group_Value = XMLHelper.getString("Value", c_BP_Group_Node);
		log.info("C_BP_Group_Value = [" + C_BP_Group_Value +"]");
		result.appendChild(createNewTextElement("C_BP_Group_Value", ""+C_BP_Group_Value, outDocument));
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", c_BP_Group_Node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value, outDocument));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", c_BP_Group_Node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value, outDocument));
		log.info("_______________________________________________");
		
		// Search for C_BP_Group by Value...
		C_BP_Group_ID = XMLHelper.getIDbyValue("C_BP_Group", C_BP_Group_Value, AD_Client_Value);
		log.info("C_BP_Group_ID = " + C_BP_Group_ID);
		result.appendChild(createNewTextElement("C_BP_Group_ID", ""+C_BP_Group_ID, outDocument));
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID, outDocument));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID, outDocument));
		
		if (C_BP_Group_Value == null || "".equals(C_BP_Group_Value) ||
				C_BP_Group_Name == null || "".equals(C_BP_Group_Name) ||
				AD_Client_Value == null || "".equals(AD_Client_Value)) {
			log.error("ERROR: C_BP_Group_Value or C_BP_Group_Name or AD_Client_Value is null...");
			System.out.println("ERROR: C_BP_Group_Value or C_BP_Group_Name or AD_Client_Value is null...");
			throw new ImportException("C_BP_Group_Value or C_BP_Group_Name or AD_Client_Value is null...");
		}
		
		// Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID, outDocument));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
		Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
		
		MBPGroup bpGroup = new MBPGroup(Env.getCtx(), C_BP_Group_ID, null);
		
		bpGroup.setValue(C_BP_Group_Value);
		bpGroup.setName(C_BP_Group_Name);
		bpGroup.setAD_Org_ID(AD_Org_ID);
		//adRole.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		
		String Description = XMLHelper.getString("Description", c_BP_Group_Node);
		log.info("Description = " + Description);
		result.appendChild(createNewTextElement("Description", ""+Description, outDocument));
		if (Description != null && !"".equals(Description)) {
			bpGroup.setDescription(Description);
		}
		
		String IsDefault = XMLHelper.getString("IsDefault", c_BP_Group_Node);
		log.info("Isdefault = " + IsDefault);
		result.appendChild(createNewTextElement("IsDefault", ""+IsDefault, outDocument));
		if (IsDefault != null && !"".equals(IsDefault)) {
			bpGroup.setIsDefault(IsDefault.equals("Y") ? true : false);
		}
		
		String AD_PrintColor_Name = XMLHelper.getString("AD_PrintColor_Name", c_BP_Group_Node);
		log.info("AD_PrintColor_Name = " + AD_PrintColor_Name);
		result.appendChild(createNewTextElement("AD_PrintColor_Name", ""+AD_PrintColor_Name, outDocument));
		int AD_PrintColor_ID = XMLHelper.getIDbyName("AD_PrintColor_Name", AD_PrintColor_Name, AD_Client_Value); 
		if (AD_PrintColor_Name != null 
				&& !"".equals(AD_PrintColor_Name)
				&& 0 != AD_PrintColor_ID ) {
			bpGroup.setAD_PrintColor_ID(AD_PrintColor_ID);
		}
		
		String IsConfidentialInfo = XMLHelper.getString("IsConfidentialInfo", c_BP_Group_Node);
		log.info("IsConfidentialInfo = " + IsConfidentialInfo);
		result.appendChild(createNewTextElement("IsConfidentialInfo", ""+IsConfidentialInfo, outDocument));
		if (IsConfidentialInfo != null && !"".equals(IsConfidentialInfo)) {
			bpGroup.setIsConfidentialInfo(IsConfidentialInfo.equals("Y") ? true : false);
		}
		
		String PriorityBase = XMLHelper.getString("PriorityBase", c_BP_Group_Node);
		log.info("PreferenceType = " + PriorityBase);
		result.appendChild(createNewTextElement("PriorityBase", ""+PriorityBase, outDocument));
		if (PriorityBase != null && !"".equals(PriorityBase)) {
			bpGroup.setPriorityBase(PriorityBase);
		}
		
		String M_PriceList_Name = XMLHelper.getString("M_PriceList_Name", c_BP_Group_Node);
		log.info("M_PriceList_Name = " + M_PriceList_Name);
		result.appendChild(createNewTextElement("M_PriceList_Name", ""+M_PriceList_Name, outDocument));
		int M_PriceList_ID = XMLHelper.getIDbyName("M_PriceList", M_PriceList_Name, AD_Client_Value); 
		if (M_PriceList_Name != null && !"".equals(M_PriceList_Name)
				&& 0 != M_PriceList_ID ) {
			bpGroup.setM_PriceList_ID(M_PriceList_ID);
		}
		
		String PO_PriceList_Name = XMLHelper.getString("PO_PriceList_Name", c_BP_Group_Node);
		log.info("PO_PriceList_Name = " + PO_PriceList_Name);
		result.appendChild(createNewTextElement("PO_PriceList_Name", ""+PO_PriceList_Name, outDocument));
		int PO_PriceList_ID = XMLHelper.getIDbyName("M_PriceList", PO_PriceList_Name, AD_Client_Value); 
		if (PO_PriceList_Name != null && !"".equals(PO_PriceList_Name)
				&& 0 != PO_PriceList_ID ) {
			bpGroup.setPO_PriceList_ID(PO_PriceList_ID);
		}
		
		String M_DiscountSchema_Name = XMLHelper.getString("M_DiscountSchema_Name", c_BP_Group_Node);
		log.info("M_DiscountSchema_Name = " + M_DiscountSchema_Name);
		result.appendChild(createNewTextElement("M_DiscountSchema_Name", ""+M_DiscountSchema_Name, outDocument));
		int M_DiscountSchema_ID = XMLHelper.getIDbyName("M_DiscountSchema", M_DiscountSchema_Name, AD_Client_Value); 
		if (M_DiscountSchema_Name != null && !"".equals(M_DiscountSchema_Name)
				&& 0 != M_DiscountSchema_ID ) {
			bpGroup.setM_DiscountSchema_ID(M_DiscountSchema_ID);
		}
		
		String PO_DiscountSchema_Name = XMLHelper.getString("PO_DiscountSchema_Name", c_BP_Group_Node);
		log.info("PO_DiscountSchema_Name = " + PO_DiscountSchema_Name);
		result.appendChild(createNewTextElement("PO_DiscountSchema_Name", ""+PO_DiscountSchema_Name, outDocument));
		int PO_DiscountSchema_ID = XMLHelper.getIDbyName("M_DiscountSchema", PO_DiscountSchema_Name, AD_Client_Value); 
		if (PO_DiscountSchema_Name != null && !"".equals(PO_DiscountSchema_Name)
				&& 0 != PO_DiscountSchema_ID ) {
			bpGroup.setPO_DiscountSchema_ID(PO_DiscountSchema_ID);
		}
		
		String CreditWatchPercent = XMLHelper.getString("CreditWatchPercent", c_BP_Group_Node);
		log.info("CreditWatchPercent = " + CreditWatchPercent);
		result.appendChild(createNewTextElement("CreditWatchPercent", ""+CreditWatchPercent, outDocument));
		BigDecimal amt = new BigDecimal(CreditWatchPercent);
		if (CreditWatchPercent != null && !"".equals(CreditWatchPercent)) {
			bpGroup.setCreditWatchPercent(amt);
		}
		
		String PriceMatchTolerance = XMLHelper.getString("PriceMatchTolerance", c_BP_Group_Node);
		log.info("PriceMatchTolerance = " + PriceMatchTolerance);
		result.appendChild(createNewTextElement("PriceMatchTolerance", ""+PriceMatchTolerance, outDocument));
		BigDecimal amtPriceMatchTolerance = new BigDecimal(PriceMatchTolerance);
		if (PriceMatchTolerance != null && !"".equals(PriceMatchTolerance)) {
			bpGroup.setPriceMatchTolerance(amtPriceMatchTolerance);
		}
		
		boolean resultSave = bpGroup.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave, outDocument));
		outElement.appendChild(result);
	}

	private Element createNewTextElement(String elementName, String textNodeValue, Document outDocument) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
}
