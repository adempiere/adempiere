package org.compiere.compilo.zzlib;

import java.util.Properties;
import java.util.logging.Level;

import org.compiere.util.CLogger;
import org.compiere.util.DB;
//import org.compiere.util.Log; // @Trifon this is for 2.5.1x versions
//import org.compiere.util.Logger; // @Trifon this is for 2.5.1x versions

/**
 * Adapted from the standard Compiere value preference code
 *
 */
/*
 * UNIQUE INDEX COMPIERE.AD_PREFERENCE_ATTRIBUTE
    ON COMPIERE.AD_PREFERENCE(AD_CLIENT_ID, AD_ORG_ID, AD_WINDOW_ID, AD_USER_ID, ATTRIBUTE)
 */
public class ValuePreferenceManager
{

    /**   Logger                     */
    //private static Logger s_log = Logger.getCLogger(ValuePreferenceManager.class);

    /**   Logger                     */
    //protected Logger         log = Logger.getCLogger (getClass());
   
	private static CLogger	log = CLogger.getCLogger(ValuePreferenceManager.class); //@Trifon
	
    private Properties m_ctx;
    private Integer m_AD_Client_ID;
    private Integer m_AD_Org_ID;
    private Integer m_AD_User_ID;
    private Integer m_AD_Window_ID;
    private String m_Attribute;
    private String m_Value;
   
    public ValuePreferenceManager(
            Properties ctx,
            Integer m_AD_Client_ID,
            Integer m_AD_Org_ID,
            Integer m_AD_User_ID,
            Integer m_AD_Window_ID,
            String m_Attribute
            )
    {
        this.m_ctx=ctx;
        this.m_AD_Client_ID=m_AD_Client_ID;
        this.m_AD_Org_ID=m_AD_Org_ID;
        this.m_AD_User_ID=m_AD_User_ID;
        this.m_AD_Window_ID=m_AD_Window_ID;
        this.m_Attribute=m_Attribute;
    }

    public void set(String value)
    {
        m_Value=value;
        insert();
    }
   
    /**
     *  Save to Disk
     */
    private void insert()
    {
        log.entering("ValuePreference", "insert");

        //  --- Delete first
        int no = delete();
       

        //  --- Inserting
        int Client_ID = m_AD_Client_ID.intValue();
        int Org_ID = m_AD_Org_ID.intValue();
        int AD_Preference_ID = DB.getNextID(m_ctx, "AD_Preference", null);
        //
        /*
         * UNIQUE INDEX COMPIERE.AD_PREFERENCE_ATTRIBUTE
            ON COMPIERE.AD_PREFERENCE(AD_CLIENT_ID, AD_ORG_ID, AD_WINDOW_ID, AD_USER_ID, ATTRIBUTE)
         */
        StringBuffer sql = new StringBuffer ("INSERT INTO AD_Preference ("
            + "AD_Preference_ID, AD_Client_ID, AD_Org_ID, IsActive, Created,CreatedBy,Updated,UpdatedBy,"
            + "AD_Window_ID, AD_User_ID, Attribute, Value) VALUES (");
        sql.append(AD_Preference_ID).append(",").append(Client_ID).append(",").append(Org_ID)
            .append(", 'Y',SysDate,").append(m_AD_User_ID).append(",SysDate,").append(m_AD_User_ID).append(", ");
        if (m_AD_Window_ID==null)
            sql.append("null").append(",");
        else
            sql.append(m_AD_Window_ID).append(",");
        if (m_AD_User_ID==null)
            sql.append("null").append(",");
        else
            sql.append(m_AD_User_ID).append(",");
        //
        sql.append("'").append(m_Attribute).append("','").append(m_Value).append("')");
        //
        log.log(Level.FINER, "sql=" + sql.toString());
        no = DB.executeUpdate(sql.toString(), null);
        if (no != 1)
        {
            throw new SystemException("ValuePreference.insert -  preference not inserted");
        }

    }   //  insert
   
    /**
     *  Delete Preference
     *  @return number of rows deleted
     */
    public int delete()
    {
        log.entering("ValuePreferenceManager", "delete");

        StringBuffer sql = new StringBuffer ("DELETE FROM AD_Preference WHERE ");
        sql.append("AD_Client_ID=").append(m_AD_Client_ID);
        sql.append(" AND AD_Org_ID=").append(m_AD_Org_ID);
        if (m_AD_User_ID==null)
            sql.append(" AND AD_User_ID is null ");
        else
            sql.append(" AND AD_User_ID=").append(m_AD_User_ID);
        if (m_AD_Window_ID==null)
            sql.append(" AND AD_Window_ID is null ");
        else
            sql.append(" AND AD_Window_ID=").append(m_AD_Window_ID);
        sql.append(" AND Attribute='").append(m_Attribute).append("'");
        //
        log.log(Level.FINER, "sql = " + sql.toString());
        int no = DB.executeUpdate(sql.toString(), null);
        return no;
    }   //  delete

   
   
    /**
     * @return "" if no value, else the value for this value preference
     */
    public String get()
    {
        String ret;
        log.entering("ValuePreferenceManager", "get()");
        StringBuffer sql = new StringBuffer();
        sql.append
            (" SELECT value FROM AD_Preference a ").append
            (" WHERE " ).append
            (" a.AD_Client_ID=").append(m_AD_Client_ID).append(" AND ").append
            (" a.AD_Org_ID=").append(m_AD_Org_ID);
        if (m_AD_User_ID==null)
            sql.append(" AND AD_User_ID is null ");
        else
            sql.append(" AND AD_User_ID=").append(m_AD_User_ID);
        if (m_AD_Window_ID==null)
            sql.append(" AND AD_Window_ID is null ");
        else
            sql.append(" AND AD_Window_ID=").append(m_AD_Window_ID);
         sql.append(" and ").append
            (" attribute=" + ZZLib.quote(m_Attribute))
            ;
         log.log(Level.FINER, "sql=" + sql);
        ret=ZZLib.quickQueryString(m_ctx, sql.toString(), false);  //returns "" if no value
        return ret;
    }
}