package org.compiere.compilo.zzlib;

public class SystemException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2155096199167048313L;

	public SystemException() {
	    super();
	 }
	
	 public SystemException(String message, Throwable cause) {
	    super(message, cause);
	 }
	
	 public SystemException(String message) {
	    super(message);
	 }
	
	 public SystemException(Throwable cause) {
	    super(cause);
	 }
}