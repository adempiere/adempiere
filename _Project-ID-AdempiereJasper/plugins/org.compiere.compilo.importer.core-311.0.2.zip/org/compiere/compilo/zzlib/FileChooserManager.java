package org.compiere.compilo.zzlib;

import java.io.File;
import java.util.Properties;
import java.util.logging.Level;

import javax.swing.JFileChooser;

import org.compiere.model.MUser;
import org.compiere.util.CLogger;
import org.compiere.util.Env;
import org.compiere.util.ExtensionFileFilter;
//import org.compiere.util.Logger;
import org.compiere.util.Msg;

/**
 * Managed file chooser
 * Lookup a file, store the path that the user selected so that next time
 *  we use the same path for convenience sake
 */
public class FileChooserManager
{
   
    /**   Logger                     */
    //private static Logger s_log = Logger.getCLogger(FileChooserManager.class);
   
    /**   Logger                     */
    //protected Logger         log = Logger.getCLogger (getClass());

    private static CLogger	log = CLogger.getCLogger(FileChooserManager.class); //@Trifon
   
    public FileChooserManager()
    {
    }
   
    /**
     * Display a file selection dialog
     *
     * File file=ZZLib.getFile("Export Allocation (Specify the .csv extension)", "csv");
     String status="";
     if (file==null) {
     status="User cancelled file selection";
     throw new Exception(status);
     }
     * @param ctx
     * @param title
     * @param fileExtension e.g. csv
     * @return  File or null
     */
    public static File getFile(Properties ctx, String title, String fileExtension)
    {
        log.entering("FileChooserManager", "getFile");
        File file = null;
        String dirName =null;
        dirName=getLastUsedDirectory(ctx);
        if (!validateDir(dirName))
        {
            log.log(Level.WARNING, "FileChooserManager - '" + dirName + "' is invalid *******");
            dirName=org.compiere.Adempiere.getAdempiereHome() ;
        }
        JFileChooser chooser = new JFileChooser(dirName);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setMultiSelectionEnabled(false);
        chooser.setDialogTitle(Msg.translate(Env.getCtx(), title));
        chooser.addChoosableFileFilter(new ExtensionFileFilter(fileExtension, fileExtension));
       
        //  Show it
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            file = chooser.getSelectedFile();
            setLastUsedDirectory(ctx, file.getParent());
        }
        else
        {
            file = null;
        }
        chooser = null;
   
        return file;
    }   //  getFile
   

    private static String getLastUsedDirectory(Properties ctx)
    {
        String ret;
        ret=getPreference(ctx).get();
        return ret;
    }
   
    private static void setLastUsedDirectory(Properties ctx, String dir)
    {
        if (dir!=null)
        {
            getPreference(ctx).set(dir);
        } else
        {
            getPreference(ctx).set("");
        }
    }
   
    private static boolean validateDir(String dir)
    {
        File file;
       
        file=new File(dir);
        if (file.canRead())
        {
            return true;
        }
        return false;
    }
   
    private static ValuePreferenceManager getPreference(Properties ctx)
    {
        String prefName;
        MUser user;
        ValuePreferenceManager pref;
       
        user=new MUser(ctx, Env.getAD_User_ID(ctx), null); //@Trifon
        prefName="Last Used Directory " + user.getName();
       
        pref=new ValuePreferenceManager(
                ctx,
                new Integer(Env.getAD_Client_ID(ctx)),  /*m_AD_Client_ID*/
                new Integer(0),                         /*m_AD_Org_ID*/
                new Integer(Env.getAD_User_ID(ctx)) ,   /*Env.getAD_User_ID(ctx) */
                null,                                   /*m_AD_Window_ID*/
                prefName
        );
        return pref;
    }
   
}