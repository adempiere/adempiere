package org.compiere.compilo.zzlib;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.logging.Level;

import org.compiere.util.CLogger;
import org.compiere.util.DB;
import org.compiere.util.Env;

public class ZZLib {

    private static CLogger log = CLogger.getCLogger(ZZLib.class); //@Trifon
    
	public static String quickQueryString(Properties ctx, String sql, boolean checkClient) {

	      String retValue=null;
	      ResultSet rs = null;
	      PreparedStatement pstmt=null;

	      try {
	         pstmt = DB.prepareStatement(sql, null);

	         if (checkClient) {
	         	int AD_Client_ID = Env.getAD_Client_ID(ctx);
	         	pstmt.setInt(1, AD_Client_ID);
            }

	         rs = pstmt.executeQuery();
	         if (rs.next())
	            retValue=rs.getString(1);
	         else
	            return "";
	      } catch (Exception ex) {
	      	log.log(Level.WARNING, " Error: sql=" + sql, ex);
            throw new SystemException(ex);
	      } finally {
	         try {
	            pstmt.close();
	         } catch (Exception ex) {
	         	// ignored
	         } 
	         pstmt = null;
	      }
	      return retValue;
	   }

	    public static String quickQueryString(Properties ctx, String sql) {

	        return quickQueryString(ctx, sql, true);

	    }
	    
	    /**
	     * Quote the sql in "'" for sql statements
	     * @param sql
	     * @return
	     */
	    public static String quote(String sql) {
	         if (sql==null)
	         {
	             return "'null'";
	         }
	       return "'" + sql.replaceAll("'", "''") + "'";
	    }
}
