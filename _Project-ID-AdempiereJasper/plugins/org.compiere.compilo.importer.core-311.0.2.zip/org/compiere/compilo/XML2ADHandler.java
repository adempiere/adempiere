package org.compiere.compilo;


import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;

import org.compiere.compilo.helper.XMLHelper;
import org.compiere.model.GenericPO;
import org.compiere.model.MLanguage;
import org.compiere.model.MRefList;
import org.compiere.model.MTree_Base;
import org.compiere.model.MTree_NodeMM;
import org.compiere.model.POInfo;
import org.compiere.model.X_AD_Column;
import org.compiere.model.X_AD_Element;
import org.compiere.model.X_AD_Field;
import org.compiere.model.X_AD_Menu;
import org.compiere.model.X_AD_Process;
import org.compiere.model.X_AD_Process_Para;
import org.compiere.model.X_AD_Ref_Table;
import org.compiere.model.X_AD_Reference;
import org.compiere.model.X_AD_ReportView;
import org.compiere.model.X_AD_Sequence;
import org.compiere.model.X_AD_Tab;
import org.compiere.model.X_AD_Table;
import org.compiere.model.X_AD_Val_Rule;
import org.compiere.model.X_AD_Window;
import org.compiere.util.CLogMgt;
import org.compiere.util.CLogger;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * SAX Handler for parsing XML description of the GUI.
 *
 * @author Marco LOMBARDO, lombardo@mayking.com
 */
public class XML2ADHandler extends DefaultHandler {

    /**
     * 	XML2AD Handler
     */
    public XML2ADHandler () {
		m_MenuSeqNo = new int[100];   // TODO: remove this limit of 100 nested menu levels.
		m_Menu = new X_AD_Menu[100];
		m_Tab = new X_AD_Tab[100];
		m_MenuSeqNo[m_MenuIndex+1] = 100;
    }

    /** Default Entity Type */
    private String m_EntityType = "A"; // Applications, select name,value from ad_ref_list where ad_reference_id =245. TODO: put a param.
    /** Default Access Level */
    private String m_AccessLevel = "3"; // Client+Organization, select name,value from ad_ref_list where ad_reference_id =5. TODO: put a param.
    /** Menu array          */
    private X_AD_Menu[] m_Menu;
    private int m_MenuIndex = -1;
    private int[] m_MenuSeqNo;
    
    private X_AD_Window m_Window = null;
    private X_AD_Process m_Process = null;
    private int m_ProcessSeqNo = 10;
    private X_AD_Table m_Table = null;
    private X_AD_Column m_Column = null;
    private int m_ColumnSeqNo = 10;
    private X_AD_Tab[] m_Tab;
    private int m_TabSeqNo = 0;
    private int m_TabLevelNo = -1;
    private X_AD_Field m_Field = null;
    private int m_FieldSeqNo = 10;
    
    private SimpleDateFormat	m_dformat = null; // @Trifon
    
    private MLanguage	m_translationLanguage = null; // @Trifon
    
    private String trl = null; // @Trifon
    private String translationIsActive = null; // @Trifon
    
    private boolean isFieldTranslation = false; // @Trifon
    private boolean isReferenceTranslation = false; // @Trifon
    private boolean isReferenceListTranslation = false; // @Trifon
    
    private String translationName = null; // @Trifon
    private boolean isAttribName = false; // @Trifon
    
    private String translationDescription = null; // @Trifon
    private boolean isAttribDescription = false; // @Trifon
    
    private String translationHelp = null; // @Trifon
    private boolean isAttribHelp = false; // @Trifon
    
    private Timestamp m_time = new Timestamp(System.currentTimeMillis()); // @Trifon
    
    private X_AD_Reference m_Reference = null;
    private boolean isReference = false; // @Trifon
    
    
    private X_AD_Ref_Table m_Ref_Table = null; // @Trifon
    private boolean isReferenceTale = false; // @Trifon
    
    private MRefList m_RefList = null; // @Trifon
    private boolean isRefList = false; // @Trifon; it is rised to true when execution is in ReferenceList xml element 
    
    /** Set this if you want to delete a definition rather than create it. */
    private boolean m_DeleteMode = false;
    /** Switch between Compiere Application Dictionary and Druid parser.*/   // TODO: split the three parser: for view, model and data.
    private boolean compiereAD = false;
    /** Switch to Compiere data.                                        */
    private boolean compieredata = false;
    /** tablename for compieredata                                      */
    private String d_tablename = null;
    private String d_rowname = null;
    private GenericPO genericPO = null;
    private boolean isDefaultData = false;
    private HashMap defaults = new HashMap();
    private int m_AD_Client_ID = 0;
    String m_ColumnList = "";
    
    /** Switch to Druid.                                                */
    private boolean druid = false;
    
    private StringBuffer chracters = null;
    
    /** Constants                            */
    private final static String TABLE_TAG = "table";
    private final static String TABLEDATA_TAG = "table";
    private final static String ROWDATA_TAG = "row";
    private final static String COLUMNDATA_TAG = "column";
    private final static String COLUMN_TAG = "field";
    private final static String FIELD_TAG = "field";
    private final static String REFERENCE_TAG = "Reference";
    private final static String REFERENCE_LIST_TAG = "ReferenceList";
    private final static String REFERENCE_TABLE_TAG = "ReferenceTable";
	//private final static String ELEMENT_TAG = "Element name";
    private final static String ATTRIB_TAG = "attrib";
    private final static String TAB_TAG = "tab";
    private final static String COMMIT_WARNING_TAG = "commitWarning";
    private final static String TRANSLATION_TAG = "translation"; //@Trifon
    private final static String TRANSLATION_NAME_TAG = "Name"; //@Trifon
    private final static String TRANSLATION_DESCRIPTION_TAG = "Description"; //@Trifon
    private final static String TRANSLATION_HELP_TAG = "Help"; //@Trifon
    private final static String PROCESS_TAG = "process"; //@Trifon
    private final static String PROCESS_PARA_TAG = "processpara"; //@Trifon
    private final static String REPORT_VIEW_TAG = "reportView"; //@Trifon
    private final static String WINDOW_TAG = "window"; // @Trifon
    private final static String COMPIERE_AD_TAG = "compiereAD"; // @Trifon
    private final static String DATABASE_TAG = "database"; // @Trifon
    private final static String MENU_TAG = "menu"; // @Trifon
    private final static String COMPIERE_DATA_TAG = "compieredata"; // @Trifon
    

//    private Logger log = Logger.getCLogger(getClass()); //@Trifon
	/**	Logger			*/
	public static CLogger	log = CLogger.getCLogger(XML2ADHandler.class); //@Trifon

    /** Used when an object inherit the name from the contained object   */
    private final String TEMP_NAME = "__TempName__";

    /**
     * 	Receive notification of the start of an element.
     *
     * 	@param uri namespace
     * 	@param localName simple name
     * 	@param qName qualified name
     * 	@param atts attributes
     * 	@throws org.xml.sax.SAXException
     */
	public void startElement (String uri, String localName, String qName, Attributes atts)
		throws org.xml.sax.SAXException {
    	
    	chracters = new StringBuffer();
    	
		// Check namespace.
		String elementValue = null;
		if ("".equals (uri))
		    elementValue = qName;
		else
		    elementValue = uri + localName;
		
	    log.entering("XML2ADHandler", "startElement", "elementValue=" + elementValue);
	
		// default element, compiereAD.
		if (elementValue.equals("default") && compiereAD) {
			doStartDefault_View(atts);
		}
		// the "field" element is used by me and druid, and I don't want change name, nor wrote 2 parser.
		else if (elementValue.equals(COMPIERE_AD_TAG)) {
		    doStartCompiereAD(atts);
		}
		// compieredata element. used in data.xml file.
		// some fields i.e. "table" are commons.
		else if (elementValue.equals(COMPIERE_DATA_TAG)) {
		    doStartCompiereData(atts);
		}
		// database element (Druid). Used in Model.xml and DruidSummary.xml
		else if (elementValue.equals(DATABASE_TAG)) {
		    druid = true;
		}
		// menu element.
		else if (elementValue.equals(MENU_TAG)) {
		    doStartMenu(atts);
		}
		// window element.
		else if (elementValue.equals(WINDOW_TAG)) {
		    doStartWindow(atts);
		}
		// tab element.
		else if (elementValue.equals(TAB_TAG)) {
		    doStartTab(atts);
		}
		
		// tab element.
		else if (elementValue.equals(COMMIT_WARNING_TAG)) {
		    doStartCommitWarning(atts);
		}
		
		// field element.
		else if (elementValue.equals(FIELD_TAG) && compiereAD) {
		    doStartField_View(atts);
		}
		// process element.
		else if (elementValue.equals(PROCESS_TAG)) {
		    doStartProcess(atts);
		}
	
		// processpara element.
		else if (elementValue.equals(PROCESS_PARA_TAG)) {
		    doStartProcessPara(atts);
		}
		
		// Report View element.
		else if (elementValue.equals(REPORT_VIEW_TAG)) {
		    doStartReportView(atts);
		}
	
		// table element.
		else if (elementValue.equals(TABLE_TAG) && druid) {
		    doStartTable_Model(atts);
		}
	
		// column element.
		else if (elementValue.equals(COLUMN_TAG) && druid) {
		    doStartColumn_Model(atts);
		} 
		// attrib element.
		// TODO: I add Reference and Element name on druid but in fact they are not Model but View.
		else if (elementValue.equals(ATTRIB_TAG) && m_translationLanguage == null) {
		    doStartAttrib(atts);
		}
		
		else if (elementValue.equals(TRANSLATION_TAG)) {
			doStartTranslation(atts);
		}
		
		else if (elementValue.equals(ATTRIB_TAG) && m_translationLanguage != null) {
		    doStartTranslationAttrib(atts);
		}
		
		/* ****************************************
		   compieredata Handler.
		   **************************************** */
		// table element, compieredata
		else if (elementValue.equals(TABLEDATA_TAG) && compieredata) {
		    d_tablename = atts.getValue("tablename");
	    	log.info("======================================");
	    	log.info("tabledata name: " + d_tablename);
		}
		// row element, compieredata
		else if (elementValue.equals(ROWDATA_TAG) && compieredata) {
		    doStartRow_Data(atts);
		}
		// DEFAULT column element, compieredata
		else if (isDefaultData && elementValue.equals(COLUMNDATA_TAG) && compieredata) {
		    // defaults for current table.
		    HashMap thisDefault = (HashMap)defaults.get(d_tablename);
		    if (thisDefault == null) {
		    	thisDefault = new HashMap();  // do not exist, CREATE.
	    		log.info("New HashMap for " + d_tablename);
		    }
		    ArrayList thisValue = new ArrayList(3);
		    thisValue.add(atts.getValue("name"));
		    thisValue.add(atts.getValue("value"));
		    thisValue.add(atts.getValue("class"));
		    // store default for this column.
		    thisDefault.put(atts.getValue("name"), thisValue);
		    // store back defaults for current table.
		    defaults.put(d_tablename, thisDefault);
		}
		// column element, compieredata
		else if (elementValue.equals(COLUMNDATA_TAG) && compieredata) {
		    doStartColumn_Data(atts);
		}
		// REFERENCE element; @Trifon used to define/modify existing Reference;
		// TODO - Reference
		//else if (elementValue.equals(REFERENCE_TAG) && compiereAD) {
		else if (elementValue.equals(REFERENCE_TAG)) {
			doStartReference_Model(atts);
		} 
		// TODO - Reference List
		//else if (elementValue.equals(REFERENCE_LIST_TAG) && compiereAD) {
		else if (elementValue.equals(REFERENCE_LIST_TAG)) {
			doStartReferenceList_Model(atts);
			//AD_Reference List
		}
		
		// TODO - Reference Table
		// else if (elementValue.equals(REFERENCE_TABLE_TAG) && compiereAD) {
		else if (elementValue.equals(REFERENCE_TABLE_TAG)) {
			doStartReferenceTable_Model(atts);
			//AD_Reference Table
		}
	
		// default element, compieredata
		if (elementValue.equals("default") && compieredata) {
		    isDefaultData = true;
		}
    }   // startElement

    /**
	 * @param atts
	 */
	private void doStartReferenceTable_Model(Attributes atts) {
		/*
key CDATA #IMPLIED           --> AD_Column_Key
table CDATA #IMPLIED         --> AD_Table_TableName
display CDATA #IMPLIED       --> AD_Column_Display
isValueDisplayed             --> 
whereClause CDATA #IMPLIED   --> 
orderByClause CDATA #IMPLIED --> 
entityType CDATA #IMPLIED    -->
isActive                     --> isActive

AD_REFERENCE_ID		NUMBER		10		0		Not Null	false	2		
AD_KEY	    	AD_Column.AD_Column_ID	NUMBER		10		0		Not Null	false	2
D_TABLE_ID			NUMBER		10		0		Not Null	false	2		
AD_DISPLAY		AD_Column.AD_Column_ID	NUMBER		10		0		Not Null	false	2	
ISVALUEDISPLAYED	CHAR		1		0		Not Null	false	1	
WHERECLAUSE			VARCHAR2	2000	0		Nullable	false	12	
ORDERBYCLAUSE		VARCHAR2	2000	0		Nullable	false	12	
ENTITYTYPE			VARCHAR2	4		0		Not Null	false	12
		 */
		
		String AD_Column_Key         = atts.getValue("key");
		int    AD_Column_Key_ID      = 0;
		String AD_Table_TableName    = atts.getValue("table");
		int    AD_Table_ID           = 0;
		String AD_Column_Display     = atts.getValue("display");
		int    AD_Column_Display_ID  = 0;
		String isValueDisplayed      = atts.getValue("isValueDisplayed");
		String whereClause           = atts.getValue("whereClause");
		String orderByClause         = atts.getValue("orderByClause");
		String entityType            = atts.getValue("entityType");
		String isActive              = atts.getValue("isActive");
		
		
		
		if (AD_Column_Key != null && !"".equals(AD_Column_Key) 
				&& AD_Table_TableName != null && !"".equals(AD_Table_TableName)
				
		) {
			//-----------------------------
			//int id = 0;
			String sql = "SELECT * \n"
					   + " FROM AD_Ref_Table \n"
					   + " WHERE AD_Reference_ID = " + m_Reference.get_ID();
			System.out.println("SQL = " + sql);
			try {
			    PreparedStatement pstmt = DB.prepareStatement(sql, null);
			    ResultSet rs = pstmt.executeQuery();
			    X_AD_Ref_Table refTable = null;
			    if ( rs.next() ) {
			    	// there is record .. 
			    	refTable = new X_AD_Ref_Table(Env.getCtx(), rs, null);			    	
			    } else {
			    	// Create new ...
			    	refTable = new X_AD_Ref_Table(Env.getCtx(), null, null);
			    	refTable.setAD_Reference_ID(m_Reference.get_ID());
			    	//refTable.save();
			    }
				
				
				AD_Column_Key_ID     = XMLHelper.getIDWithColumn("AD_Column", "ColumnName", AD_Column_Key, m_AD_Client_ID);
				AD_Table_ID          = XMLHelper.getIDWithColumn("AD_Table", "TableName", AD_Table_TableName, m_AD_Client_ID);
				AD_Column_Display_ID = XMLHelper.getIDWithColumn("AD_Column", "ColumnName", AD_Column_Display, m_AD_Client_ID);
				
				if (AD_Column_Key_ID != 0 
						&& AD_Table_ID !=0 
						&& AD_Column_Display_ID != 0
				) {
					refTable.setAD_Table_ID(AD_Table_ID);
					refTable.setAD_Key(AD_Column_Key_ID);
					refTable.setAD_Display(AD_Column_Display_ID);

					if (isValueDisplayed!= null  && !"".equals(isValueDisplayed)) 
					{
						boolean is = true;
						if ("N".equals(isValueDisplayed)) {
							is = false;
						}
						refTable.setIsValueDisplayed(is);
					}
					
					if (whereClause!= null && !"".equals(whereClause)) {
						refTable.setWhereClause(whereClause);
					}
					
					if (orderByClause!= null && !"".equals(orderByClause)) {
						refTable.setOrderByClause(orderByClause);
					}
					
					if (entityType!= null && !"".equals(entityType)) {
						String entityTypeValue = XMLHelper.reverseReference("_Entity Type", entityType);
			    		if (entityTypeValue != null) {
			    			refTable.setEntityType(entityTypeValue);
			    		} else {
			    			// Set Default entity type
			    			refTable.setEntityType("U");
			    		}
					}
					
					if (isActive!= null  && !"".equals(isActive)) 
					{
						boolean isActiveBoolean = true;
						if ("N".equals(isActive)) {
							isActiveBoolean = false;
						}
						refTable.setIsActive(isActiveBoolean);
					}

					if (refTable.save()) {
						log.info("AD_Ref_Table saved!");
					} else {
						log.severe("ERROR while saving Ref_Table");
					}					
				}
				
			    rs.close();
			    pstmt.close();
			    pstmt = null;
			}
			catch (Exception e) {
				log.log(Level.SEVERE, "" + e);
			}
			//-----------------------------

		}		
	}

    /**
	 * @param atts
	 */
	private void doStartReferenceList_Model(Attributes atts) {
		isRefList = true;
		
		String value       = atts.getValue("value");
		String name        = atts.getValue("name");
		String isActive    = atts.getValue("isActive");
		String description = atts.getValue("description");
		String entityType  = atts.getValue("entityType");
		
		
		if (value != null && !"".equals(value)) {
			m_RefList = MRefList.get (Env.getCtx(), m_Reference.getAD_Reference_ID(), value, null);
			if (m_RefList == null || m_RefList.getAD_Ref_List_ID() == 0) {
				m_RefList = new MRefList (Env.getCtx(), 0, null);
				m_RefList.setAD_Reference_ID(m_Reference.getAD_Reference_ID());
				m_RefList.setValue(value);
			}
			
			if (name!= null && !"".equals(name)) {
				m_RefList.setName(name);
			}
			if (isActive!= null  && !"".equals(isActive)) 
			{
				boolean isActiveBoolean = true;
				if ("N".equals(isActive)) {
					isActiveBoolean = false;
				}
				m_RefList.setIsActive(isActiveBoolean);
			}
			if (description!= null && !"".equals(description)) {
				m_RefList.setDescription(description);
			}
			if (entityType!= null && !"".equals(entityType)) {
				String entityTypeValue = XMLHelper.reverseReference("_Entity Type", entityType);
	    		if (entityTypeValue != null) {
	    			m_RefList.setEntityType(entityTypeValue);
	    		} else {
	    			// Set Default entity type
	    			m_RefList.setEntityType("U");
	    		}
			}
			
			if (m_RefList.save()) {
				log.info("AD_Ref_List saved!");
			} else {
				log.severe("ERROR while saving Ref_List");
			}
		}		
	}

	/**
	 * @param atts
	 */
	private void doStartReference_Model(Attributes atts) {
		int AD_Reference_ID = 0;
		String name           = atts.getValue("name");
		String description    = atts.getValue("description");
		String help           = atts.getValue("help");
		String validationType = atts.getValue("validationType");
		String entityType     = atts.getValue("entityType");
		String vFormat        = atts.getValue("vFormat");
		
    	log.info("Reference name:" + name);
	    if (name != null && !"".equals(name)) {
	    	AD_Reference_ID = XMLHelper.getIDbyName("AD_Reference", name, null);
		    m_Reference = new X_AD_Reference(Env.getCtx(), AD_Reference_ID, null);
		    if (m_Reference.getAD_Reference_ID() == 0) {
		    	// Create new Reference
		    	m_Reference.setName(name);
		    	//Set Entity Type
		    	if (entityType != null && !"".equals(entityType)) {
		    		String entityTypeValue = XMLHelper.reverseReference("_Entity Type", entityType);
		    		if (entityTypeValue != null) {
		    			m_Reference.setEntityType(entityTypeValue);
		    		} else {
		    			// Set Default entity type
		    			m_Reference.setEntityType("U");
		    		}
		    	} else {
		    		// Set Default entity type
		    		m_Reference.setEntityType("U");
		    	}
		    } 
		    
	    	if (description != null && !"".equals(description)) {
	    		m_Reference.setDescription(description);		    		
	    	}
	    	if (help != null && !"".equals(help)) {
	    		m_Reference.setHelp(help);
	    	}
	    	if (entityType != null && !"".equals(entityType)) {
	    		String entityTypeValue = XMLHelper.reverseReference("_Entity Type", entityType);
	    		if (entityTypeValue != null) {
	    			m_Reference.setEntityType(entityTypeValue);
	    		}
	    	}
	    	if (vFormat != null && !"".equals(vFormat)) {
	    		m_Reference.setVFormat(vFormat);
	    	}
	    	if (validationType != null && !"".equals(validationType)) {
	    		m_Reference.setValidationType(XMLHelper.reverseReference ("AD_Reference Validation Types", validationType));
	    	}
	    	
		    m_Reference.save();
	    }
	}

	/**
	 * @param atts
	 */
	private void doStartColumn_Data(Attributes atts) {
		String value = atts.getValue("value");
		String name = atts.getValue("name");
		String attClass = atts.getValue("class");
		
		if (value != null && !"".equals(value.trim())) {
			if (attClass == null || attClass.equals("String")) {
		    	log.info("value to set: is string");
			    genericPO.setValue(name, value);
			}
			else if (attClass.equals("Integer")) {
				log.info("value to set: is int");
			    genericPO.setValue(name, Integer.valueOf(value));
			}
			else if (attClass.equals("Boolean")) {
		    	log.info("value to set: is bool");
			    genericPO.setValue(name, new Boolean(value.equals("true") ? true : false));
			}
			// @Trifon - TODO add support for Date
			else if (attClass.equals("Date")) {
				String dateFormat = atts.getValue("dateFormat");
				if (dateFormat == null || "".equals(dateFormat) ) {
					dateFormat = "mm/dd/yyyy";
				}
		    	log.info("value to set: is date");
		    	genericPO.setValue(name, parseDate (value, dateFormat));
			}
			// @Trifon
			else if (attClass.equals("BigDecimal")) {
		    	log.info("value to set: is Double");
		    	genericPO.setValue(name, new BigDecimal(value));
				
			}
	    }
	    else if (atts.getValue("lookupname") != null && !"".equals(atts.getValue("lookupname").trim())) {
			String m_tablename = name.substring(0, name.length()-3);
			log.info("Tablename for lookup by Name:" + m_tablename);
			log.info("Name                        =" + atts.getValue("lookupname"));
			String clientName = atts.getValue("clientname");
			genericPO.setValue(name, new Integer(XMLHelper.getIDbyName(m_tablename, atts.getValue("lookupname"), clientName)));
			
	    } else if (atts.getValue("lookupvalue") != null && !"".equals(atts.getValue("lookupvalue").trim())) {
			String m_tablename = name.substring(0, name.length()-3);
			log.info("Tablename for lookup by Value:" + m_tablename);
			log.info("Value                        =" + atts.getValue("lookupvalue"));
			genericPO.setValue(name, new Integer(XMLHelper.getIDWithColumn (m_tablename, "Value", atts.getValue("lookupvalue"), m_AD_Client_ID)));
			
	    } else if (atts.getValue("lookupcustom") != null && !"".equals(atts.getValue("lookupcustom").trim())) {
			String lookupcustom = atts.getValue("lookupcustom");
	    	String m_tableName = atts.getValue("lookupcustom_table");
			if (m_tableName == null) {
				m_tableName = atts.getValue("name").substring(0, atts.getValue("name").length()-3);
			}
			String column = atts.getValue("lookupcustom_col");
			String tableNameMaster = atts.getValue("tableNameMaster"); 
		    String masterColumn = atts.getValue("masterColumn");
		    String masterValue = atts.getValue("masterValue");
		    String where = atts.getValue("Where");
		    	
			log.info("           name for lookup by Custom column:" + lookupcustom);
			log.info("      tableName for lookup by Custom column:" + m_tableName);
			log.info("     columnName for lookup by Custom column:" + column);
			log.info("          Where for lookup by Custom column:" + where);
			log.info("tableNameMaster for lookup by Custom column:" + tableNameMaster);
			log.info("   masterColumn for lookup by Custom column:" + masterColumn);
			log.info("    masterValue for lookup by Custom column:" + masterValue);

			if (tableNameMaster != null && !"".equals(tableNameMaster) &&
				masterColumn != null && !"".equals(masterColumn) &&
				masterValue != null && !"".equals(masterValue)
			) {
				genericPO.setValue(atts.getValue("name"), new Integer(getIDWithMasterColumnAndWhere (m_tableName, column, lookupcustom, tableNameMaster, masterColumn, masterValue)));
				log.info("==========================AD_ImpFormat_ID:" + getIDWithMasterColumnAndWhere (m_tableName, column, lookupcustom, tableNameMaster, masterColumn, masterValue));
			} else if (where != null && !"".equals(where.trim())) {
				genericPO.setValue(atts.getValue("name"), new Integer(getIDWithColumnAndWhere(m_tableName, column, lookupcustom, where)));
			} else {
				genericPO.setValue(atts.getValue("name"), new Integer(XMLHelper.getIDWithColumn(m_tableName, column, lookupcustom, m_AD_Client_ID)));
			}
			//(  tableName,   columnName,    name, tableNameMaster, masterColumn, masterValue)
			//("AD_Column", "ColumnName", "SeqNo",      "AD_Table",  "TableName", "I_ImpFormat")
		    //<column name="AD_Column_ID" lookupcustom="Name" lookupcustom_table="AD_Column" lookupcustom_col="ColumnName" tableNameMaster="AD_Table" masterColumn="TableName" masterValue="I_ImpFormat" />
		    //<!--                                      name,                     tableName,                   columnName,           tableNameMaster,            masterColumn,      masterValue -->

	    } else if (atts.getValue("lookup_ref_list") != null && !"".equals(atts.getValue("lookup_ref_list"))) {
			String ref_List_Name = atts.getValue("lookup_ref_list");
			String reference_Name = atts.getValue("ref_name");
			log.info("Reference Name for lookup by ref_list:" + ref_List_Name);
			genericPO.setValue(atts.getValue("name"), getValueFromRefList ( ref_List_Name, reference_Name));
			
	    } else if (atts.getValue("lookup_ref_table") != null && !"".equals(atts.getValue("lookup_ref_table"))) {
		/*
	    	String m_tablename = atts.getValue("lookup_ref_table");
			if (m_tablename == null) {
				m_tablename = atts.getValue("name").substring(0, atts.getValue("name").length()-3);
			}
			if (DEBUG) 
				log.info("tablename for lookup by Custom column:" + m_tablename);
			genericPO.setValue(atts.getValue("name"), getValueFromRefTable());
*/			
	    }
	}

	/**
	 * @param atts
	 */
	private void doStartRow_Data(Attributes atts) {
		d_rowname = atts.getValue("name");
	    log.info("row Name:" + d_rowname);
	    System.out.println("----- row Name:" + d_rowname);
	    
	    String rowValue = atts.getValue("value");
	    log.info("row Value:" + rowValue);
	    System.out.println("----- row Value:" + rowValue);
	    
	    Properties ctx = Env.getCtx();
	    //ctx.setProperty("compieredataTable_ID", String.valueOf(getIDbyName("AD_Table", d_tablename))); // @Trifon - old one
	    ctx.setProperty("compieredataTable_ID", String.valueOf(XMLHelper.getIDWithColumn ("AD_Table", "TableName", d_tablename, m_AD_Client_ID)));
	    log.info("compieredataTable_ID setted:" + XMLHelper.getIDWithColumn ("AD_Table", "TableName", d_tablename, m_AD_Client_ID));
	    // name can be null if there are keyXname attributes.
	    if (d_rowname != null && atts.getValue("key1name") == null) {
	    	genericPO = new GenericPO(Env.getCtx(), XMLHelper.getIDbyName(d_tablename, d_rowname, null));
	    // keyXname and lookupkeyXname.
	    } else {
			String sql = "SELECT * FROM " + d_tablename;
			String whereAnd = " WHERE";
			if (d_rowname != null && !"".equals(d_rowname.trim())) {
				whereAnd = whereAnd + " Name='" + d_rowname + "' AND ";
			}
			if (rowValue != null && !"".equals(rowValue.trim())) {
				whereAnd = whereAnd + " Value='" + rowValue + "' AND ";
			}
			String t_tablename = null;
			
			String CURRENT_KEY = "key1name";
			if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
				t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
				if (atts.getValue("key1Where") != null && !"".equals(atts.getValue("key1Where"))) {
					if (atts.getValue("key1SearchBy") != null && !"".equals(atts.getValue("key1SearchBy"))) {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDWithColumnAndWhere(t_tablename, atts.getValue("key1SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key1Where"));
					} else {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key1Where"));
					}
				} else {
					sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null);
				}
			    whereAnd = " AND";
			}
			CURRENT_KEY = "key2name";
			if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
			    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
			    if (atts.getValue("key2Where") != null && !"".equals(atts.getValue("key2Where"))) {
			    	if (atts.getValue("key2SearchBy") != null && !"".equals(atts.getValue("key2SearchBy"))) {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDWithColumnAndWhere(t_tablename, atts.getValue("key2SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key2Where"));
					} else {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key2Where"));	
					}
				} else {
					sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null);
				}
			    whereAnd = " AND";
			}
			CURRENT_KEY = "key3name";
			if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
			    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
			    if (atts.getValue("key3Where") != null && !"".equals(atts.getValue("key3Where"))) {
			    	if (atts.getValue("key3SearchBy") != null && !"".equals(atts.getValue("key3SearchBy"))) {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDWithColumnAndWhere(t_tablename, atts.getValue("key3SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key3Where"));
					} else {
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key3Where"));	
					}
				} else {
					sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null);
				}
			    whereAnd = " AND";
			}
			CURRENT_KEY = "key4name";
			if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
			    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
			    System.out.println("----- atts.getValue(key4Where):" + atts.getValue("key4Where"));
			    System.out.println("----- atts.getValue(key4SearchBy):" + atts.getValue("key4SearchBy"));
			    
			    if (atts.getValue("key4Where") != null && !"".equals(atts.getValue("key4Where").trim())) {
			    	System.out.println("----- Where is not NULL");
			    	if (atts.getValue("key4SearchBy") != null && !"".equals(atts.getValue("key4SearchBy").trim())) {
			    		System.out.println("----- key4SearchBy is not NULL");
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDWithColumnAndWhere(t_tablename, atts.getValue("key4SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key4Where"));
					} else {
						System.out.println("----- key4SearchBy is NULL");
						sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key4Where"));	
					}
				} else {
					System.out.println("----- key4Where is NULL");
					sql = sql+whereAnd+" "+atts.getValue(CURRENT_KEY)+"="+XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null);
				}
			    whereAnd = " AND";
			}
		    log.info("keyXname sql:"+sql);
			// Load GenericPO from rs, in fact ID could not exist e.g. Attribute Value
			try {
			    PreparedStatement pstmt = DB.prepareStatement(sql, null);
			    ResultSet rs = pstmt.executeQuery();
			    if (rs.next()) {
		    		log.info("init GenericPo from rs.");
					genericPO = new GenericPO(Env.getCtx(), rs);
			    } else {
		    		log.info("new GenericPo.");
			    	genericPO = new GenericPO(Env.getCtx(), 0);
			    	
			    	if (rowValue != null) {
			    		genericPO.setValueNoCheck("Value", rowValue);
			    	}
			    	// set keyXname.
			    	CURRENT_KEY = "key1name";
					if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
					    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
					    Integer id = null;
					    if (atts.getValue("key1Where") != null && !"".equals(atts.getValue("key1Where"))) {
					    	if (atts.getValue("key1SearchBy") != null && !"".equals(atts.getValue("key1SearchBy").trim())) {
								id = new Integer(getIDWithColumnAndWhere(t_tablename, atts.getValue("key1SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key1Where")));
							} else {
								id = new Integer(getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key1Where")));	
							}
						} else {
							id = new Integer(XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null));
						}
					    genericPO.setValueNoCheck(atts.getValue(CURRENT_KEY), id);
					}
					CURRENT_KEY = "key2name";
					if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
					    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
					    Integer id = null;
					    if (atts.getValue("key2Where") != null && !"".equals(atts.getValue("key2Where"))) {
					    	if (atts.getValue("key2SearchBy") != null && !"".equals(atts.getValue("key2SearchBy").trim())) {
								id = new Integer(getIDWithColumnAndWhere(t_tablename, atts.getValue("key2SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key2Where")));
							} else {
								id = new Integer(getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key2Where")));	
							}
						} else {
							id = new Integer(XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null));
						}
					    genericPO.setValueNoCheck(atts.getValue(CURRENT_KEY), id);
								      
					}
					CURRENT_KEY = "key3name";
					if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
					    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
					    Integer id = null;
					    if (atts.getValue("key3Where") != null && !"".equals(atts.getValue("key3Where"))) {
					    	if (atts.getValue("key3SearchBy") != null && !"".equals(atts.getValue("key3SearchBy").trim())) {
								id = new Integer(getIDWithColumnAndWhere(t_tablename, atts.getValue("key3SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key3Where")));
							} else {
								id = new Integer(getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key3Where")));	
							}
						} else {
							id = new Integer(XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null));
						}
					    genericPO.setValueNoCheck(atts.getValue(CURRENT_KEY), id);
					}
					CURRENT_KEY = "key4name";
					if (atts.getValue(CURRENT_KEY) != null && !"".equals(atts.getValue(CURRENT_KEY))) {
					    t_tablename = atts.getValue(CURRENT_KEY).substring(0, atts.getValue(CURRENT_KEY).length()-3);
					    Integer id = null;
					    if (atts.getValue("key4Where") != null && !"".equals(atts.getValue("key4Where"))) {
					    	if (atts.getValue("key4SearchBy") != null && !"".equals(atts.getValue("key4SearchBy").trim())) {
								id = new Integer(getIDWithColumnAndWhere(t_tablename, atts.getValue("key4SearchBy"), atts.getValue("lookup"+CURRENT_KEY), atts.getValue("key4Where")));
							} else {
								id = new Integer(getIDbyNameAndWhere(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null, atts.getValue("key4Where")));	
							}
						} else {
							id = new Integer(XMLHelper.getIDbyName(t_tablename, atts.getValue("lookup"+CURRENT_KEY), null));
						}
					    genericPO.setValueNoCheck(atts.getValue(CURRENT_KEY), id);
					}

			    }
			    rs.close();
			    pstmt.close();
			    pstmt = null;
			}
			catch (Exception e) {
				log.log(Level.SEVERE, "keyXname attribute. init from rs error."+e);
			}
	    }
	    // reset Table ID for GenericPO.
	    // TODO  Trifon why this is set to '0'?
	    //ctx.setProperty("compieredataTable_ID", "0");
	    // for debug GenericPO.
	    if (false) {
			//POInfo poInfo = POInfo.getPOInfo(Env.getCtx(), getIDbyName("AD_Table", d_tablename)); //@Trifon
			POInfo poInfo = POInfo.getPOInfo(Env.getCtx(), XMLHelper.getIDWithColumn ("AD_Table", "TableName", d_tablename, m_AD_Client_ID));//Trifon
			if (poInfo == null)
			    log.info("poInfo is null.");
			for (int i = 0; i < poInfo.getColumnCount(); i++) {
			    log.info(d_tablename+" column: "+poInfo.getColumnName(i));
			}
	    }
	    // if new. TODO: no defaults for keyXname.
	    if (d_rowname != null && ((Integer)(genericPO.get_Value(d_tablename+"_ID"))).intValue() == 0) {
			log.info("new genericPO, name:"+d_rowname);
			genericPO.setValue("Name", d_rowname);
			// Set defaults.
			HashMap thisDefault = (HashMap)defaults.get(d_tablename);
			if (thisDefault != null) {
			    Iterator iter = thisDefault.values().iterator();
			    ArrayList thisValue = null;
			    while (iter.hasNext()) {
			    	thisValue = (ArrayList)iter.next();
			    	if (((String)(thisValue.get(2))).equals("String"))
			    		genericPO.setValue((String)thisValue.get(0), (String)thisValue.get(1));
			    	else if (((String)(thisValue.get(2))).equals("Integer"))
			    		genericPO.setValue((String)thisValue.get(0), Integer.valueOf((String)thisValue.get(1)));
			    	else if (((String)(thisValue.get(2))).equals("Boolean"))
			    		genericPO.setValue((String)thisValue.get(0), new Boolean(((String)thisValue.get(1)).equals("true") ? true : false));
			    	else if (((String)(thisValue.get(2))).equals("BigDecimal"))
			    		genericPO.setValue((String)thisValue.get(0), new BigDecimal((String)thisValue.get(1)));
			    }
			}
	    }
	    else {
	    	//log.info("Generic ID is: "+genericPO.get_Value(d_tablename+"_ID"));
	    }
	}

	/**
	 * @param atts
	 */
	private void doStartAttrib(Attributes atts) {
		String name = atts.getValue("name");
		String value = atts.getValue("value");

	    if (name != null) {
			if (name.equals("Name")) {
			    m_Column.setName(value);
			} else if (name.equals("PrKey")) {
				m_Column.setIsKey(true);
			} else if (name.equals("Callout")) {
			    m_Column.setCallout(value);
			} else if (name.equals("Description")) {
			    m_Column.setDescription(value);
			} else if (name.equals("ColumnSQL")) {
			    m_Column.setColumnSQL(value);
			} else if (name.equals("IsMandatory")) {
			    m_Column.setIsMandatory("Y".equals(value) ? true : false);
			} else if (name.equals("IsUpdateable")) {
				m_Column.setIsUpdateable("Y".equals(value) ? true : false);
			} else if (name.equals("IsEncrypted")) {
				m_Column.setIsEncrypted(value);
			} else if (name.equals("IsAlwaysUpdateable")) {
				m_Column.setIsAlwaysUpdateable("Y".equals(value) ? true : false);
			} else if (name.equals("IsIdentifier")) {
			    m_Column.setIsIdentifier("Y".equals(value) ? true : false);
			} else if (name.equals("NotN")) {
			    m_Column.setIsMandatory(true);
			} else if (name.equals("Def") || name.equals("DefaultValue")) { // @Trifon
			    m_Column.setDefaultValue(value); // @Trifon
			} else if (name.equals("FieldLength")) { // @Trifon
			    m_Column.setFieldLength(Integer.parseInt(value)); // @Trifon
			} else if (name.equals("Parent") || name.equals("IsParent")) { // @Rasmus Kl�rke
				m_Column.setIsParent(true); // @Rasmus Kl�rke
				if (value != null) {
					m_Column.setIsParent("Y".equals(value) ? true : false); // @Trifon
				}
			} else if (name.equals("Process")) { //@Rasmus Kl�rke
			    //m_Column.setAD_Process_ID(getIDbyName("AD_Process", value, null)); // @Trifon
			    m_Column.setAD_Process_ID(XMLHelper.getIDWithColumn("AD_Process", "Value", value, m_AD_Client_ID));
			} else if (name.equals("Reference")) {
			    m_Column.setAD_Reference_ID(XMLHelper.getIDbyName("AD_Reference", value, null));
			} else if (name.equals("Reference Value")) {
			    m_Column.setAD_Reference_Value_ID(XMLHelper.getIDbyName("AD_Reference", value, null));
			} else if (name.equals("Element name")) {
			    X_AD_Element m_Element = new X_AD_Element(Env.getCtx(), XMLHelper.getIDWithColumn("AD_Element", "ColumnName", m_Column.getColumnName(), m_AD_Client_ID), null);
			    if (m_Element.getAD_Element_ID() == 0) {
					m_Element.setColumnName(m_Column.getColumnName());
					m_Element.setEntityType(m_EntityType);
				    m_Element.setName(value);
				    m_Element.setPrintName(value);
				    m_Element.save();
			    }
			    // @Trifon; I do not want to overrwrite already existing element.
			    //m_Element.setName(atts.getValue("value"));
			    //m_Element.setPrintName(atts.getValue("value"));
			    //m_Element.save();
			    m_Column.setAD_Element_ID(m_Element.getAD_Element_ID());
			} else if (name.equals("Dynamic Validation")) {
				// @Trifon
				X_AD_Val_Rule m_valRule = new X_AD_Val_Rule(Env.getCtx(), XMLHelper.getIDbyName("AD_Val_Rule", value, null), null);
			    if (m_valRule.getAD_Val_Rule_ID() == 0) {
			    	m_valRule.setEntityType(m_EntityType); // TODO - could be taken from attribute
			    	m_valRule.setName(value);
			    	//m_valRule.setDescription(value); // TODO this could be taken from attributes 
			    	m_valRule.setType("S"); // TODO this could be taken from attributes
			    	// S = SQL; J = Java Language; E = Java Script
			    }
			    String code = atts.getValue("code");
			    
			    if (code != null) {
			    	m_valRule.setCode(code);
			    }
			    
			    m_valRule.save();
			    m_Column.setAD_Val_Rule_ID(m_valRule.getAD_Val_Rule_ID());
			} else if (name.equals("VFormat")) {
				m_Column.setVFormat(value);
			} else if (name.equals("ReadOnlyLogic")) {
				m_Column.setReadOnlyLogic(value);
			}
	    }
	}

	/*
	 * 
<translation language="ru_RU" trl="N" >
	<attrib name="Name">????????</attrib>
	<attrib name="Description">???????????????????</attrib>
	<attrib name="Help">?????????????????????????????????</attrib>
</translation>
	 */
	private void doStartTranslation(Attributes atts) {
		if (m_Field != null) {
			isFieldTranslation = true;
		}
		
		if (m_Reference != null) {
			isReferenceTranslation = true;
		}
	    
	    if (m_RefList != null) {
	    	isReferenceListTranslation = true;
	    }
		String language = atts.getValue("language");
		
		if (language != null && !"".equals(language)) {
			// lokup language by AD_Language column
			m_translationLanguage = MLanguage.get(Env.getCtx(), language);
		}
		
		trl = atts.getValue("trl");
		
		if (trl == null || "".equals(trl.trim()) 
				|| !"Y".equals(trl) || !"N".equals(trl) ) {
			trl = "Y";
		}
		
		// translationIsActive
		translationIsActive = atts.getValue("IsActive");
		
		if (translationIsActive == null || "".equals(translationIsActive.trim()) 
				|| !"Y".equals(translationIsActive) || !"N".equals(translationIsActive) ) {
			translationIsActive = "Y";
		}
	}
	
	private void doStartTranslationAttrib(Attributes atts) {
		String name = atts.getValue("name");
		log.info("TranslationAttrib name=" + name);
		
		if (name != null && !"".equals(name)) {
			if ("Name".equals(name)) {
				translationName = null;
				isAttribName = true;
			} else if ("Description".equals(name)) {
				translationDescription = null;
				isAttribDescription = true;
			} else if ("Help".equals(name)) {
				translationHelp = null;
				isAttribHelp = true;
			}
		}
	}
	
	/**
	 * @param atts
	 */
	private void doStartColumn_Model(Attributes atts) {
		// Mandatory.
	    String columnName = atts.getValue("ColumnName");
	    
	    // Get/New window.
	    m_Column = new X_AD_Column(Env.getCtx(), XMLHelper.getIDWithMasterAndColumn("AD_Column", "ColumnName", columnName, "AD_Table", m_Table.getAD_Table_ID()), null);
	    if (m_Column.getAD_Column_ID() == 0) {
		    log.info("Column: " + columnName + " not found. CREATE.");
			m_Column.setName(columnName);
			m_Column.setVersion(Env.ZERO);
			m_Column.setEntityType(m_EntityType);
			m_Column.setColumnName(columnName);
			m_Column.setAD_Table_ID(m_Table.getAD_Table_ID());
			m_Column.setAD_Reference_ID(10);
			m_Column.setIsKey(false);
			m_Column.setIsParent(false);
			m_Column.setIsMandatory(false);
			m_Column.setIsUpdateable(true);
			m_Column.setIsIdentifier(false);
			m_Column.setSeqNo(m_ColumnSeqNo);
			m_ColumnSeqNo = m_ColumnSeqNo+10;
			m_Column.setIsTranslated(false);
			//m_Column.setIsEncrypted(false);
			m_Column.setIsEncrypted(X_AD_Column.ISENCRYPTED_NotEncrypted);
			m_Column.setIsSelectionColumn(false);
			m_Column.setIsAlwaysUpdateable(false);
	    } else {
    		log.info("Column: ["+columnName+"] FOUND.");
	    	// Set Entity Type or it won't be remove in future when you remove the Column.
	    	m_Column.setEntityType(m_EntityType);
	    }
	    // TODO: druid is configurable so this sqlType can be parameter.
	    if (atts.getValue("sqlType") != null) {
			if (atts.getValue("sqlType").startsWith("number") || atts.getValue("sqlType").startsWith("numeric")) {
			    m_Column.setAD_Reference_ID(XMLHelper.getIDbyName("AD_Reference", "Number", null));
			    m_Column.setFieldLength(22);
			}
			else if (atts.getValue("sqlType").toLowerCase().indexOf("char") != -1 && atts.getValue("sqlType").endsWith("(1)")) {
			    m_Column.setAD_Reference_ID(20 /*getID("AD_Reference", "YesNo")*/); // do not work with YesNo.
			    m_Column.setFieldLength(1);
			}
			else if (atts.getValue("sqlType").indexOf("char") != -1)
			    m_Column.setAD_Reference_ID(XMLHelper.getIDbyName("AD_Reference", "String", null));
			else if (atts.getValue("sqlType").indexOf("date") != -1 || atts.getValue("sqlType").indexOf("time") != -1) {
			    m_Column.setAD_Reference_ID(XMLHelper.getIDbyName("AD_Reference", "DateTime", null));
			    m_Column.setFieldLength(7);
			}
			// FieldLenght
			int i_s = atts.getValue("sqlType").indexOf("(");
			int i_e1 = atts.getValue("sqlType").indexOf(",");
			int i_e2 = atts.getValue("sqlType").indexOf(")");
			if (i_s != -1)
			    m_Column.setFieldLength(Integer.valueOf(atts.getValue("sqlType").substring(i_s+1, i_e1 != -1 ? i_e1 : i_e2)).intValue());
	    }
	    // Boring things that you will be happy to start forgetting about.
	    // AD_Client_ID
	    if (m_Column.getColumnName().toUpperCase().equals("AD_CLIENT_ID")) {
			m_Column.setAD_Reference_ID(19);
			m_Column.setAD_Val_Rule_ID(129); // @Trifon
			m_Column.setFieldLength(22);
			m_Column.setIsUpdateable(false);
			m_Column.setDefaultValue("@AD_Client_ID@");
	    }
	    // AD_Org_ID
	    else if (m_Column.getColumnName().toUpperCase().equals("AD_ORG_ID")) {
			m_Column.setAD_Reference_ID(19);
			m_Column.setAD_Val_Rule_ID(104);
			m_Column.setIsUpdateable(false);
			m_Column.setDefaultValue("@AD_Org_ID@");
			m_Column.setFieldLength(22);
	    }
	    // Created, Updated
	    else if (m_Column.getColumnName().toUpperCase().equals("CREATED") ||
		     m_Column.getColumnName().toUpperCase().equals("UPDATED")) {
	    	m_Column.setAD_Reference_ID(16);
	    	m_Column.setIsUpdateable(false);
	    }
	    // CreatedBy, UpdatedBY
	    else if (m_Column.getColumnName().toUpperCase().equals("CREATEDBY") ||
		     m_Column.getColumnName().toUpperCase().equals("UPDATEDBY")) {
	    	m_Column.setAD_Reference_ID(18);
	    	m_Column.setAD_Reference_Value_ID(110); // AD_User.
	    	m_Column.setIsUpdateable(false);
	    }
	    // ID
	    else if (m_Column.getColumnName().toUpperCase().equals(m_Table.getName().toUpperCase()+"_ID")) {
			m_Column.setAD_Reference_ID(13);
			m_Column.setIsUpdateable(false);
			m_Column.setIsKey(true);
			m_Column.setIsMandatory(true);
			m_Column.setFieldLength(22);
	    }
	    // Name
	    else if (m_Column.getColumnName().toUpperCase().equals("NAME")) {
	    	m_Column.setIsIdentifier(true); //@Trifon; this will make only confusions...
	    }
	    // FK
	    else if (m_Column.getColumnName().endsWith("_ID")) {
			//m_Column.setAD_Reference_ID(19); //@Trifon this is maintained now..
			//m_Column.setIsParent(false);
	    }
	    // Button
	    // TODO: convention for buttons ok?
	    else if (m_Column.getColumnName().endsWith("ING")) {
	    	//m_Column.setAD_Reference_ID(28); //@Trifon this is maintained now...
	    	//m_Column.setFieldLength(1);
	    }
	    
	    // Setup Element.
	    X_AD_Element element =
		new X_AD_Element(Env.getCtx(), XMLHelper.getIDWithColumn("AD_Element", "ColumnName", m_Column.getColumnName(), m_AD_Client_ID), null);
	    if (element.getAD_Element_ID() == 0) {
			element.setColumnName(m_Column.getColumnName());
			element.setEntityType(m_EntityType);
			element.setPrintName(m_Column.getColumnName());
			element.setName(m_Column.getColumnName());
			element.save();
	    }
	    m_Column.setAD_Element_ID(element.getAD_Element_ID());
	    
	    m_Column.save();
	    // This is to delete non existent column.
	    if (m_ColumnList.length() == 0)
	    	m_ColumnList = String.valueOf(m_Column.getAD_Column_ID());
	    else
	    	m_ColumnList = m_ColumnList+","+String.valueOf(m_Column.getAD_Column_ID());
	}

	/**
	 * @param atts
	 */
	private void doStartTable_Model(Attributes atts) {
		m_ColumnSeqNo = 10; // reset SeqNo.
	    // Mandatory.
	    String tableName     = atts.getValue("TableName"); //@Trifon; this is changed in new version of Druid;
	    String name          = atts.getValue("Name");      // @Trifon; added in new version of Druid
	    String window_Name   = atts.getValue("AD_Window_Name");
	    String client_Name   = atts.getValue("AD_Client_Name");
	    String val_Rule_Name = atts.getValue("AD_Val_Rule_Name");
	    String AD_Org_Name   = atts.getValue("AD_Org_Name");
	    String accessLevel   = atts.getValue("AccessLevel");
	    String isView        = atts.getValue("IsView"); 
	    
    	log.info(tableName + " starts ============================================");
	    // Get/New Table
	    m_Table = new X_AD_Table(Env.getCtx(), XMLHelper.getIDWithColumn ("AD_Table", "TableName", tableName, m_AD_Client_ID), null ); // @Trifon; new one
	    if (m_Table.getAD_Table_ID() == 0) {
		    log.info("Table: " + tableName + " NOT FOUND. CREATE new one.");
			m_Table.setEntityType(m_EntityType);
		    if (name == null || "".equals(name.trim())) {
		    	name = tableName;
		    }
			m_Table.setName(name);
			m_Table.setTableName(tableName);
			m_Table.setIsView(false);
			m_Table.setAccessLevel(XMLHelper.reverseReference("AD_Table Access Levels", "Client+Organization"));
			m_Table.setIsSecurityEnabled(false);
			m_Table.setIsDeleteable(true);
			m_Table.setIsHighVolume(false);
			m_Table.setIsChangeLog(false);
			m_Table.setReplicationType(XMLHelper.reverseReference("AD_Table Replication Type", "Local"));
			m_Table.save();
			
			// Create new record into AD_Sequence table! // @Trifon
			// Example: 
			//-- Name, Description, IsAutoSequence, IncrementNo, StartNo, CurrentNext, CurrentNextSys, IsAudited, IsTableID, StartNewYear
			//-- I_ImpFormat, I_ImpFormat, 'Y', 1, 1000000, 1000000, 1, 'N', 'Y', 'N'
			//-- I_ImpFormat_Row, I_ImpFormat_Row, 'Y', 1, 1000000, 1000000, 1, 'N', 'Y', 'N'

			//MSequence.createTableSequence (Env.getCtx(), m_Table.getTableName(), null);
			X_AD_Sequence m_Sequence = new X_AD_Sequence (Env.getCtx(), 0, null);
			//MSequence m_Sequence = new MSequence(Env.getCtx(), 0, null);
			//m_Sequence.setClientOrg(0, 0);
			m_Sequence.setName(m_Table.getTableName());
			m_Sequence.setDescription("Table " + m_Table.getTableName());
			m_Sequence.setIsAutoSequence(true);
			m_Sequence.setIncrementNo(1);
			m_Sequence.setStartNo(1000000);
			m_Sequence.setCurrentNext(1000000);
			m_Sequence.setCurrentNextSys(100);
			m_Sequence.setIsAudited(false);
			m_Sequence.setIsTableID(true);
			m_Sequence.setStartNewYear(false);
			
			m_Sequence.save();
			
	    } else {
    		log.info("Table: " + tableName + " found.");
	    }
	    String description = atts.getValue("Description");
	    if (description != null && !"".equals(description)) {
	    	m_Table.setDescription(description);
	    }
	    if (name != null && !"".equals(name.trim())) {
	    	m_Table.setName(name);
	    }
		if (accessLevel != null && !"".equals(accessLevel.trim())) {
			m_Table.setAccessLevel(XMLHelper.reverseReference("AD_Table Access Levels", accessLevel));
		}
		if (isView != null && !"".equals(isView.trim())) {
			if (isView.equals("Y")) {
				m_Table.setIsView(true); //@Trifon
	    	} else {
	    		m_Table.setIsView(false); //@Trifon
	    	}
		}
		
	    m_Table.save();
	}

	/**
	 * @param atts
	 */
	private void doStartField_View(Attributes atts) {
		// Initialize.
	    String name = atts.getValue("name");
	    String columnName = atts.getValue("columnname");
	    // Init the associated column.
	    if (columnName != null && !"".equals(columnName)) {
		    log.info("Field: " + name + ": init column.");
			m_Column = new X_AD_Column(Env.getCtx(), 
						   XMLHelper.getIDWithMasterAndColumn("AD_Column", "ColumnName", columnName
							    , "AD_Table", m_Tab[m_TabLevelNo].getAD_Table_ID()), null);
			log.info("Field: " + name + ": column [" + columnName + "]" + m_Column);
			//m_Field.setAD_Column_ID(m_Column.getAD_Column_ID());
	    } else {
	    	// no "columnname" so field should have a Column already.
	    	//m_Column = new X_AD_Column(Env.getCtx(), m_Field.getAD_Column_ID(), null); //@Trifon
	    	log.info("Field: "+name+" not found 'columnname' attribute ++++++++++++++++++++++++.");
	    }
	    
	    // name is mandatory.
	    if (name != null) {
	    	//m_Field = new X_AD_Field(Env.getCtx(), getIDWithMaster("AD_Field", name, "AD_Tab", m_Tab[m_TabLevelNo].getAD_Tab_ID()), null);
	    	//m_Field = new X_AD_Field(Env.getCtx(), getIDWithMasterAndColumn("AD_Field", "ColumnName", name, "AD_Tab", m_Tab[m_TabLevelNo].getAD_Tab_ID()), null); //@Trifon
	    	// Search for Field by Column!
	    	m_Field = new X_AD_Field(Env.getCtx(), getIDWithMasterColumnAnd2Where ("AD_Field", "AD_Tab_ID", m_Tab[m_TabLevelNo].getAD_Tab_ID(), "AD_Column", "ColumnName", columnName, "AD_Table_ID", m_Tab[m_TabLevelNo].getAD_Table_ID()), null); //@Trifon
//	    	                                       /getIDWithMasterColumnAnd2Where (tableName, columnName, String name,            String tableNameMaster, String masterColumn, String masterValue, String masterColumn2, String masterValue2)

			if (m_Field.getAD_Field_ID() == 0) {
		    	log.info("Field: "+name+" not found. CREATE.");
			    m_Field.setAD_Tab_ID(m_Tab[m_TabLevelNo].getAD_Tab_ID());
			    m_Field.setEntityType (m_EntityType);
			    m_Field.setIsCentrallyMaintained (true);
			    m_Field.setIsDisplayed (true);
			    m_Field.setIsEncrypted (false);
			    m_Field.setIsFieldOnly (false);
			    m_Field.setIsHeading (false);
			    m_Field.setIsReadOnly (false);
			    m_Field.setIsSameLine (false);
			    m_Field.setName(name);
		    	m_Field.setSeqNo(m_FieldSeqNo); //@Trifon
		    	m_FieldSeqNo = m_FieldSeqNo + 10; //@Trifon
		    	m_Field.setAD_Column_ID(m_Column.getAD_Column_ID());//@Trifon
		    	m_Field.save();
			} else {
		    	log.info("Field: "+name+" found.");
			    // Set Entity Type or it won't be removed in case you remove the Field.
			    m_Field.setEntityType (m_EntityType);
			}
			if (m_Field.getAD_Field_ID() != 0) { // always.
			    //
			    if (atts.getValue("mandatory") != null ) {
			    	if (atts.getValue("mandatory").equals("Y")) {
			    		m_Column.setIsMandatory(true);
			    	} else {
			    		m_Column.setIsMandatory(false); //@Trifon
			    	}
			    }
			    // @Trifon
			    // Update Field name!
			    m_Field.setName(name);
			    
			    //Below code added by @Trifon
			    if (atts.getValue("defaultValue") != null && !"".equals(atts.getValue("defaultValue"))) {
			    	m_Column.setDefaultValue(atts.getValue("defaultValue"));
			    }
			    if (atts.getValue("identifierno") != null) {
			    	m_Column.setIsIdentifier(true);
			    	m_Column.setSeqNo(Integer.valueOf(atts.getValue("identifierno")).intValue());
			    }
			    if (atts.getValue("seqNo") != null && !"".equals(atts.getValue("seqNo"))) { //@Trifon
			    	m_Field.setSeqNo(Integer.valueOf(atts.getValue("seqNo")).intValue()); //@Trifon
			    }
			    if (atts.getValue("displayLogic") != null) { //@Trifon
			    	m_Field.setDisplayLogic(atts.getValue("displayLogic"));
			    }
			    if (atts.getValue("isSameLine") != null) { //@Trifon
			    	if (atts.getValue("isSameLine").equals("Y")) {
			    		m_Field.setIsSameLine (true); //@Trifon
			    	} else {
			    		m_Field.setIsSameLine (false); //@Trifon
			    	}
			    }
			    if (atts.getValue("isDisplayed") != null) { //@Trifon
			    	if (atts.getValue("isDisplayed").equals("Y")) {
			    		m_Field.setIsDisplayed (true); //@Trifon
			    	} else {
			    		m_Field.setIsDisplayed (false); //@Trifon
			    	}
			    }
			    // 

			    if (atts.getValue("isReadOnly") != null) { //@Trifon
			    	if (atts.getValue("isReadOnly").equals("Y")) {
			    		m_Field.setIsReadOnly (true); //@Trifon
			    	} else {
			    		m_Field.setIsReadOnly (false); //@Trifon
			    	}
			    }
			    
			    // @Trifon
			    if (atts.getValue("FieldGroup") != null && !"".equals(atts.getValue("FieldGroup").trim())) {
				    m_Field.setAD_FieldGroup_ID(XMLHelper.getIDbyName("AD_FieldGroup", atts.getValue("FieldGroup"), null));
			    }
			    
			    //Below code added by @Trifon
			    String displayLength = atts.getValue("displayLength"); 
			    if (displayLength != null && !"".equals(displayLength) && !"null".equals(displayLength)) {
			    	try {
			    		int length = Integer.parseInt(displayLength);
			    		m_Field.setDisplayLength(length);
			    	} catch (NumberFormatException ex) {
					    log.severe("Unable to Parse 'displayLength' = [" + displayLength + "]");
			    		ex.printStackTrace();
			    	}
			    }
			    
			    m_Field.save(); // @Trifon
			    m_Column.save(); // @Trifon
			}
	    }
	}

	/**
	 * @param atts
	 */
	private void doStartDefault_View(Attributes atts) {
		String entityType = atts.getValue("entitytype");
		String firstDelete = atts.getValue("firstdelete");
		
		if (entityType != null) {
	    	m_EntityType = XMLHelper.reverseReference("_Entity Type", entityType);
    		log.finest("entitytype is: " + m_EntityType);
	    }
	    // TODO: a better policy to modify things than delete everything and reinsert.
	    if (firstDelete != null) {
	    	m_DeleteMode = firstDelete.equals("true") ? true : false;
	    	log.finest("firstdelete: " + m_DeleteMode);
			if (m_DeleteMode) {
			    // Delete menus.
			    String sql = "delete AD_Menu where EntityType='"+m_EntityType+"'";
			    int no = DB.executeUpdate(sql, null);
			    log.finest("Menus deleted:" + no);
			    
			    // Delete window
			    sql = "delete AD_Window where EntityType='"+m_EntityType+"'";
			    no = DB.executeUpdate(sql, null);
			    log.finest("Window deleted:"+no);
			    
			    // Delete process instances
			    sql = "delete AD_PInstance where AD_Process_ID in "
			    	+"(select AD_Process_ID from AD_Process where EntityType='"+m_EntityType+"')";
			    no = DB.executeUpdate(sql, null);
			    log.finest("Process Instance deleted:"+no);
			    
			    // Delete process
			    sql = "delete AD_Process where EntityType='"+m_EntityType+"'";
			    no = DB.executeUpdate(sql, null);
			    log.finest("Process deleted:"+no);
			    
			    // Delete tab
			    sql = "delete AD_Tab where EntityType='"+m_EntityType+"'";
			    no = DB.executeUpdate(sql, null);
			    log.finest("Tab deleted:"+no);
			    
			    // Delete fields
			    sql = "delete AD_Field where EntityType='"+m_EntityType+"'";
			    no = DB.executeUpdate(sql, null);
			    log.finest("Fields deleted:"+no);
			}
	    }
	}

	/**
	 * @param atts
	 * @param elementValue
	 */
	private void doStartProcess(Attributes atts) {
		// Name.
	    String name = atts.getValue("name");
	    if (name == null) {
	    	// Is there a field?
	    	if (m_Field != null)
	    		name = m_Field.getName();
	    	// Is there a menu?
	    	else if (m_MenuIndex >= 0)
	    		name = m_Menu[m_MenuIndex].getName();
	    }
	    String value = atts.getValue("value");
	    if (value == null) {
	    	value = name;
	    }
	    // Get/New process.
	    m_Process = new X_AD_Process(Env.getCtx(), XMLHelper.getIDbyName("AD_Process", name, null), null);
	    if (m_Process.getAD_Process_ID() == 0) {
		    log.info("Process: "+name+" not found. CREATE.");
			m_Process.setEntityType(m_EntityType);
			m_Process.setName(name);
			m_Process.setValue(value);
			m_Process.setAccessLevel(m_AccessLevel);
			m_Process.setIsReport(false);
			
		    // This assign the AD_Process_ID, is necessary for set Parent_ID in children.
		    m_Process.save();

		    // @Trifon
			// Get all roles defined in Compiere.
		    // This code makes problem, becasue it do ot set proper AD_Client_ID...
		    /*
			String sql = "SELECT AD_Role_ID "
					   + "FROM AD_Role "
					   + "WHERE AD_Client_ID <> 0 ";
			try {
				int AD_Role_ID = 0;
			    PreparedStatement pstmt = DB.prepareStatement(sql, null);
			    ResultSet rs = pstmt.executeQuery();
			    // Assign window to role. 
			    while (rs.next()) {
			    	AD_Role_ID = rs.getInt(1);
				    X_AD_Process_Access m_process_Access = new X_AD_Process_Access(Env.getCtx(), 0, null);
				    //m_window_Access.setClientOrg(m_Window);
				    m_process_Access.setAD_Process_ID(m_Process.getAD_Process_ID());
				    m_process_Access.setAD_Role_ID (AD_Role_ID);
				    m_process_Access.setIsReadWrite(true);
				    
				    m_process_Access.save();
			    }
			    	
			    rs.close();
			    pstmt.close();
			    pstmt = null;
			}
			catch (Exception e) {
				log.log(Level.SEVERE, "ERROR while getting AD_Role_ID : "+e);
			}
			*/
	    } else {
    		log.info("Process: "+name+" FOUND.");
	    }
	    // Check process attributes.
/*	    if (atts.getValue("jasperreport") != null) {
			m_Process.setJasperreport(atts.getValue("jasperreport"));
			m_Process.setClassname("ru.compiere.report.RusReportStarter");
	    } */
	    if (atts.getValue("classname") != null) {
	    	m_Process.setClassname(atts.getValue("classname"));
	    }
	    if (atts.getValue("description") != null) {
	    	m_Process.setDescription(atts.getValue("description"));
	    }
	    if (atts.getValue("help") != null) {
	    	m_Process.setHelp(atts.getValue("help"));
	    }
	    // Is Report
	    if (atts.getValue("IsReport") != null && !"".equals(atts.getValue("IsReport"))) {
	    	m_Process.setIsReport(atts.getValue("IsReport").equals("Y") ? true : false);
	    }
	    
	    // This assign the AD_Menu_ID, is necessary for set Parent_ID in children.
	    m_Process.save();
	    // Reset SeqNo for parameters.
	    m_ProcessSeqNo = 10;
	}
	
	private void doStartReportView(Attributes atts) {
		// Name. Mandatory.
	    String name = atts.getValue("name");
	    // Get/New Report View.
	    X_AD_ReportView m_ReportView = new X_AD_ReportView(Env.getCtx(), XMLHelper.getIDbyName("AD_ReportView", name, null), null);
	    if (m_ReportView.getAD_ReportView_ID() == 0) {
		    log.info("Report View: [" + name + "] not found. CREATE NEW ONE.");
		    m_ReportView.setEntityType(m_EntityType);
		    m_ReportView.setName(name);
	    } else {
    		log.info("Report View: ["+name+"] FOUND.");
	    }
	    
	    // Description
	    if (atts.getValue("description") != null) {
	    	m_ReportView.setDescription(atts.getValue("description"));
	    	log.info("Report View: Description " + atts.getValue("description"));
	    }
	    
	    // Is Active
	    if (atts.getValue("IsActive") != null && !"".equals(atts.getValue("IsActive"))) {
	    	m_ReportView.setIsActive(atts.getValue("IsActive").equals("Y") ? true : false);
	    	log.info("Report View: IsActive " + atts.getValue("IsActive"));
	    }
	    // OrderByClause
	    if (atts.getValue("OrderByClause") != null) {
	    	m_ReportView.setOrderByClause(atts.getValue("OrderByClause"));
	    	log.info("Report View: OrderByClause " + atts.getValue("OrderByClause"));
	    }
	    // WhereClause
	    if (atts.getValue("WhereClause") != null) {
	    	m_ReportView.setWhereClause(atts.getValue("WhereClause"));
	    	log.info("Report View: WhereClause " + atts.getValue("WhereClause"));
	    }
	    
	    // AD_Table_ID
	    int m_AD_Table_ID = XMLHelper.getIDWithColumn("AD_Table", "TableName", atts.getValue("tableName"), m_AD_Client_ID);
	    m_ReportView.setAD_Table_ID(m_AD_Table_ID);
	    
	    m_ReportView.save();
	    if (m_Process != null) {
	    	m_Process.setAD_ReportView_ID(m_ReportView.getAD_ReportView_ID());
	    	m_Process.save();
	    }
	    
	}
	
	/**
	 * @param atts
	 */
	private void doStartProcessPara(Attributes atts) {
		// Name. Mandatory.
	    String name = atts.getValue("name");
	    // Get/New process.
	    X_AD_Process_Para m_ProcessPara = new X_AD_Process_Para(Env.getCtx(), getIDWithMaster("AD_Process_Para", name, "AD_Process", m_Process.getName()), null);
	    if (m_ProcessPara.getAD_Process_Para_ID() == 0) {
		    log.info("Process Parameter: " + name + " not found. CREATE.");
			m_ProcessPara.setEntityType(m_EntityType);
			m_ProcessPara.setName(name);
			m_ProcessPara.setAD_Process_ID(m_Process.getAD_Process_ID());
			m_ProcessPara.setColumnName("to_be_defined");
			m_ProcessPara.setIsCentrallyMaintained (false);
			m_ProcessPara.setIsRange (false);
			m_ProcessPara.setIsMandatory (false);
			m_ProcessPara.setFieldLength(0);
	    } else {
    		log.info("Process Parameter: "+name+" FOUND.");
	    }
	    // Adjust sequence number.
	    m_ProcessPara.setSeqNo(m_ProcessSeqNo);
	    // Check process attributes.
	    if (atts.getValue("reference") != null) {
	    	m_ProcessPara.setAD_Reference_ID(XMLHelper.getIDbyName("AD_Reference", atts.getValue("reference"), null));
	    }
	    if (atts.getValue("reference_value") != null && !"".equals(atts.getValue("reference_value"))) {
	    	m_ProcessPara.setAD_Reference_Value_ID(XMLHelper.getIDbyName("AD_Reference", atts.getValue("reference_value"), null));
	    }
	    if (atts.getValue("columnname") != null) {
	    	m_ProcessPara.setColumnName(atts.getValue("columnname"));
    		log.info("Process Parameter: columnname " + atts.getValue("columnname"));
	    }
	    if (atts.getValue("name") != null) {
	    	m_ProcessPara.setName(atts.getValue("name"));
	    }
	    if (atts.getValue("description") != null) { //@Trifon
	    	m_ProcessPara.setDescription(atts.getValue("description"));
	    }
	    if (atts.getValue("element") != null) { //@Trifon
		    //X_AD_Element element = new X_AD_Element(Env.getCtx(), getIDWithColumn("AD_Element", "ColumnName", atts.getValue("element")), null);
	    	//m_ProcessPara.setAD_Element_ID(element.getID());
	    	m_ProcessPara.setAD_Element_ID(XMLHelper.getIDWithColumn("AD_Element", "ColumnName", atts.getValue("element"), m_AD_Client_ID));
	    }
	    if (atts.getValue("val_rule") != null) { //@Trifon
	    	m_ProcessPara.setAD_Val_Rule_ID(XMLHelper.getIDWithColumn("AD_Val_Rule", "Name", atts.getValue("val_rule"), m_AD_Client_ID));
	    }
	    if (atts.getValue("defaultValue") != null) { //@Trifon
	    	m_ProcessPara.setDefaultValue(atts.getValue("defaultValue"));
	    }
	    if (atts.getValue("seqNo") != null) { //@Trifon
	    	m_ProcessPara.setSeqNo(Integer.parseInt(atts.getValue("seqNo")));
	    }
	    //
	    if (atts.getValue("mandatory") != null) {
	    	m_ProcessPara.setIsMandatory(atts.getValue("mandatory").equals("Y") ? true : false);
	    }
	    //
	    if (atts.getValue("IsRange") != null && !"".equals(atts.getValue("IsRange"))) {
	    	m_ProcessPara.setIsRange(atts.getValue("IsRange").equals("Y") ? true : false);
	    }
	    //
	    if (atts.getValue("DynamicValidation") != null && !"".equals(atts.getValue("DynamicValidation"))) {
			// @Trifon
			X_AD_Val_Rule m_valRule = new X_AD_Val_Rule(Env.getCtx(), XMLHelper.getIDbyName("AD_Val_Rule", atts.getValue("DynamicValidation"), null), null);
		    if (m_valRule.getAD_Val_Rule_ID() == 0) {
		    	m_valRule.setEntityType(m_EntityType); // TODO - could be taken from attribute
		    	m_valRule.setName(atts.getValue("DynamicValidation"));
		    	//m_valRule.setDescription(value); // TODO this could be taken from attributes 
		    	m_valRule.setType("S"); // TODO this could be taken from attributes
		    	// S = SQL; J = Java Language; E = Java Script
		    }
		    String code = atts.getValue("code");
		    
		    if (code != null) {
		    	m_valRule.setCode(code);
		    }
		    
		    m_valRule.save();
		    
		    m_ProcessPara.setAD_Val_Rule_ID(m_valRule.getAD_Val_Rule_ID());
	    }
	    // This assign the AD_Menu_ID, is necessary for set Parent_ID in children.
	    m_ProcessPara.save();
	    m_ProcessSeqNo = m_ProcessSeqNo + 10;
	}

	private void doStartCommitWarning(Attributes atts) {
		chracters = new StringBuffer();
	}
	
	private void doEndCommitWarning() {
    	log.info("_________________ END commitWarning _________________");
    	
    	if (chracters != null && !"".equals(chracters.toString().trim())) {
	    	m_Tab[m_TabLevelNo].setCommitWarning(chracters.toString());
	    	log.info("Trifon __________________________________________________________");
	    	log.info("Trifon _________________ chracters = "+ chracters.toString());
	    	log.info("Trifon __________________________________________________________");
	    	
	    	m_Tab[m_TabLevelNo].save();
	    }
	}
	
	/**
	 * @param atts
	 */
	private void doStartTab(Attributes atts) {
		m_TabSeqNo = m_TabSeqNo+10;
	    m_TabLevelNo++;

	    String tabName = atts.getValue("name");
	    String tableName = atts.getValue("tablename");
	    int AD_Table_ID = 0;
	    if (tableName != null) // Carlos Ruiz - we can have tabs without tablename only for reference
	    	AD_Table_ID = XMLHelper.getIDWithColumn ("AD_Table", "TableName", tableName, m_AD_Client_ID); 
	    String linkColumn = atts.getValue("linkcolumn");
	    String singleRow = atts.getValue("IsSingleRow");
	    String whereClause = atts.getValue("WhereClause");
	    String commitWarning = atts.getValue("CommitWarning");
	    String orderByClause = atts.getValue("OrderByClause");
	    String TabLevel_Str = atts.getValue("TabLevel");
	    String ReadOnlyLogic = atts.getValue("ReadOnlyLogic");
	    
	    int tabLevel = 0;
	    if (TabLevel_Str != null && !"".equals(TabLevel_Str)) {
	    	tabLevel = Integer.parseInt(TabLevel_Str);
	    }
	    
	    boolean isActive = true;
	    String isActiveString = atts.getValue("IsActive");
	    if (isActiveString != null && !"".equals(isActiveString)) {
		    if (isActiveString.equals("N")) {
		    	isActive = false;
	    	}	    	
	    }
	    
	    boolean isSingleRow = false;
	    if (singleRow != null && !"".equals(singleRow)) {
		    if (singleRow.equals("Y")) {
		    	isSingleRow = true;
		    }
	    }
	    
	    boolean isReadOnly = false;
	    String isReadOnlyString = atts.getValue("IsReadOnly");
	    if (isReadOnlyString != null && !"".equals(isReadOnlyString)) {
		    if (isReadOnlyString.equals("Y")) {
		    	isReadOnly = true;
	    	}	    	
	    }
	    
    	log.info("TAB:" + tabName 
    			+ ", level:" + m_TabLevelNo
    			+ ", tabName:" + tabName
    			+ ", tableName:" + tableName
    			+ ", AD_Table_ID:" + AD_Table_ID
    			+ ", m_AD_Client_ID:" + m_AD_Client_ID
    			+ ", linkcolumn:" + linkColumn
    			+ ", singleRow:" + singleRow
    			+ ", whereClause:" + whereClause    			
    			+ ", commitWarning:" + commitWarning
    			+ ", orderByClause:" + orderByClause
    			+ ", IsActive:" + isActive
    	);
    	
	    // Get/New window.
	    m_Tab[m_TabLevelNo] = new X_AD_Tab(Env.getCtx(), getIDWithMaster("AD_Tab", tabName, "AD_Window", m_Window.getName()), null);
    	log.info("X_AD_Tab constructor called");
	    if (m_Tab[m_TabLevelNo].getAD_Tab_ID() == 0) {
		    log.info("Tab: " + tabName + " NOT found. CREATE.");
			m_Tab[m_TabLevelNo].setName(tabName);
			//m_Tab[m_TabLevelNo].setAD_Table_ID(getIDbyName("AD_Table", atts.getValue("tablename"))); // @Trifon
			
			m_Tab[m_TabLevelNo].setAD_Table_ID(AD_Table_ID);
			m_Tab[m_TabLevelNo].setAD_Window_ID(m_Window.getAD_Window_ID());
			m_Tab[m_TabLevelNo].setSeqNo(m_TabSeqNo);
			if (TabLevel_Str != null && !"".equals(TabLevel_Str)) {
				m_Tab[m_TabLevelNo].setTabLevel(tabLevel);
			} else {
				m_Tab[m_TabLevelNo].setTabLevel(m_TabLevelNo);
			}
			
			// TODO Get attributes
			m_Tab[m_TabLevelNo].setIsSingleRow(isSingleRow);
			m_Tab[m_TabLevelNo].setWhereClause(whereClause);
			m_Tab[m_TabLevelNo].setIsTranslationTab(false);
			m_Tab[m_TabLevelNo].setIsReadOnly(isReadOnly);
			m_Tab[m_TabLevelNo].setHasTree(false);
			m_Tab[m_TabLevelNo].setIsSortTab(false); 
			m_Tab[m_TabLevelNo].setEntityType(m_EntityType);
			m_Tab[m_TabLevelNo].setOrderByClause(orderByClause);
			if (commitWarning != null && !"".equals(commitWarning.trim())) {
				m_Tab[m_TabLevelNo].setCommitWarning(commitWarning);
			}
			
			m_Tab[m_TabLevelNo].setIsActive(isActive);
	    } else {
		    log.info("Tab: "+tabName+" FOUND.");
	    }
	    m_Tab[m_TabLevelNo].setSeqNo(m_TabSeqNo);
	    if (TabLevel_Str != null && !"".equals(TabLevel_Str)) {
			m_Tab[m_TabLevelNo].setTabLevel(tabLevel);
		} else {
			m_Tab[m_TabLevelNo].setTabLevel(m_TabLevelNo);
		}
	    if (linkColumn != null && !"".equals(linkColumn.trim())) {
	    	m_Tab[m_TabLevelNo].setAD_Column_ID(XMLHelper.getIDWithMasterAndColumn("AD_Column", "ColumnName", linkColumn, "AD_Table", m_Tab[m_TabLevelNo].getAD_Table_ID()));
	    }
	    if (singleRow != null && !"".equals(singleRow.trim())) {
	    	m_Tab[m_TabLevelNo].setIsSingleRow(isSingleRow);
	    }
	    if (whereClause != null && !"".equals(whereClause.trim())) {
	    	m_Tab[m_TabLevelNo].setWhereClause(whereClause);
	    }
	    if (commitWarning != null && !"".equals(commitWarning.trim())) {
	    	m_Tab[m_TabLevelNo].setCommitWarning(commitWarning);
	    }
	    if (orderByClause != null && !"".equals(orderByClause.trim())) {
	    	m_Tab[m_TabLevelNo].setOrderByClause(orderByClause);
	    }
	    m_Tab[m_TabLevelNo].setIsActive(isActive);
	    
	    if (ReadOnlyLogic != null && !"".equals(ReadOnlyLogic.trim())) {
			m_Tab[m_TabLevelNo].setReadOnlyLogic(ReadOnlyLogic);
		}
	    m_Tab[m_TabLevelNo].setIsReadOnly(isReadOnly);
	    
	    // SAVE
	    m_Tab[m_TabLevelNo].save();
	    // syncfields should be controlled after save cause TAB_ID is needed.
	    String syncFields = atts.getValue("syncfields"); 
	    if (syncFields != null && syncFields.equals("Y")) {
			// boolean isSameLine = false; // @Trifon
			String sql = 
				  "SELECT coalesce(e.PrintName, c.Name), c.Description, c.AD_Column_ID, c.FieldLength, c.EntityType, c.ColumnName"
			    + ", (SELECT tablename "
				+ "   FROM AD_Table "
				+ "   WHERE AD_Table_ID = c.AD_Table_ID) as tablename"
			    + " FROM AD_Column c "
				+ " LEFT OUTER JOIN AD_Element e USING(AD_Element_ID)"
			    + " WHERE NOT EXISTS (SELECT * " 
				+"                    FROM AD_Field f "
			    + "                   WHERE c.AD_Column_ID=f.AD_Column_ID"
			    + "                    AND c.AD_Table_ID=? "
				+ "                    AND f.AD_Tab_ID=?"
				+ "                  )"
			    + " AND AD_Table_ID=? "
				+ " AND NOT (UPPER(c.Name) LIKE 'CREATED%' OR UPPER(c.Name) LIKE 'UPDATED%')"
			    + " AND c.IsActive='Y'";
			try {
			    PreparedStatement pstmt = DB.prepareStatement(sql, null);
			    pstmt.setInt(1, m_Tab[m_TabLevelNo].getAD_Table_ID());
			    pstmt.setInt(2, m_Tab[m_TabLevelNo].getAD_Tab_ID());
			    pstmt.setInt(3, m_Tab[m_TabLevelNo].getAD_Table_ID());
			    ResultSet rs = pstmt.executeQuery();
			    while (rs.next()) {
					//m_Column = new X_AD_Column(Env.getCtx(), rs.getInt(3)); // Get the column.
					m_Field = new X_AD_Field(Env.getCtx(), 0, null);
					m_Field.setAD_Column_ID(rs.getInt(3));
					m_Field.setAD_Tab_ID(m_Tab[m_TabLevelNo].getAD_Tab_ID());
					m_Field.setEntityType(m_EntityType);
					m_Field.setIsCentrallyMaintained(true);
					m_Field.setIsDisplayed(!rs.getString(6).equals(rs.getString(7)+"_ID"));
					m_Field.setIsEncrypted(false);
					m_Field.setIsFieldOnly(false);
					m_Field.setIsHeading(false);
					m_Field.setIsReadOnly(false);
					//m_Field.setIsSameLine(isSameLine); // @Trifon
					m_Field.setName(rs.getString(1));
					// Save.
					m_Field.save();
					// Use 2 lines.
					//if (m_Field.isDisplayed())
					    //isSameLine = !isSameLine; // @Trifo
				}
			    rs.close();
			    pstmt.close();
			    pstmt = null;
			}
			catch (Exception e) {
				log.severe("syncfields:" + e);
			}
	    }   // syncfields.
		// Adjust parent link informations.
	    // TODO: some convention to be documented.
	    // TODO - @Trifon; This is generating problems !!!
	    /*
	    if (m_TabLevelNo > 0) {
			String sql = 
				  "UPDATE AD_Column"
			    + " SET isParent='Y'"
			    + " WHERE ColumnName = (select TableName||'_ID' from AD_Table where AD_Table_ID="+m_Tab[m_TabLevelNo-1].getAD_Table_ID()+")"
			    + "  AND AD_Table_ID="+m_Tab[m_TabLevelNo].getAD_Table_ID();
			int no = DB.executeUpdate(sql);
			if (DEBUG)
			    log.info("Parent link for "+tabName+":"+no);
	    }
	    */
	}

	/**
	 * @param atts
	 */
	private void doStartWindow(Attributes atts) {
		// Reset Tab numbering.
	    m_TabSeqNo = 0;
	    m_TabLevelNo = -1;
	    // Mandatory.
	    String windowName = atts.getValue("name");
	    if (windowName == null)
	    	windowName = m_Menu[m_MenuIndex].getName();   // Take the name from the menu.
	    
	    String isSOTrxStr = atts.getValue("IsSOTrx");
	    boolean isSOTrx = false;
	    if (isSOTrxStr != null && !"".equals(isSOTrxStr)) {
	    	if (isSOTrxStr.equals("Y")) {
	    		isSOTrx = true;
	    	}
	    }
	    // Get/New window.
	    m_Window = new X_AD_Window(Env.getCtx(), XMLHelper.getIDbyName("AD_Window", windowName, null), null);
	    if (m_Window.getAD_Window_ID() == 0) {
		    log.info("Window: "+windowName+" not found. CREATE.");
			m_Window.setEntityType(m_EntityType);
			if (isSOTrxStr != null && !"".equals(isSOTrxStr)) {
				m_Window.setIsSOTrx(isSOTrx);
			}
			m_Window.setName(windowName);
			m_Window.setWindowType(XMLHelper.reverseReference("AD_Window Types", "Maintain"));
			
		    // @Trifon
			// Get all roles defined in Compiere.
			// This code makes problem, becasue it do not set proper AD_Client_ID
			/*
			String sql = "SELECT AD_Role_ID "
					   + "FROM AD_Role "
					   + "WHERE AD_Client_ID <> 0 ";
			try {
				int AD_Role_ID = 0;
			    PreparedStatement pstmt = DB.prepareStatement(sql, null);
			    ResultSet rs = pstmt.executeQuery();
			    // Assign window to role. 
			    while (rs.next()) {
			    	AD_Role_ID = rs.getInt(1);
				    X_AD_Window_Access m_window_Access = new X_AD_Window_Access(Env.getCtx(), 0, null);
				    //m_window_Access.setClientOrg(m_Window);
				    m_window_Access.setAD_Window_ID(m_Window.getAD_Window_ID());
				    m_window_Access.setAD_Role_ID (AD_Role_ID);
				    m_window_Access.setIsReadWrite(true);
				    
				    m_window_Access.save();
			    }
			    	
			    rs.close();
			    pstmt.close();
			    pstmt = null;
			}
			catch (Exception e) {
				log.severe("ERROR while getting AD_Role_ID : "+e);
			}
			*/
			// This assign the AD_Menu_ID, is necessary for set Parent_ID in children.
			m_Window.save();
	    } else {
		    log.info("Window: "+windowName+" FOUND.");
	    }
	    
	    if (isSOTrxStr != null && !"".equals(isSOTrxStr)) {
	    	m_Window.setIsSOTrx(isSOTrx);
	    }
	    
	    m_Window.save();
	}

	/**
	 * @param atts
	 */
	private void doStartMenu(Attributes atts) {
		// Mandatory.
	    String menuName = atts.getValue("name");
	    if (menuName == null)
	    	menuName = TEMP_NAME;   // Name from the object contained (window, report...)
	    // SeqNo.
	    m_MenuSeqNo[m_MenuIndex+1] = m_MenuSeqNo[m_MenuIndex+1] + 10;
	    // Get/New menu.
	    ++m_MenuIndex;
	    m_MenuSeqNo[m_MenuIndex+1] = 10;
	    m_Menu[m_MenuIndex] = new X_AD_Menu(Env.getCtx(), XMLHelper.getIDbyName("AD_Menu", menuName, null), null);
	    if (m_Menu[m_MenuIndex].getAD_Menu_ID() == 0) {
		    log.info("Menu: "+menuName+" not found. CREATE.");
			m_Menu[m_MenuIndex].setEntityType(m_EntityType);
			m_Menu[m_MenuIndex].setIsReadOnly(false);
			m_Menu[m_MenuIndex].setIsSOTrx(false);
			m_Menu[m_MenuIndex].setName(menuName);
	    } else {
	    	log.info("Menu: " + menuName + " FOUND.");
	    }
	    // Check menu attributes.
	    // Actually IsSummary is calculated.
	    String isSummary = atts.getValue("isSummary"); 
	    if (isSummary != null && !"".equals(isSummary)) {
	    	m_Menu[m_MenuIndex].setIsSummary(isSummary.equals("true") ? true : false);
	    }
	    // IsSales Transaction
	    String isSOTrx = atts.getValue("isSOTrx"); 
	    if (isSOTrx != null && !"".equals(isSOTrx)) {
	    	m_Menu[m_MenuIndex].setIsSOTrx(isSOTrx.equals("true") ? true : false);
	    }
	    // Action: B = Workbench; F = WorkFlow; P = Process; R = Report; T = Task; W = Window; X = Form;
	    String action = atts.getValue("action"); 
	    if (action != null && !"".equals(action)) {
	    	m_Menu[m_MenuIndex].setAction(action);
	    }
	    // This assign the AD_Menu_ID, is necessary for set Parent_ID in children.
	    m_Menu[m_MenuIndex].save();
	}

	/**
	 * @param atts
	 */
	private void doStartCompiereData(Attributes atts) {
		compieredata = true;
		String clientName = atts.getValue("clientname");
		
	    if (clientName != null && !"".equals(clientName)) {
	    	m_AD_Client_ID = XMLHelper.getIDbyName("AD_Client", clientName, null);
	    	Env.setContext(Env.getCtx(), "#AD_Client_ID", m_AD_Client_ID);
    		log.info("Client ID is:"+Env.getAD_Client_ID(Env.getCtx()));
	    }
	}

	/**
	 * 
	 */
	private void doStartCompiereAD(Attributes atts) {
		compiereAD = true;
	}


    public int getIDbyNameAndWhere (String tableName, String name, String clientName, String where) {
		int id = 0;
		int AD_Client_ID = m_AD_Client_ID;
		String sql = null;
		
		sql = "SELECT " + tableName + "_ID \n"
		    + "FROM " + tableName + " \n"
		    + "WHERE Name=? \n"
		;
		if (where != null && !"".equals(where.trim())) {
			sql = sql + " AND " + where;
		}
		if (!tableName.startsWith("AD_")) {
		    sql = sql + " AND AD_Client_ID=?";

		    if (clientName != null && !"".equals(clientName.trim())) {
				AD_Client_ID = XMLHelper.getIDbyName("AD_Client", clientName, null);
			}
		}

		log.finer("SQL = \n" + sql);
		log.finer("AD_Client_ID = " + m_AD_Client_ID);

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    if (!tableName.startsWith("AD_"))
		    	pstmt.setInt(2, AD_Client_ID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "getID:"+e);
		}
		return id;
    }
    
    public int getIDWithColumnAndWhere (String tableName, String columnName, Object value, String where) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID "
				   + " FROM " + tableName + " "
				   + " WHERE " + columnName + "=?";
		if (where != null && !"".equals(where.trim())) {
			sql = sql + " AND " + where;
		}
		if (!tableName.startsWith("AD_"))
		    sql = sql + " AND AD_Client_ID=?";
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    if (value instanceof String)
		    	pstmt.setString(1, (String)value);
		    else if (value instanceof Integer)
		    	pstmt.setInt(1, ((Integer)value).intValue());
		    if (!tableName.startsWith("AD_"))
		    	pstmt.setInt(2, m_AD_Client_ID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		return id;
    }

    /**
     * Get ID from Name for a table with a Master reference.
     *
     * @param tableName
     * @param name
     * @param tableNameMaster
     * @param nameMaster
     */
    public int getIDWithMaster (String tableName, String name, String tableNameMaster, String nameMaster) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID "
				   + " FROM " + tableName + " "
				   + " WHERE name=? "
				   + "  AND "
				   + tableNameMaster+"_ID = (select "+tableNameMaster+"_ID from "+tableNameMaster+" where name=?)";
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    pstmt.setString(2, nameMaster);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		return id;
    }

    /**
     * Get ID from Name for a table with a Master reference ID.
     *
     * @param tableName
     * @param name
     * @param tableNameMaster
     * @param masterID
     */
    public int getIDWithMaster (String tableName, String name, String tableNameMaster, int masterID) {
		int id = 0;
		String sql = "SELECT "+tableName+"_ID "
				   + " FROM "+tableName+" "
				   + " WHERE name=? and "
				   + tableNameMaster+"_ID=?";
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    pstmt.setInt(2, masterID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "getIDWithMasterID:"+e);
		}
		return id;
    }

    // @Trifon
    public int getIDWithMasterColumnAndWhere (String tableName, String columnName, String name, String tableNameMaster, String masterColumn, String masterValue) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID \n"
				   + "FROM " + tableName + " x \n"
				   + "WHERE " + columnName + "=? \n" // name
				   + " AND x." + tableNameMaster + "_ID = \n"
				   + "  ( SELECT " + tableNameMaster + "_ID \n"
				   + "    FROM " + tableNameMaster + "\n"
				   + "    WHERE " + masterColumn + " = ? \n" // masterValue 
				   + "  )\n"
				   ;
		log.log(Level.FINEST, "sql:\n" + sql);
		log.log(Level.FINEST, "param1:" + name);
		log.log(Level.FINEST, "param2:" + masterValue);

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    pstmt.setString(2, masterValue);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, e.toString());
		}
		/*
		if (id == 0) {
			throw new NullPointerException("NOT Found ID");
		}
		*/
		return id;

    }

    // @Trifon
    public int getIDWithMasterColumnAnd2Where (String tableName, String columnName, String name, String tableNameMaster, String masterColumn, String masterValue, String masterColumn2, String masterValue2) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID \n"
				   + "FROM " + tableName + " x \n"
				   + "WHERE " + columnName + "=? \n" // name
				   + " AND x." + tableNameMaster + "_ID = \n"
				   + "  ( SELECT " + tableNameMaster + "_ID \n"
				   + "    FROM " + tableNameMaster + "\n"
				   + "    WHERE " + masterColumn + " = ? \n" // masterValue
				   + "     AND " + masterColumn2 + " = ? \n" // masterValue2
				   + "  )\n"
				   ;
		log.log(Level.FINEST, "sql:" + sql);
		log.log(Level.FINEST, "param1:" + name);
		log.log(Level.FINEST, "param2:" + masterValue);
		log.log(Level.FINEST, "param2:" + masterValue2);

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    pstmt.setString(2, masterValue);
		    pstmt.setString(3, masterValue2);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		/*
		if (id == 0) {
			throw new NullPointerException("NOT Found ID");
		}
		*/
		return id;

    }

    // @Trifon
    public int getIDWithMasterColumnAnd2Where (String tableName, String columnName, int name, String tableNameMaster, String masterColumn, String masterValue, String masterColumn2, int masterValue2) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID \n"
				   + "FROM " + tableName + " x \n"
				   + "WHERE " + columnName + "=? \n" // name
				   + " AND x." + tableNameMaster + "_ID = \n"
				   + "  ( SELECT " + tableNameMaster + "_ID \n"
				   + "    FROM " + tableNameMaster + "\n"
				   + "    WHERE " + masterColumn + " = ? \n" // masterValue
				   + "     AND " + masterColumn2 + " = ? \n" // masterValue2
				   + "  )\n"
				   ;
		log.log(Level.FINEST, "sql = \n" + sql);
		log.log(Level.FINEST, "param1 - int:" + name);
		log.log(Level.FINEST, "param2:" + masterValue);
		log.log(Level.FINEST, "param3 - int:" + masterValue2);

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setInt(1, name);
		    pstmt.setString(2, masterValue);
		    pstmt.setInt(3, masterValue2);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		/*
		if (id == 0) {
			throw new NullPointerException("NOT Found ID");
		}
		*/
		return id;

    }

    // @Trifon
    public String getValueFromRefList (String referenceName, String name) {
		String value = "";
		String sql = " SELECT Value "
				   + " FROM AD_Ref_List "
				   + " WHERE " 
				   + "   AD_Ref_List.AD_Reference_ID = (SELECT AD_Reference.AD_Reference_ID " 
				   + "                                  FROM AD_Reference "
				   + "                                  WHERE AD_Reference.Name = ?) " // @1
				   + "   AND AD_Ref_List.Name= ? "   // 'Comma Separated' " // This is duplicated
				   //+ "    AND AD_Ref_List.Value = 'C' "              // This is Unique
				   ;

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, referenceName);
		    pstmt.setString(2, name);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next()) {
		    	value = rs.getString(1);
		    }
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, e.toString());
		}
		return value;
    }
    
    // TODO - Trifon
    public String getValueFromRefTable (String referenceName, String name) {
		String value = "";
		String sql = "   SELECT Value "
				   + "   FROM AD_Ref_List "
				   + "   WHERE " 
				   + "    AD_Ref_List.AD_Reference_ID = (SELECT AD_Reference.AD_Reference_ID " 
				   + "                                   FROM AD_Reference "
				   + "                                   WHERE AD_Reference.Name = ?) " // @1
				   + "    AND AD_Ref_List.Name= ? "   // 'Comma Separated' " // This is duplicated
				   //+ "    AND AD_Ref_List.Value = 'C' "              // This is Unique
				   ;

		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, referenceName);
		    pstmt.setString(2, name);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next()) {
		    	value = rs.getString(1);
		    }
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, e.toString());
		}
		return value;
    }

    /**
     *	Receive notification of character data inside an element.
     *
     * 	@param ch buffer
     * 	@param start start
     * 	@param length length
     * 	@throws SAXException
     */
    // Not used right now.

    public void characters (char ch[], int start, int length) throws SAXException {
    	//log.info("<___________________________BEGIN_______________________________>");
    	
    	for (int i = start; i < start + length; i++) {
    		//chracters.append(ch[i]);
    		//log.info("___ch[i] = "+ ch[i]);
    		
    	    switch (ch[i]) {
    	    case '\\':
    	    	//chracters.append("\\\\");
    	    	chracters.append("\\");
    	    	break;
    	    	
    	    case '"':
    	    	//chracters.append("\\\"");
    	    	chracters.append("\"");
    	    	break;
    	    	
    	    case '\n':
    	    	//chracters.append("\\n");
    	    	chracters.append("\n");
    	    	break;
    	    	
    	    case '\r':
    	    	//chracters.append("\\r");
    	    	chracters.append("\r");
    	    	break;
    	    	
    	    case '\t':
    	    	//chracters.append("\\t");
    	    	chracters.append("\t");
    	    	break;
    	    	
    	    default:
    	    	chracters.append(ch[i]);
    	    
    			break;
    	    }
    	}
    	//log.info("<__________________________END________________________________>");
    }


    /**
	 *	Return date as YYYY-MM-DD HH24:MI:SS	(JDBC Timestamp format w/o miliseconds)
	 *  @param info data
	 *  @return date as JDBC format String
	 */
	private Timestamp parseDate (String info, String dateFormat)
	{
		//Date date = null;
		Timestamp ret = null;
		
		if (m_dformat == null)
		{
			try
			{
				m_dformat = new SimpleDateFormat(dateFormat);
			}
			catch (Exception e)
			{
				log.log(Level.SEVERE, "Format=" + dateFormat, e);
			}
			if (m_dformat == null)
				m_dformat = (SimpleDateFormat)DateFormat.getDateInstance();
			m_dformat.setLenient(true);
		}

//		Timestamp ts = null;
		try
		{
			Date date = m_dformat.parse(info);
			ret = new Timestamp (m_dformat.parse(info).getTime());
		}
		catch (ParseException pe)
		{
			log.log(Level.SEVERE, info, pe);
		}
/*
		if (ts == null) {
			ts = new Timestamp (System.currentTimeMillis());	
		}
		//
		String dateString = ts.toString();
		return dateString.substring(0, dateString.indexOf("."));	//	cut off miliseconds
*/
		return ret;
	}
    /**
     *	Receive notification of the end of an element.
     * 	@param uri namespace
     * 	@param localName simple name
     * 	@param qName qualified name
     * 	@throws SAXException
     */
    public void endElement (String uri, String localName, String qName) throws SAXException {
		// Check namespace.
		String elementValue = null;
		if ("".equals (uri))
		    elementValue = qName;
		else
		    elementValue = uri + localName;
		
		log.info("endElement: " + elementValue);
	
		// menu element.
		if (elementValue.equals("menu")) {
		    // There was a precedent Window.
		    if (m_Window != null) {
				m_Menu[m_MenuIndex].setAD_Window_ID(m_Window.getAD_Window_ID());
				m_Menu[m_MenuIndex].setAction(XMLHelper.reverseReference("AD_Menu Action", "Window"));
				m_Menu[m_MenuIndex].setIsSummary(false);
				if (m_Menu[m_MenuIndex].getName().equals(TEMP_NAME)) // Name from the contained object.
				    m_Menu[m_MenuIndex].setName(m_Window.getName());
				m_Window = null;
		    } else if (m_Process != null) {
				// Precedent Process.
				m_Menu[m_MenuIndex].setAD_Process_ID(m_Process.getAD_Process_ID());
				if ("P".equals(m_Menu[m_MenuIndex].getAction()) || m_Menu[m_MenuIndex].getAction() == null) {
					m_Menu[m_MenuIndex].setAction(XMLHelper.reverseReference("AD_Menu Action", "Process"));
				}
				m_Menu[m_MenuIndex].setIsSummary(false);
				if (m_Menu[m_MenuIndex].getName().equals(TEMP_NAME)) // Name from the contained object.
				    m_Menu[m_MenuIndex].setName(m_Process.getName());
				m_Process = null;
		    } else {
		    	m_Menu[m_MenuIndex].setIsSummary(true);
		    }
		    m_Menu[m_MenuIndex].save();
		    MTree_Base m_TreeBase = new MTree_Base(Env.getCtx(), 10, null); // Menu.
		    MTree_NodeMM m_TreeNodeMM = MTree_NodeMM.get(m_TreeBase, m_Menu[m_MenuIndex].getAD_Menu_ID());
		    if (m_TreeNodeMM == null)
		    	m_TreeNodeMM = new MTree_NodeMM(m_TreeBase, m_Menu[m_MenuIndex].getAD_Menu_ID());
		    // There was an update to zero for the root, but X_AD_Menu transform 0 to null. So no update for roots.
		    // zero is placed by default.
		    if (m_MenuIndex > 0)
		    	m_TreeNodeMM.setParent_ID(m_Menu[m_MenuIndex-1].getAD_Menu_ID());
		    m_TreeNodeMM.setSeqNo(m_MenuSeqNo[m_MenuIndex]);
		    m_TreeNodeMM.save();
		    m_Menu[m_MenuIndex] = null;
		    --m_MenuIndex;
		}
		// TAB tag
		else if (elementValue.equals(TAB_TAG)) {
		    m_TabLevelNo--;
		    m_FieldSeqNo = 10;
		}
		//
		else if (elementValue.equals(COMMIT_WARNING_TAG)) {
			doEndCommitWarning();
			
		}
		// end of Field Translation
		else if (elementValue.equals(TRANSLATION_TAG) && isFieldTranslation ) {
			String tableName = "AD_Field_Trl"; // "AD_Reference_Trl", "AD_Ref_List_Trl"
	    	String columnName = "AD_Field_ID"; // "AD_Reference_ID",  "AD_Ref_List_ID"
			//doEndFieldTranslation(tableName, columnName);
			doEndTranslation(tableName, columnName);
		}
		// end of Reference Translation
		else if (elementValue.equals(TRANSLATION_TAG) && isReferenceTranslation && !isReferenceListTranslation ) {
			String tableName = "AD_Reference_Trl";
	    	String columnName = "AD_Reference_ID";
			//doEndReferenceTranslation(tableName, columnName);
			doEndTranslation(tableName, columnName);
		}
		// end of ReferenceList Translation
		else if (elementValue.equals(TRANSLATION_TAG) && isReferenceListTranslation ) {
			String tableName = "AD_Ref_List_Trl";
	    	String columnName = "AD_Ref_List_ID";
			//doEndReferenceListTranslation(tableName, columnName);
			doEndTranslation(tableName, columnName);
		}
		// 
		else if (m_translationLanguage != null && elementValue.equals(ATTRIB_TAG) && isAttribName) {
			doEndTranslation_AttribName();
		}
		//
		else if (m_translationLanguage != null && elementValue.equals(ATTRIB_TAG) && isAttribDescription) {
			doEndTranslation_AttribDescription();
		}
		//
		else if (m_translationLanguage != null && elementValue.equals(ATTRIB_TAG) && isAttribHelp) {
			doEndTranslation_AttribHelp();
		}
		// window element close.
		else if (elementValue.equals(WINDOW_TAG)) {
			if (m_MenuIndex >= 0 ) {
				
			} else {
				m_Window = null;
			}
		} 
		// field element close.
		else if (elementValue.equals(FIELD_TAG) && compiereAD) {
	    	doEndField();
		}
	
		// Reference element close
		else if (elementValue.equals(REFERENCE_TAG) && compiereAD) {
			doEndReference();
		}
		
		// TODO - Reference List
		else if (elementValue.equals(REFERENCE_LIST_TAG) && compiereAD) {
			//AD_Reference List
			doEndReferenceList();
		}

		// TODO - Reference Table
		else if (elementValue.equals(REFERENCE_TABLE_TAG) && compiereAD) {
			//AD_Reference Table
			doEndReferenceTable();
		}

		/* ****************************************
		   Druid Handler.
		   **************************************** */
		else if (elementValue.equals(TABLE_TAG) && druid) {
		    // Remove non existent column and field of the specified entitytype
		    // Dangerous if you use Compiere or Dictionary entity type.
		    // @Trifon; We do not need to delte all columns or fields
/*
			if (m_ColumnList.length() > 0) {
				// Delete Fields with the EntityType specified.
				String sql = 
					"DELETE AD_Field "
				  + "WHERE AD_Column_ID in (SELECT AD_Column_ID"
				  + "                       FROM AD_Column "
				  + "                       WHERE AD_Table_ID="+m_Table.getAD_Table_ID()
				  + " AND AD_Column_ID not in ("+m_ColumnList+"))"
				  + " AND EntityType='"+m_EntityType+"'";
				int no = DB.executeUpdate(sql);
			    log.info ("delete old fields for table:"+m_Table.getTableName() +", noColumn:" + no);
			    
				// Delete Columns with the EntityType specified.
				sql = "DELETE AD_Column "
					+ "WHERE AD_Table_ID="+m_Table.getAD_Table_ID()
					+ " AND AD_Column_ID not in ("+m_ColumnList+")"
				    + " AND EntityType='"+m_EntityType+"'";
				no = DB.executeUpdate(sql);
			    log.info ("Delete old columns for table:"+m_Table.getTableName() +", noColumn:" + no);
		    }
*/		    
		    m_ColumnList = "";
		}
		// column elememt, druid
		else if (elementValue.equals(COLUMN_TAG) && druid) {
		    m_Column.save();   // save Column modified by attrib element.
	
		/* ****************************************
		   compieredata Handler.
		   **************************************** */
		// row element, compieredata
		} else if (elementValue.equals(ROWDATA_TAG) && compieredata) {
		    log.fine("END row; TRYING to SAVE +++++++++++++++++++++++++++++++++");
			genericPO.save();
		    genericPO = null;
		}
		// default element, compieredata
		if (elementValue.equals("default") && compieredata) {
		    isDefaultData = false;
		}
    }   // endElement

	/**
	 * 
	 */
	private void doEndField() {
		log.info (FIELD_TAG+" ends.");
		boolean modified = false;
		if (m_Process != null) {
		    log.info (FIELD_TAG+" ends: set ProcessID:"+ m_Process.getAD_Process_ID() +" for column:"+m_Column.getName());
			m_Column.setAD_Process_ID(m_Process.getAD_Process_ID());
			m_Process = null;
			modified = true;
		}
		if (modified)
			m_Column.save();
		m_Field = null;
		m_Column = null;
	}
    
    public void doEndReference() {
    	m_Reference = null;
    	isReference = false;
    }
    
    public void doEndReferenceList() {
    	m_RefList = null;
    	isRefList = false;
    }
    
    public void doEndReferenceTable() {
    	m_Ref_Table = null;
    	isReferenceTale = false;
    }
    
    public void doEndTranslation(String tableName, String columnName) {
    	//String tableName = "AD_Field_Trl"; // "AD_Reference_Trl", "AD_Ref_List_Trl"
    	//String columnName = "AD_Field_ID"; // "AD_Reference_ID",  "AD_Ref_List_ID"
    	
		// TODO update/insert translated record...
		// I need: Language and field
		
		// Having AD_Column we can find to which table it belongs
		//M_Column column = M_Column.get(Env.getCtx(), m_Field.getAD_Column_ID());
		
		// Having AD_Table we can find proper translation table...
		//M_Table table = M_Table.get(Env.getCtx(), m_Column.getAD_Table_ID());
		
		//String lookupTableName = table.getTableName() + "_Trl";
		//String lookupTableID = table.getTableName() + "_ID";
		
		// TODO - Here i need to translate AD_Field_Trl
		String sql = "SELECT * "
				   + " FROM "+tableName+" " 
				   + " WHERE AD_Language = ? "    // #1 AD_Language
				   + "   AND "+columnName+" = ? " // #2 Record ID
		;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		    pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, m_translationLanguage.getAD_Language());
		    if ("AD_Field_ID".equals(columnName)) {
		    	pstmt.setInt(2, m_Field.getAD_Field_ID());
		    } else if ("AD_Reference_ID".equals(columnName)) {
		    	pstmt.setInt(2, m_Reference.getAD_Reference_ID());
		    } else if ("AD_Ref_List_ID".equals(columnName)) {
		    	pstmt.setInt(2, m_RefList.getAD_Ref_List_ID());
		    }
		    
		    
		    rs = pstmt.executeQuery();
		    if (rs.next()) {
		    	
		    	StringBuffer updateSQL = new StringBuffer("UPDATE "+tableName+" SET ");
		    	updateSQL.append("Updated=").append(DB.TO_DATE(m_time, false));
		    	if (trl != null	&& ("Y".equals(trl) || "N".equals(trl))) {
					updateSQL.append(", IsTranslated='").append(trl).append("'");
		    	} else {
					updateSQL.append(", IsTranslated='Y'");
		    	}
		    	if (translationIsActive != null	&& ("Y".equals(translationIsActive) || "N".equals(translationIsActive))) {
					updateSQL.append(", IsActive='").append(translationIsActive).append("'");
		    	} else {
					updateSQL.append(", IsActive='Y'");
		    	}
		    	if (translationName != null ) {
		    		updateSQL.append(", Name='").append(translationName).append("'");
		    	}
		    	if (translationDescription != null ) {
		    		updateSQL.append(", Description='").append(translationDescription).append("'");
		    	}
		    	if (translationHelp != null ) {
		    		updateSQL.append(", Help='").append(translationHelp).append("'");
		    	}
		    	// Where section
				updateSQL.append(" WHERE AD_Language = '").append(m_translationLanguage.getAD_Language()).append("'");
				if (m_AD_Client_ID >= 0) {
					// updateSQL.append(" AND AD_Client_ID=").append(m_AD_Client_ID);
				}
				if ("AD_Field_ID".equals(columnName)) {
					updateSQL.append(" AND AD_Field_ID = ").append(m_Field.getAD_Field_ID());
			    } else if ("AD_Reference_ID".equals(columnName)) {
			    	updateSQL.append(" AND AD_Reference_ID = ").append(m_Reference.getAD_Reference_ID());
			    } else if ("AD_Ref_List_ID".equals(columnName)) {
			    	updateSQL.append(" AND AD_Ref_List_ID = ").append(m_RefList.getAD_Ref_List_ID());
			    }
				
				
		    	int no = DB.executeUpdate(updateSQL.toString(), null);
				if (no == 1)
				{
					if (CLogMgt.isLevelFinest())
						log.fine(updateSQL.toString());
				} else if (no == 0) {
					log.warning ("Not Found - " + updateSQL.toString());
				} else {
					log.severe ("Update Rows=" + no + " (Should be 1) - " + updateSQL.toString());
				}
				
			} else {
				// INSERT INTO table_name (column1, column2,...)
				// VALUES (value1, value2,....)
				StringBuffer insertSQL = new StringBuffer("INSERT INTO "+tableName+" ");
				insertSQL.append(" ( AD_Client_ID, AD_Org_ID, CreatedBy, UpdatedBy, IsActive, IsTranslated, AD_Language");
				if ("AD_Field_ID".equals(columnName)) {
					insertSQL.append(", AD_Field_ID");
			    } else if ("AD_Reference_ID".equals(columnName)) {
			    	insertSQL.append(", AD_Reference_ID");
			    } else if ("AD_Ref_List_ID".equals(columnName)) {
			    	insertSQL.append(", AD_Ref_List_ID");
			    }
				// Name
		    	if (translationName != null ) {
		    		insertSQL.append(", Name");
		    	}
		    	// Description
		    	if (translationDescription != null ) {
		    		insertSQL.append(", Description");
		    	}
		    	// Help
		    	if (translationHelp != null ) {
		    		insertSQL.append(", Help");
		    	}
				
		    	insertSQL.append(" ) VALUES ( ")
				
				// AD_Client_ID
				.append(m_AD_Client_ID)
				// AD_Org_ID
				.append(", 0")
				// CreatedBy
				.append(", 1-0")
				// UpdatedBy
				.append(", 0")
				;
				// IsActive
				if (translationIsActive != null	&& ("Y".equals(translationIsActive) || "N".equals(translationIsActive))) {
					insertSQL.append(", '").append(translationIsActive).append("'");
		    	} else {
					insertSQL.append(", 'Y'");
		    	}
				// IsTranslated
		    	if (trl != null	&& ("Y".equals(trl) || "N".equals(trl))) {
					insertSQL.append(", '").append(trl).append("'");
		    	} else {
					insertSQL.append(", 'Y'");
		    	}
		    	// AD_Language
		    	insertSQL.append(", '").append(m_translationLanguage.getAD_Language()).append("'");
		    	// AD_Field_ID or AD_Reference_ID, AD_Ref_List_ID
		    	if ("AD_Field_ID".equals(columnName)) {
					insertSQL.append(", ").append(m_Field.getAD_Field_ID());
			    } else if ("AD_Reference_ID".equals(columnName)) {
			    	insertSQL.append(", ").append(m_Reference.getAD_Reference_ID());
			    } else if ("AD_Ref_List_ID".equals(columnName)) {
			    	insertSQL.append(", ").append(m_RefList.getAD_Ref_List_ID());
			    }
		    	// Name
		    	log.info ("translationName = " + translationName);
		    	System.out.println ("translationName = " + translationName);
		    	if (translationName != null ) {
		    		insertSQL.append(", '").append(translationName).append("'");
		    	}
		    	// Description
		    	log.info ("translationDescription = " + translationDescription);
		    	System.out.println ("translationDescription = " + translationDescription);
		    	if (translationDescription != null ) {
		    		insertSQL.append(", '").append(translationDescription).append("'");
		    	}
		    	// Help
		    	log.info ("translationHelp = " + translationHelp);
		    	System.out.println("translationHelp = " + translationHelp);
		    	if (translationHelp != null ) {
		    		insertSQL.append(", '").append(translationHelp).append("'");
		    	}
		    	
		    	// END of INSERT SQL
		    	insertSQL.append(" ) ");
		    	
		    	
		    	int no = DB.executeUpdate(insertSQL.toString(), null);
				if (no == 1)
				{
					if (CLogMgt.isLevelFinest())
						log.fine(insertSQL.toString());
				} else if (no == 0) {
					log.warning ("Not Found - " + insertSQL.toString());
				} else {
					log.severe ("INSERTED Rows=" + no + " (Should be 1) - " + insertSQL.toString());
				}
				
			}
		}
		catch (SQLException e) {
			log.severe("Error when executing sql statement:" + e.toString());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException ex) { /* ignored */ }
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException ex) { /* ignored */ }
			}
			pstmt = null;
	    	
			m_translationLanguage = null;
	    	trl = null;
	    	translationIsActive = null;

	    	translationName = null;
	    	translationDescription = null;
			translationHelp = null;
		}
		
    }
    
    public void doEndTranslation_AttribName() {
    	translationName = chracters.toString();
    	isAttribName = false;
    }
    
    public void doEndTranslation_AttribDescription() {
    	translationDescription = chracters.toString();
    	isAttribDescription = false;
    }
    
    public void doEndTranslation_AttribHelp() {
    	translationHelp = chracters.toString();
    	isAttribHelp = false;
    }
    
}

