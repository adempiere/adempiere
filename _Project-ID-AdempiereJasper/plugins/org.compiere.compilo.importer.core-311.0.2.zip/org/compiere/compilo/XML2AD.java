package org.compiere.compilo;

import java.io.File;
import java.util.logging.Level;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.compiere.db.CConnection;
import org.compiere.db.Database;
import org.compiere.util.CLogMgt;
import org.compiere.util.CLogger;
import org.compiere.util.DB;
import org.compiere.util.Ini;

/**
 *  XML2AD Compilo tool.
 *
 *  @author Marco LOMBARDO, lombardo@mayking.com
 */
public class XML2AD {

    /**	Logger						*/
    //private Logger log = Logger.getCLogger(getClass());
    private CLogger	log = CLogger.getCLogger(XML2AD.class); //@Trifon

    /**
     * 	Uses XML2ADHandler to update AD.
     *	@param fileName xml file to read
     * 	@return status message
     */
    public String importXML (String fileName) {
    	log.entering("XML2AD", "importXML", "fileName=" + fileName);
    	
		File in = new File (fileName);
		if (!in.exists()) {
		    String msg = "File does not exist: " + fileName;
		    log.log(Level.SEVERE, msg);
		    return msg;
		}
		try {
		    XML2ADHandler handler = new XML2ADHandler();
		    SAXParserFactory factory = SAXParserFactory.newInstance();
		    SAXParser parser = factory.newSAXParser();
		    parser.parse(in, handler);
		    return "OK.";
		}
		catch (Exception e) {
			log.log(Level.SEVERE,"importXML:", e);
		    return e.toString();
		}
    }
    
    /*****************************************************
     *
     * 	@param args XMLfile host port db username password
     */
    public static void main (String[] args) {
		if (args.length < 1) {
		    System.out.println("Please give the file name to read as first parameter.");
		    System.exit(1);
		}
		boolean isClient = true; //@Trifon
		String file = args[0];
		File f = null; 
		//Properties ctx;

		Ini.setClient (isClient); //@Trifon
		org.compiere.Adempiere.startup(isClient); // @Trifon

		// Thanks to Neil from South Africa.
		if (args.length < 1) { 
		 	 
		 	//ctx = org.compiere.util.Env.getCtx(); 
		 	//f = JFileChooser.getFile(ctx, "Select a file", "xml");
		 	//f = FileChooserManager.getFile(ctx, "Select a file", "xml");
			if (f==null) 
			{ 
				return; 
			} 
			file=f.getAbsolutePath(); 
		} else { 
			file = args[0]; 
		}
		
		// Force connection if there are enough parameters. Else we work with Compiere.properties
		if (args.length >= 6) {
		    CConnection cc = CConnection.get(Database.DB_ORACLE, args[1], Integer.valueOf(args[2]).intValue(), args[3], args[4], args[5]);
		    System.out.println("DB UserID:"+cc.getDbUid());
		    DB.setDBTarget(cc);
		}
	
		// Adjust trace level. Or it will be taken from Compiere.properties
		// TODO: have a parameter for the trace level.
		// log.setTraceLevel(2); //@Trifon
		// Ini.setProperty(Ini.P_DEBUGLEVEL, String.valueOf(2)); //@Trifon
		// CLogMgt.setLevel(Ini.getProperty(Ini.P_TRACELEVEL)); //@Trifon
		CLogMgt.setLevel(Level.FINEST); //@Trifon
		/* 
		 Level.OFF, Level.SEVERE, Level.WARNING, Level.INFO,
		Level.CONFIG, Level.FINE, Level.FINER, Level.FINEST, Level.ALL
		*/
	
		XML2AD impXML = new XML2AD();
		impXML.importXML(file);
		
		System.exit(0);
    }   // main

}   // XML2AD

// Marco LOMBARDO, 2004-08-20, Italy.
// lombardo@mayking.com