package org.compiere.compilo.helper;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.compiere.util.CLogger;
import org.compiere.util.DB;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLHelper {

	/**	Logger			*/
	private static CLogger	log = CLogger.getCLogger(XMLHelper.class); //@Trifon
	
	private static XPath xPath = XPathFactory.newInstance().newXPath();
	  
//	 GENERIC FUNCTION - SQL, XML and XPATH ones
//	 can be in separate class in future
	  
//	 XPath generic functions - they retrieve NodeList, Node, (String) Node, (Double) Node, (Boolean) Node, (Element) Node
//	 do not use them more, than needed - very slow!
	  public static Element getElement(String xPathExpression, Node node) throws XPathExpressionException {
	      return (Element) xPath.evaluate(xPathExpression, node, XPathConstants.NODE);
	  }
	  
	  public static Node getNode(String xPathExpression, Node node) throws XPathExpressionException {
	      return (Node) xPath.evaluate(xPathExpression, node, XPathConstants.NODE);
	  }
	  
	  public static NodeList getNodeList(String xPathExpression, Node node) throws XPathExpressionException {
	      return (NodeList) xPath.evaluate(xPathExpression, node, XPathConstants.NODESET);
	  }
	  
	  public static Double getNumber(String xPathExpression, Node node) throws XPathExpressionException {
	      return (Double) xPath.evaluate(xPathExpression, node, XPathConstants.NUMBER);
	  }
	  
	  public static String getString(String xPathExpression, Node node) throws XPathExpressionException {
	      return (String) xPath.evaluate(xPathExpression, node, XPathConstants.STRING);
	  }
	  
	  public static Boolean getBoolean(String xPathExpression, Node node) throws XPathExpressionException {
	      return (Boolean) xPath.evaluate(xPathExpression, node, XPathConstants.BOOLEAN);
	  }
	  
		// RegExp change global variables in SQL SELECT statement using regular expression
		public static String replaceGlobalVariable(String tableSql, HashMap globalVariables) {
			Set set = globalVariables.entrySet();

			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {// walk through each global variables pair
				Map.Entry entry = (Map.Entry) iterator.next();
				
				String key = (String) entry.getKey();
				String value = (String) entry.getValue();
				// here can be an error - should be tested by users
				tableSql = tableSql.replaceAll("\\" + key + "{1,}", value); // replace it
			}
			return tableSql;
		}

		
	public static String getColumnValueAsString(ResultSet resultSet, int columnIndex, String charsetName) 
		throws SQLException 
	{
		ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

		switch (resultSetMetaData.getColumnType(columnIndex)) {
		// I need to know, where are these codes defined on Java.Sun.Com to be
		// sure they are OK. Help needed!
		case 12: // VARCHAR
		case 1: // CHAR
		case -1: // LONGVARCHAR
		{
			/*
			 * byte[] byteArray = resultSet.getBytes(columnIndex); if
			 * (resultSet.wasNull()) { return "null"; } else { //String
			 * stringFromChar = new String(byteArray, charsetName);
			 * System.out.println("@Trifon1 -- " + new String(byteArray));
			 * System.out.println("@Trifon2 -- " + new String(byteArray,
			 * charsetName)); String stringFromChar = new String(byteArray);
			 * return stringFromChar; }//end_if-else
			 */
			String res = resultSet.getString(columnIndex);
			return res;
		}
		case 8: // DOUBLE
		case 4: // INTEGER
		case -5: // BIGINT
		case -6: // TINYINT
		case 5: // SMALLINT
		case 7: // REAL
		case 6: // FLOAT
		case 3: // DECIMAL
		case 2: // NUMERIC
		case -7: // BIT
			String stringFromNumeric = resultSet.getString(columnIndex);
			if (resultSet.wasNull()) {
				return "null";
			} else {
				return stringFromNumeric;
			}// end_if-else
		case -2: // BINARY
		case -3: // VARBINARY
		case -4: // LONGVARBINARY
			String stringFromBinary = resultSet.getString(columnIndex);
			if (resultSet.wasNull()) {
				return "null";
			} else {
				return stringFromBinary;
			}// end_if-else
		case 91: // DATE
			java.sql.Date date = resultSet.getDate(columnIndex);
			if (resultSet.wasNull()) {
				return "null";
			} else {
				return date.toString();
			}// end_if-else
		case 92: // TIME
			java.sql.Time time = resultSet.getTime(columnIndex);
			if (resultSet.wasNull()) {
				return "null";
			} else {
				return time.toString();
			}// end_if-else
		case 93: // TIMESTAMP
			java.sql.Timestamp timestamp = resultSet.getTimestamp(columnIndex);
			if (resultSet.wasNull()) {
				return "null";
			} else {
				return timestamp.toString();
			}// end_if-else
		default:
			return "unsupported data type (CLOB and BLOB should be, ARRAY, REF, STRUCT, JAVA OBJECT hard to be)";
		}// end_switch

	}

	/**
	 * Get ID from Name for a table.
	 *
	 * @param tableName
	 * @param name
	 */
	public static int getIDbyName (String tableName, String name, String clientValue) {
		int id = 0;
		int AD_Client_ID = 0;
		
		String sql = "SELECT " + tableName + "_ID \n"
		           + "FROM " + tableName + " \n"
				   + "WHERE Name=? \n";
		
		if (!tableName.startsWith("AD_")) {
		    sql = sql + " AND AD_Client_ID=?";
	
		    if (clientValue != null && !"".equals(clientValue)) {
				AD_Client_ID = getIDbyValue("AD_Client", clientValue, null);
			}
		}
	
		//log.finer("SQL = \n" + sql);
		//log.finer("AD_Client_ID = " + AD_Client_ID);
	
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    if (!tableName.startsWith("AD_"))
		    	pstmt.setInt(2, AD_Client_ID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "getID:"+e);
		}
		return id;
	}

	public static int getIDbyValue (String tableName, String value, String clientValue) {
		int id = 0;
		int AD_Client_ID = 0;
		
		String sql = "SELECT " + tableName + "_ID \n"
		           + "FROM " + tableName + " \n"
				   + "WHERE Value=? \n";
		
		if (!tableName.startsWith("AD_")) {
		    sql = sql + " AND AD_Client_ID=?";
	
		    if (clientValue != null && !"".equals(clientValue)) {
				AD_Client_ID = getIDbyValue("AD_Client", clientValue, null);
			}
		}
	
		//log.finer("SQL = \n" + sql);
		//System.out.println("SQL = \n" + sql);
		//log.finer("AD_Client_ID = " + AD_Client_ID);
		//System.out.println("AD_Client_ID = " + AD_Client_ID);
	
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, value);
		    if (!tableName.startsWith("AD_"))
		    	pstmt.setInt(2, AD_Client_ID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "getID:"+e);
		}
		return id;
	}

	/**
	 * Get ID from column value for a table.
	 *
	 * @param tableName
	 * @param AD_Client_ID TODO
	 * @param columName
	 * @param name
	 */
	public static int getIDWithColumn (String tableName, String columnName, Object value, int AD_Client_ID) {
		int id = 0;
		String sql = "SELECT " + tableName + "_ID "
				   + " FROM " + tableName + " "
				   + " WHERE " + columnName + "=?";
		if (!tableName.startsWith("AD_"))
		    sql = sql + " and AD_Client_ID=?";
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    if (value instanceof String)
		    	pstmt.setString(1, (String)value);
		    else if (value instanceof Integer)
		    	pstmt.setInt(1, ((Integer)value).intValue());
		    if (!tableName.startsWith("AD_"))
		    	pstmt.setInt(2, AD_Client_ID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		return id;
	}

	/**
	 * Get ID from Name for a table with a Master reference.
	 *
	 * @param tableName
	 * @param name
	 * @param tableNameMaster
	 * @param nameMaster
	 */
	public static int getIDWithMasterAndColumn (String tableName, String columnName, String name, String tableNameMaster, int masterID) {
		int id = 0;
		String sql = "SELECT "+tableName+"_ID "
				   + " FROM "+tableName+" "
				   + " WHERE "+columnName+"=? " // #1
				   + "  AND "
				   + tableNameMaster+"_ID =?";  // #2
		log.log(Level.FINEST, "sql:\n" + sql);
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, name);
		    pstmt.setInt(2, masterID);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	id = rs.getInt(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.log(Level.SEVERE, "" + e);
		}
		return id;
	}

	/**
     * Reverse the value of a Reference
     *
     * @param referenceName
     * @param value
     */
    public static String reverseReference (String referenceName, String name) {
		String retValue = null;
		String sql = 
			  "SELECT Value "
			+ "FROM AD_Ref_List "
			+ "WHERE AD_Reference_ID = "
		    + "  (SELECT AD_Reference_ID "
			+ "   FROM AD_Reference "
			+ "   WHERE Name=?)"
		    + "    AND Name=?";
		try {
		    PreparedStatement pstmt = DB.prepareStatement(sql, null);
		    pstmt.setString(1, referenceName);
		    pstmt.setString(2, name);
		    ResultSet rs = pstmt.executeQuery();
		    if (rs.next())
		    	retValue = rs.getString(1);
		    rs.close();
		    pstmt.close();
		    pstmt = null;
		}
		catch (Exception e) {
			log.severe("reverseRefernce:"+e);
		}
		return retValue;
    }

}
