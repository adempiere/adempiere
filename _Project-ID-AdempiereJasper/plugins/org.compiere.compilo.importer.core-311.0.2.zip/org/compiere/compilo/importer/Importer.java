package org.compiere.compilo.importer;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.compiere.compilo.helper.XMLHelper;
import org.compiere.compilo.importer.core.ImportException;
import org.compiere.compilo.importer.core.TableImporter;
import org.compiere.model.MRoleOrgAccess;
import org.compiere.model.X_AD_Column_Access;
import org.compiere.model.X_AD_Form_Access;
import org.compiere.model.X_AD_Process_Access;
import org.compiere.model.X_AD_User_Roles;
import org.compiere.model.X_AD_Window_Access;
import org.compiere.model.X_AD_Workflow_Access;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class Importer {

	//private CLogger	log = CLogger.getCLogger(Importer.class); //@Trifon
	private Log log = LogFactory.getLog(Importer.class);
	
	private int i = 0;
	
	private String pathToXsdFile = "";
	
	private String pathToMappingXmlFile = "";
	
	private String namesOfGlobalVariables;

	private String valuesOfGlobalVariables;

	private String pathToOutputXmlFile;

	// fields to be global visible
	private HashMap globalVariables = new HashMap();

	private Connection connection;

	private Statement statement;

	private Document outDocument;

	private boolean multiStatementDatabase;

	private String globalCharsetName;
	
	
	/**
	 * Creates a <code>dbsql2xml</code> for output to <code>File</code>.
	 * 
	 * @param pathToMappingXmlFile
	 *            e.g "treeXMLMapping.xml"
	 * @param pathToXsdFile
	 *            e.g. "dbsql2xml.xsd"
	 * @param namesOfGlobalVariables
	 *            e.g. "$gvG01#$gvG02#$gvG03" or "myVarX#myVarY#myVarZ"
	 * @param valuesOfGlobalVariables
	 *            e.f "01#John Smith#2005-05-10"
	 * @param pathToOutputXmlFile
	 *            e.g "treeXMLOut.xml" <br />
	 *            <br />
	 *            token, which delimites names and values of global variables,
	 *            is set in mapping XML file inside element
	 *            <code>tokenForCommandLineStringArrays</code> <br />
	 *            it can be single or multiple character <br />
	 *            token is the same for names and values of global variables
	 *            <br />
	 *            <br />
	 *            So example of creating <code>dbsql2xml</code> object is:
	 *            <br />
	 *            <code>dbsql2xml myDbSql2Xml = new dbsql2xml("treeXMLMapping.xml", "dbsql2xml.xsd", "$gvG01", "001", "treeXMLOut.xml");</code>
	 *            <br />
	 *            See example in distribution (standalone application and
	 *            servlet).
	 */
	// constructor for output into File
	public Importer(String pathToMappingXmlFile, String pathToXsdFile,
			String namesOfGlobalVariables, String valuesOfGlobalVariables,
			String pathToOutputXmlFile) {
		this.pathToMappingXmlFile = pathToMappingXmlFile;
		this.pathToXsdFile = pathToXsdFile;
		this.namesOfGlobalVariables = namesOfGlobalVariables;
		this.valuesOfGlobalVariables = valuesOfGlobalVariables;
		this.pathToOutputXmlFile = pathToOutputXmlFile;
		this.connection = null;
	}
	
	void checkInputParameters() throws IllegalArgumentException {
		if (pathToMappingXmlFile == null || pathToMappingXmlFile == "") {
			throw new IllegalArgumentException("No mapping XML file specified.");
		}// end_if
		if (pathToXsdFile == null || pathToXsdFile == "") {
			throw new IllegalArgumentException("No XML Schema specified.");
		}// end_if
		if (namesOfGlobalVariables == null || valuesOfGlobalVariables == null) {
			namesOfGlobalVariables = "";
			valuesOfGlobalVariables = "";
		}// end_if

	}
	
	// SQL generic functions
	Connection getConnection(String jdbcDriver, String jdbcUrl,
			String jdbcUserName, String jdbcPassword) throws SQLException,
			ClassNotFoundException {
		Class.forName(jdbcDriver);
		Connection connection = DriverManager.getConnection(jdbcUrl,
				jdbcUserName, jdbcPassword);
		DatabaseMetaData databaseMetaData = connection.getMetaData();
		String databaseProductName = databaseMetaData.getDatabaseProductName();
		if (databaseProductName.indexOf("Microsoft SQL Server") > -1
				|| databaseProductName.indexOf("ACCESS") > -1
				|| databaseProductName.indexOf("Oracle") > -1
		) {
			multiStatementDatabase = true;
		} else {
			multiStatementDatabase = false;
		}// end_if-else
		return connection;
	}
	
	
	String getApplicationInfo() {
		String string = "The \"importer\" is Java tool (class) for transforming (importing) hierarchical XML into Compiere Application.\nFor more information, see http://sourceforge.net/projects/comxe/";
		return string;
	}
	
	// create new Document
	Document createNewDocument() throws ParserConfigurationException {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		return documentBuilder.newDocument();

	}
	
	// Created Plugin architecture.
	// This file must call plugin which is registered and resposible to load given class...
	// Else i need to support new version of xml2D for every customization... :(
	// Done :)
	public void doImportFromFile(List plugins) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, SQLException, ClassNotFoundException, TransformerException, DOMException, ImportException {
		try {
			checkInputParameters();
			
			// load mapping (configuration) XML file
			Document document = createDocumentFromFile();

			// load global variables from constructors parameters and mapping XML file
			// TODO
			//loadGlobalVariables(namesOfGlobalVariables,	valuesOfGlobalVariables, document);

			if (connection == null) {
				// get jdbc connection parameters from XML file and connect to
				// the database
				String jdbcDriver   = null;
				String jdbcURL      = null;
				String jdbcUserName = null;
				String jdbcPassword = null;
				
				jdbcDriver = XMLHelper.getString(
						"compieredata/connectionProperties/jdbcDriver", document);
				jdbcURL = XMLHelper.getString(
						"compieredata/connectionProperties/jdbcURL", document);
				jdbcUserName = XMLHelper.getString(
						"compieredata/connectionProperties/jdbcUserName", document);
				jdbcPassword = XMLHelper.getString(
						"compieredata/connectionProperties/jdbcPassword", document);
				
				// Trifon; Add functionality to get Driver, URL, UserName and Password from System properties
				
				if (jdbcDriver == null || jdbcDriver.equals("")
						|| jdbcURL == null || jdbcURL.equals("") 
						|| jdbcUserName == null || jdbcUserName.equals("")
						|| jdbcPassword == null || jdbcPassword.equals("")
				) {
					jdbcDriver   = System.getProperty("jdbcDriver");
					jdbcURL      = System.getProperty("jdbcURL");
					jdbcUserName = System.getProperty("jdbcUserName");
					jdbcPassword = System.getProperty("jdbcPassword");
				}
				System.out.println("jdbcDriver   = " + jdbcDriver);
				System.out.println("jdbcURL      = " + jdbcURL);
				System.out.println("jdbcUserName = " + jdbcUserName);
				System.out.println("jdbcPassword = " + jdbcPassword);
				
				connection = getConnection(jdbcDriver, jdbcURL, jdbcUserName, jdbcPassword);
				
			}// end_if
			statement = connection.createStatement();

			// create output XML document
			outDocument = createNewDocument();
			// create root element of output XML document
			
			String rootName = "out";
			Element resultRootElement = outDocument.createElement(rootName);

			resultRootElement.appendChild(outDocument.createComment(getApplicationInfo()));
			outDocument.appendChild(resultRootElement);

			globalCharsetName = XMLHelper.getString("compieredata/globalCharsetName",	document);
			// load data from database to hierarchical XML document
			
			NodeList ad_Role_OrgAccess_NodeList = XMLHelper.getNodeList("/compieredata/AD_Role_OrgAccess", document);
			for (int indx = 0; indx < ad_Role_OrgAccess_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Role_OrgAccess_NodeList.item(indx);
				process_AD_Role_OrgAccess(currentNode, resultRootElement);				
			}
			
			NodeList ad_User_Roles_NodeList = XMLHelper.getNodeList("/compieredata/AD_User_Roles", document);
			for (int indx = 0; indx < ad_User_Roles_NodeList.getLength(); indx ++) {
				Node currentNode = ad_User_Roles_NodeList.item(indx);
				process_AD_User_Roles(currentNode, resultRootElement);				
			}
			
			NodeList ad_Window_Access_NodeList = XMLHelper.getNodeList("/compieredata/AD_Window_Access", document);
			for (int indx = 0; indx < ad_Window_Access_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Window_Access_NodeList.item(indx);
				process_AD_Window_Access(currentNode, resultRootElement);				
			}
			
			NodeList ad_Process_Access_NodeList = XMLHelper.getNodeList("/compieredata/AD_Process_Access", document);
			for (int indx = 0; indx < ad_Process_Access_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Process_Access_NodeList.item(indx);
				process_AD_Process_Access(currentNode, resultRootElement);				
			}
			
			NodeList ad_Workflow_Access_NodeList = XMLHelper.getNodeList("/compieredata/AD_Workflow_Access", document);
			for (int indx = 0; indx < ad_Workflow_Access_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Workflow_Access_NodeList.item(indx);
				process_AD_Workflow_Access(currentNode, resultRootElement);				
			}
			
			NodeList ad_Column_Access_NodeList = XMLHelper.getNodeList("/compieredata/AD_Column_Access", document);
			for (int indx = 0; indx < ad_Column_Access_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Column_Access_NodeList.item(indx);
				process_AD_Column_Access(currentNode, resultRootElement);				
			}
			
			NodeList ad_Form_Access_NodeList = XMLHelper.getNodeList("/compieredata/AD_Form_Access", document);
			for (int indx = 0; indx < ad_Form_Access_NodeList.getLength(); indx ++) {
				Node currentNode = ad_Form_Access_NodeList.item(indx);
				process_AD_Form_Access(currentNode, resultRootElement);				
			}
			
			if (plugins != null) {
				
				// Iterate all plugins
				// Probably this is not the best strategy to implement plugin architecture.
				// If we have many plugins it will became slow...
				for (int i = 0; i < plugins.size(); i++) {
					TableImporter importPlugin = (TableImporter)plugins.get(i);
					
					String rootElement = "compieredata";
					if (importPlugin.getRootElement() != null) {
						rootElement = importPlugin.getRootElement(); 
					}
					
					String tables = importPlugin.getTableName();
					
					// Create functionality which tokenize tables variable and extract individual table name.
					StringTokenizer tokenizer = new StringTokenizer(tables, ",");
					int numTokes = tokenizer.countTokens();

					for (int j = 0; j < numTokes; j++) {
						String tableName = tokenizer.nextToken();
							
						// Get all XML elements
						NodeList nodeList = XMLHelper.getNodeList("/" + rootElement + "/" + tableName, document);
						
						for (int indx = 0; indx < nodeList.getLength(); indx ++) {
							Node currentNode = nodeList.item(indx);
							
							// Plugin is responsible to import one record at a time
							importPlugin.importTable(currentNode, resultRootElement);				
						}
					}
					
				}				
			}

			// save output XML document into file (later somewhere else)
			outDocument.normalize();// JDK-1.4
			//outDocument.normalizeDocument(); //JDK-1.5
			

			// append to or process output XML document XSLT or CSS (if any) in mapping file
			// TODO;
			// Element processingInstructionsElement = XMLHelper.getElement("config/processingInstructions", document);
			//doProcessingInstructions(processingInstructionsElement, rootElement);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			Source source = new DOMSource(outDocument);
			StreamResult streamResult = new StreamResult(new File(pathToOutputXmlFile));
			transformer.transform(source, streamResult);
	
			System.out.println("Should be done.");
		} finally {
			// close files and JDBC connection
			if (statement != null) {
				try {
					statement.close();
				} catch (Exception e) { /* ignored */ }
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) { /* ignored */ }
			}
		}
	}
	
	private Document createDocumentFromFile() throws ParserConfigurationException,
		SAXException, IOException 
	{
		// path to file is global
		String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
		String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
		String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
		
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		// validate against XML Schema in dbsql2xml.xsd
		documentBuilderFactory.setNamespaceAware(true);
		// TODO change validation to true.
		// Someday when xsd file is complete...
		documentBuilderFactory.setValidating(false);
		documentBuilderFactory.setAttribute(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
		documentBuilderFactory.setAttribute(JAXP_SCHEMA_SOURCE, new File(pathToXsdFile));
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.parse(new File(pathToMappingXmlFile));
		
		return document;
	}
	
	void processAttributeElement(Element attributeElement, ResultSet resultSet,
			Element parentElement) throws SQLException 
	{
		
		String name = attributeElement.getAttribute("xmlName");
		String sqlName = attributeElement.getAttribute("sqlName");
		System.out.println("--- sqlName = " + sqlName);
		String value = attributeElement.getAttribute("value");
		String globalVariableName = attributeElement.getAttribute("globalVariableName");
		String charsetName = attributeElement.getAttribute("charsetName");
		String sqlStmt = attributeElement.getAttribute("sqlStmt");
		
		if (charsetName == null || charsetName == "") {
			charsetName = globalCharsetName;
		}
		String isOutTXT = attributeElement.getAttribute("isOut");
		// If "isOut" is true then will include current column to generated
		// document
		boolean isOut = true;
		if (null != isOutTXT && !"".equals(isOutTXT)) {
			if (isOutTXT.equals("N")) {
				isOut = false;
			}
		}
		
		if (null != value && !"".equals(value)) {
			// parentElement.setAttribute(name, value);
			value = XMLHelper.replaceGlobalVariable(value, globalVariables); // replace global
			
		} else if (null != sqlName && !"".equals(sqlName)) {
			// index of this attribute in the ResultSet
			int columnIndex = resultSet.findColumn(sqlName);
			
			value = XMLHelper.getColumnValueAsString(resultSet, columnIndex, charsetName);
			// should become this column value become global variable for
			// other SQL selects?
			if (globalVariableName != null) {
				globalVariables.put(globalVariableName, value);
			}
		} else if (sqlStmt != null && !"".equals(sqlStmt)) {
			sqlStmt = XMLHelper.replaceGlobalVariable(sqlStmt, globalVariables); // replace global
			// variables names
			// by their values
			//ResultSet resSet = getResultSet(sqlStmt);
			ResultSet resSet = null;
			Statement statement = null;
			if (multiStatementDatabase) {
				statement = connection.createStatement();
				System.out.println(i++);
				System.out.println(sqlStmt);
				System.out.println("===================================");
				resSet = statement.executeQuery(sqlStmt);
			} else {
				resSet = statement.executeQuery(sqlStmt);
			}
			// int columnIndex = resultSet.findColumn(sqlName);//index of
			// this attribute in the ResultSet
			int columnIndex = 1;
			if (resSet.next()) {
				value = XMLHelper.getColumnValueAsString(resSet, columnIndex, charsetName);
			}

			// should become this column value become global variable for
			// other SQL selects?
			if (globalVariableName != null && !"".equals(globalVariableName)) {
				globalVariables.put(globalVariableName, value);
			}
			i--;
			statement.close(); // @Trifon
			statement = null; // @Trifon
			resSet.close(); // @Trifon
			resSet = null; // @Trifon
		}
		if (isOut) {
			// Add only if Value is not empty...
			if (value != null && !"".equals(value)) {
				parentElement.setAttribute(name, value);
			}
		}

	}
	
	public void process_AD_Role_OrgAccess(Node AD_Role_OrgAccess_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Role_OrgAccess_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Role_OrgAccess_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Role_OrgAccess_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Role_OrgAccess "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    MRoleOrgAccess roleOrgAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	roleOrgAccess = new MRoleOrgAccess(Env.getCtx(), rs, null);	    	
	    } else {
	    	log.info("--- Record NOT FOUND ---");
	    	roleOrgAccess = new MRoleOrgAccess(Env.getCtx(), 0, null);
	    }
		
		//roleOrgAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		roleOrgAccess.setAD_Org_ID(AD_Org_ID);
		roleOrgAccess.setAD_Role_ID(AD_Role_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Role_OrgAccess_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			roleOrgAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsReadOnly = XMLHelper.getString("IsReadOnly", AD_Role_OrgAccess_node);
		log.info("IsReadOnly = " + IsReadOnly);
		if (IsReadOnly != null && !"".equals(IsReadOnly)) {
			roleOrgAccess.setIsReadOnly(IsReadOnly.equals("Y") ? true : false);
		}
		
		boolean resultSave = roleOrgAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}

	public void process_AD_User_Roles(Node AD_Role_OrgAccess_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_User_Name = null;
		int    AD_User_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Role_OrgAccess_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Role_OrgAccess_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Role_OrgAccess_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		 
		AD_User_Name = XMLHelper.getString("AD_User_Name", AD_Role_OrgAccess_node);
		log.info("AD_User_Name = [" + AD_User_Name +"]");
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		// Search for AD_User by Name...
		AD_User_ID = XMLHelper.getIDbyName("AD_User", AD_User_Name, AD_Client_Value);
		log.info("AD_User_ID = " + AD_User_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_User_Name == null || "".equals(AD_User_Name)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_User_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_User_Name or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_User_Name or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_User_Roles "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_User_ID = ? "    // #4
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_User_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_User_Roles userRoles = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next() ) {
	    	log.info("--- Record FOUND ---");
	    	userRoles = new X_AD_User_Roles(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	userRoles = new X_AD_User_Roles(Env.getCtx(), 0, null);
	    }
		
		//userRoles.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		userRoles.setAD_Org_ID(AD_Org_ID);
		userRoles.setAD_Role_ID(AD_Role_ID);
		userRoles.setAD_User_ID(AD_User_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Role_OrgAccess_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			userRoles.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		boolean resultSave = userRoles.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}
	
	public void process_AD_Window_Access(Node AD_Window_Access_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Window_Name = null;
		int    AD_Window_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Window_Access_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Window_Access_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Window_Access_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		
		AD_Window_Name = XMLHelper.getString("AD_Window_Name", AD_Window_Access_node);
		log.info("AD_Window_Name = [" + AD_Window_Name +"]");
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		// Search for AD_Window by Name...
		AD_Window_ID = XMLHelper.getIDbyName("AD_Window", AD_Window_Name, AD_Client_Value);
		log.info("AD_Window_ID = " + AD_Window_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_Window_Name == null || "".equals(AD_Window_Name)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Window_Name or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Window_Name or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Window_Name or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Window_Access "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_Window_ID = ? "  // #4
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_Window_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_Window_Access windowAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	windowAccess = new X_AD_Window_Access(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	windowAccess = new X_AD_Window_Access(Env.getCtx(), 0, null);
	    }
		
		//windowAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		windowAccess.setAD_Org_ID(AD_Org_ID);
		windowAccess.setAD_Role_ID(AD_Role_ID);
		windowAccess.setAD_Window_ID(AD_Window_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Window_Access_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			windowAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsReadWrite = XMLHelper.getString("IsReadWrite", AD_Window_Access_node);
		log.info("IsReadWrite = " + IsReadWrite);
		if (IsReadWrite != null && !"".equals(IsReadWrite)) {
			windowAccess.setIsReadWrite(IsReadWrite.equals("Y") ? true : false);
		}
		
		boolean resultSave = windowAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}

	public void process_AD_Process_Access(Node AD_Process_Access_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		Element result = outDocument.createElement("AD_Process_Access");
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Process_Value = null;
		int    AD_Process_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Process_Access_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		result.appendChild(createNewTextElement("AD_Client_Value", ""+AD_Client_Value));
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Process_Access_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		result.appendChild(createNewTextElement("AD_Org_Value", ""+AD_Org_Value));
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Process_Access_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		result.appendChild(createNewTextElement("AD_Role_Name", ""+AD_Role_Name));
		
		AD_Process_Value = XMLHelper.getString("AD_Process_Value", AD_Process_Access_node);
		log.info("AD_Process_Value = [" + AD_Process_Value +"]");
		result.appendChild(createNewTextElement("AD_Process_Value", ""+AD_Process_Value));
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		result.appendChild(createNewTextElement("AD_Client_ID", ""+AD_Client_ID));
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		result.appendChild(createNewTextElement("AD_Org_ID", ""+AD_Org_ID));
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		result.appendChild(createNewTextElement("AD_Role_ID", ""+AD_Role_ID));
		
		// Search for AD_Process by Value...
		AD_Process_ID = XMLHelper.getIDbyValue("AD_Process", AD_Process_Value, AD_Client_Value);
		log.info("AD_Process_ID = " + AD_Process_ID);
		result.appendChild(createNewTextElement("AD_Process_ID", ""+AD_Process_ID));
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_Process_Value == null || "".equals(AD_Process_Value)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Process_Value or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Process_Value or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Process_Value or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Process_Access "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_Process_ID = ? "  // #4
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_Process_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_Process_Access processAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		result.appendChild(createNewTextElement("CreatedBy_ID", ""+CreatedBy_ID));
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	result.appendChild(createNewTextElement("recordFound", "true"));
	    	processAccess = new X_AD_Process_Access(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	result.appendChild(createNewTextElement("recordFound", "false"));
	    	processAccess = new X_AD_Process_Access(Env.getCtx(), 0, null);
	    }
		
		//processAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		processAccess.setAD_Org_ID(AD_Org_ID);
		processAccess.setAD_Role_ID(AD_Role_ID);
		processAccess.setAD_Process_ID(AD_Process_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Process_Access_node);
		log.info("IsActive = " + IsActive);
		result.appendChild(createNewTextElement("IsActive", IsActive));
		if (IsActive != null && !"".equals(IsActive)) {
			processAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsReadWrite = XMLHelper.getString("IsReadWrite", AD_Process_Access_node);
		log.info("IsReadWrite = " + IsReadWrite);
		result.appendChild(createNewTextElement("IsReadWrite", IsReadWrite));
		if (IsReadWrite != null && !"".equals(IsReadWrite)) {
			processAccess.setIsReadWrite(IsReadWrite.equals("Y") ? true : false);
		}
		
		boolean resultSave = processAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
		result.appendChild(createNewTextElement("result", ""+resultSave));
		
		outElement.appendChild(result);
	}
	
	private Element createNewTextElement(String elementName, String textNodeValue) {
		Element newElement = outDocument.createElement(elementName);
		
		Text newText = outDocument.createTextNode(textNodeValue);
		
		newElement.appendChild(newText);
		
		return newElement;
	}
	
	public void process_AD_Workflow_Access(Node AD_Workflow_Access_node, Element outElement)
	throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Workflow_Value = null;
		int    AD_Workflow_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Workflow_Access_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Workflow_Access_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Workflow_Access_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		
		AD_Workflow_Value = XMLHelper.getString("AD_Workflow_Value", AD_Workflow_Access_node);
		log.info("AD_Workflow_Value = [" + AD_Workflow_Value +"]");
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		// Search for AD_Process by Value...
		AD_Workflow_ID = XMLHelper.getIDbyValue("AD_Workflow", AD_Workflow_Value, AD_Client_Value);
		log.info("AD_Workflow_ID = " + AD_Workflow_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_Workflow_Value == null || "".equals(AD_Workflow_Value)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Workflow_Value or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Workflow_Value or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Workflow_Value or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Workflow_Access "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_Workflow_ID = ? "  // #4
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_Workflow_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_Workflow_Access workflowAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	workflowAccess = new X_AD_Workflow_Access(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	workflowAccess = new X_AD_Workflow_Access(Env.getCtx(), 0, null);
	    }
		
	    //workflowAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
	    workflowAccess.setAD_Org_ID(AD_Org_ID);
	    workflowAccess.setAD_Role_ID(AD_Role_ID);
	    workflowAccess.setAD_Workflow_ID(AD_Workflow_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Workflow_Access_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			workflowAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsReadWrite = XMLHelper.getString("IsReadWrite", AD_Workflow_Access_node);
		log.info("IsReadWrite = " + IsReadWrite);
		if (IsReadWrite != null && !"".equals(IsReadWrite)) {
			workflowAccess.setIsReadWrite(IsReadWrite.equals("Y") ? true : false);
		}
		
		boolean resultSave = workflowAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}

	public void process_AD_Column_Access(Node AD_Column_Access_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Column_ColumnName = null;
		int    AD_Column_ID = 0;
		
		String AD_Table_TableName = null;
		int    AD_Table_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Column_Access_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Column_Access_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Column_Access_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		
		AD_Column_ColumnName = XMLHelper.getString("AD_Column_ColumnName", AD_Column_Access_node);
		log.info("AD_Column_ColumnName = [" + AD_Column_ColumnName +"]");
		
		AD_Table_TableName = XMLHelper.getString("AD_Table_TableName", AD_Column_Access_node);
		log.info("AD_Table_TableName = [" + AD_Table_TableName +"]");
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		// Search for AD_Table by TableName...
		AD_Table_ID = XMLHelper.getIDWithColumn("AD_Table", "TableName", AD_Table_TableName, AD_Client_ID);
		log.info("AD_Table_ID = " + AD_Table_ID);
		
		// Search for AD_Column by ColumnName...
		AD_Column_ID = XMLHelper.getIDWithMasterAndColumn("AD_Column", "ColumnName", AD_Column_ColumnName, "AD_Table", AD_Table_ID);
		log.info("AD_Column_ID = " + AD_Column_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_Table_TableName == null || "".equals(AD_Table_TableName)
				|| AD_Column_ColumnName == null || "".equals(AD_Column_ColumnName)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Column_ColumnName or AD_Table_TableName or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Column_ColumnName or AD_Table_TableName or AD_Client_Value is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Column_ColumnName or AD_Table_TableName or AD_Client_Value is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Column_Access "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_Column_ID = ? "  // #4
			+ "  AND AD_Table_ID = ? "  // #5
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_Column_ID);
	    pstmt.setInt(5, AD_Table_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_Column_Access columnAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	columnAccess = new X_AD_Column_Access(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	columnAccess = new X_AD_Column_Access(Env.getCtx(), 0, null);
	    }
		
	    //columnAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
	    columnAccess.setAD_Org_ID(AD_Org_ID);
	    columnAccess.setAD_Role_ID(AD_Role_ID);
	    columnAccess.setAD_Column_ID(AD_Column_ID);
	    columnAccess.setAD_Table_ID(AD_Table_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Column_Access_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			columnAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}

		String IsReadOnly = XMLHelper.getString("IsReadOnly", AD_Column_Access_node);
		log.info("IsReadOnly = " + IsReadOnly);
		if (IsReadOnly != null && !"".equals(IsReadOnly)) {
			columnAccess.setIsReadOnly(IsReadOnly.equals("Y") ? true : false);
		}
		
		String IsExclude = XMLHelper.getString("IsExclude", AD_Column_Access_node);
		log.info("IsExclude = " + IsExclude);
		if (IsExclude != null && !"".equals(IsExclude)) {
			columnAccess.setIsExclude(IsExclude.equals("Y") ? true : false);
		}
		
		boolean resultSave = columnAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}
	
	public void process_AD_Form_Access(Node AD_Form_Access_node, Element outElement)
		throws DOMException, SQLException, XPathExpressionException, ImportException
	{
		
		String AD_Client_Value = null;
		int    AD_Client_ID = 0;
		
		String AD_Org_Value = null;
		int    AD_Org_ID = 0;
	
		String CreatedBy_Name = null;
		int    CreatedBy_ID = 0;
		
		String AD_Role_Name = null;
		int    AD_Role_ID = 0;
		
		String AD_Form_Name = null;
		int    AD_Form_ID = 0;
		
		AD_Client_Value = XMLHelper.getString("AD_Client_Value", AD_Form_Access_node);
		log.info("AD_Client_Value = [" + AD_Client_Value +"]");
		
		AD_Org_Value = XMLHelper.getString("AD_Org_Value", AD_Form_Access_node);
		log.info("AD_Org_Value = [" + AD_Org_Value +"]");
		
		AD_Role_Name = XMLHelper.getString("AD_Role_Name", AD_Form_Access_node);
		log.info("AD_Role_Name = [" + AD_Role_Name +"]");		
		
		AD_Form_Name = XMLHelper.getString("AD_Form_Name", AD_Form_Access_node);
		log.info("AD_Form_Value = [" + AD_Form_Name +"]");
		
		log.info("_______________________________________________");
		
		// Search for AD_Client_ID by Value...
		AD_Client_ID = XMLHelper.getIDbyValue("AD_Client", AD_Client_Value, AD_Client_Value);
		log.info("AD_Client_ID = " + AD_Client_ID);
		
		// Search for AD_Org_ID by Value...
		AD_Org_ID = XMLHelper.getIDbyValue("AD_Org", AD_Org_Value, AD_Client_Value);
		log.info("AD_Org_ID = " + AD_Org_ID);
		
		// Search for AD_Role by Name...
		AD_Role_ID = XMLHelper.getIDbyName("AD_Role", AD_Role_Name, AD_Client_Value);
		log.info("AD_Role_ID = " + AD_Role_ID);
		
		// Search for AD_form by Name...
		AD_Form_ID = XMLHelper.getIDbyName("AD_Form", AD_Form_Name, AD_Client_Value);
		log.info("AD_Form_ID = " + AD_Form_ID);
		
		if (
				AD_Client_Value == null || "".equals(AD_Client_Value) 
				|| AD_Org_Value == null || "".equals(AD_Org_Value)
				|| AD_Role_Name == null || "".equals(AD_Role_Name)
				|| AD_Form_Name == null || "".equals(AD_Form_Name)
			) 
		{
			log.error("ERROR: AD_Org_Value or AD_Role_Name or AD_Process_Value or AD_Client_Value is null...");
			System.out.println("ERROR: AD_Org_Value or AD_Role_Name or AD_Fomr_Name or AD_Form_Name is null...");
			throw new ImportException("AD_Org_Value or AD_Role_Name or AD_Fomr_Name or AD_Form_Name is null...");
		}
		
		String sql = "SELECT * "
			+ " FROM AD_Form_Access "
			+ " WHERE AD_Client_ID = ? " // #1
			+ "  AND AD_Org_ID = ? "     // #2
			+ "  AND AD_Role_ID = ? "    // #3
			+ "  AND AD_Form_ID = ? "    // #4
		;
		
		PreparedStatement pstmt = DB.prepareStatement(sql, null);
	    pstmt.setInt(1, AD_Client_ID);
	    pstmt.setInt(2, AD_Org_ID);
	    pstmt.setInt(3, AD_Role_ID);
	    pstmt.setInt(4, AD_Form_ID);
	    ResultSet rs = pstmt.executeQuery();
	    
	    X_AD_Form_Access formAccess = null;
	    
	    // Search for AD_User by Name...
		CreatedBy_ID = XMLHelper.getIDbyName("AD_User", CreatedBy_Name, AD_Client_Value);
		log.info("CreatedBy_ID = " + CreatedBy_ID);
		if (CreatedBy_Name != null && !"".equals(CreatedBy_Name)) {
			//adRole.set_ValueNoCheck("CreatedBy", CreatedBy_ID);
			Env.setContext(Env.getCtx(), "#AD_User_ID", CreatedBy_ID);
		}
		Env.setContext(Env.getCtx(), "#AD_Client_ID", AD_Client_ID);
	    Env.setContext(Env.getCtx(), "#AD_Org_ID", AD_Org_ID);
	    
	    if (rs.next()) {
	    	log.info("--- Record FOUND ---");
	    	formAccess = new X_AD_Form_Access(Env.getCtx(), rs, null);
	    } else {
	    	// Create new one
	    	log.info("--- Record NOT FOUND ---");
	    	formAccess = new X_AD_Form_Access(Env.getCtx(), 0, null);
	    }
		
		//formAccess.set_ValueNoCheck ("AD_Client_ID", new Integer(AD_Client_ID));
		formAccess.setAD_Org_ID(AD_Org_ID);
		formAccess.setAD_Role_ID(AD_Role_ID);
		formAccess.setAD_Form_ID(AD_Form_ID);
		
		String IsActive = XMLHelper.getString("IsActive", AD_Form_Access_node);
		log.info("IsActive = " + IsActive);
		if (IsActive != null && !"".equals(IsActive)) {
			formAccess.setIsActive(IsActive.equals("Y") ? true : false);
		}
		
		String IsReadWrite = XMLHelper.getString("IsReadWrite", AD_Form_Access_node);
		log.info("IsReadWrite = " + IsReadWrite);
		if (IsReadWrite != null && !"".equals(IsReadWrite)) {
			formAccess.setIsReadWrite(IsReadWrite.equals("Y") ? true : false);
		}
		
		boolean resultSave = formAccess.save();
		log.info("--- RESULT SAVE = " + resultSave);
	}
	
		
}
