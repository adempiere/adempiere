package org.compiere.compilo.importer.core;

import java.sql.SQLException;

import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.logging.Log;

import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public abstract class TableImporter {
	
	private String tableName;
	
	private String description;
	
	private String rootElement;
	
	protected Log log;
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	public abstract void importTable(Node ad_Role_Node, Element outElement) 
		throws DOMException, SQLException, XPathExpressionException, ImportException;

	/**
	 * @param log The log to set.
	 */
	public void setLog(Log log) {
		this.log = log;
		
	}

	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}
		
}
