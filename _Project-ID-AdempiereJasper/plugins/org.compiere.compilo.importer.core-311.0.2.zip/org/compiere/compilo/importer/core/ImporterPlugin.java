package org.compiere.compilo.importer.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

import org.compiere.Adempiere;
import org.compiere.compilo.XML2AD;
import org.compiere.compilo.importer.Importer;
import org.compiere.db.CConnection;
import org.compiere.db.Database;
import org.compiere.util.CLogMgt;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.compiere.util.Ini;
import org.compiere.util.Login;
import org.java.plugin.boot.Application;
import org.java.plugin.boot.ApplicationPlugin;
import org.java.plugin.registry.Extension;
import org.java.plugin.registry.ExtensionPoint;
import org.java.plugin.registry.PluginDescriptor;
import org.java.plugin.registry.Extension.Parameter;
import org.java.plugin.util.ExtendedProperties;

public class ImporterPlugin extends ApplicationPlugin 
						 implements Application 
{

	/**
     * This plug-in ID.
     */
    public static final String PLUGIN_ID = "org.compiere.compilo.importer.core";
    
    /*
     * Name of extrension point. Defined in plugin.xml
     */
    public static final String TABLE_IMPORTER = "TableImporter";
    
    
    /*
     * Data folder where plugins can store data
     */
    public static final String DATA_FOLDER = "dataFolder";
    
    private File dataFolder;
    
    // Compiere properties
    public static final String IS_CLIENT = "isClient";
    
    private boolean isClient = true;
    
    private File mappingFile;
    
    private File xsdFile;
    
    private File outputFile;
    
    private boolean forceConnection = false;
    private String db_host;
    private int    db_port;
    private String db_name;
    private String db_uid;
    private String db_pwd;
    
    private String uid_value;
    private String pwd_value;
    private String role_value;
    private String client_value;
    private String org_value;
    private String warehouse_value;
    private String language_value;

    // TODO; this must be removed and migrated only to DOM implementation of imports...
    // Means get rid of XML2AD class and HM2ADHandler
    /*
     * Indicate if we will start XML2AD
     * 
     */
	private boolean startXML2AD;

	private File fml2adFile;
    
	public void startApplication() throws Exception {
		log.debug("--- startApplication ---------------------------");
	    Date end;
	    Date start;

	    Adempiere.startup(isClient);
		//CLogMgt.setLoggerLevel(Level.INFO, null);
		//CLogMgt.setLevel(Level.INFO);
		log.debug("--- startApplication 2222 ---------------------------");
		//
	    Ini.setProperty(Ini.P_UID,       uid_value);
		Ini.setProperty(Ini.P_PWD,       pwd_value);
		Ini.setProperty(Ini.P_ROLE,      role_value);
		Ini.setProperty(Ini.P_CLIENT,    client_value);
		Ini.setProperty(Ini.P_ORG,       org_value);
		Ini.setProperty(Ini.P_WAREHOUSE, warehouse_value);
		Ini.setProperty(Ini.P_LANGUAGE,  language_value);

		Login login = new Login(Env.getCtx());

//		if (!login.batchLogin(null)) {
//			System.out.println("EXITING abnormaly ....");
//			System.exit(1);	
//		}
		
		//
		CLogMgt.setLoggerLevel(Level.ALL, null);
		CLogMgt.setLevel(Level.ALL);

		// Force connection if there are enough parameters. Else we work with Compiere.properties
		if (forceConnection) {
		    CConnection cc = CConnection.get(Database.DB_ORACLE, db_host, db_port, db_name, db_uid, db_pwd);
		    log.debug("DB UserID:" + cc.getDbUid());
		    DB.setDBTarget(cc);
		}
		
		log.debug("mappingFile = " + mappingFile);
		System.out.println("mappingFile = " + mappingFile);
		if (mappingFile != null) {
			log.debug("mappingFile = " + mappingFile.getCanonicalPath());
			System.out.println("mappingFile = " + mappingFile.getCanonicalPath());
		}
		
		log.debug("xsdFile     = " + xsdFile);
		System.out.println("xsdFile     = " + xsdFile);
		if (xsdFile != null) {
			log.debug("xsdFile     = " + xsdFile.getCanonicalPath());
			System.out.println("xsdFile     = " + xsdFile.getCanonicalPath());
		}
		
		log.debug("outputFile  = " + outputFile);
		System.out.println("outputFile  = " + outputFile);
		if (outputFile != null) {
			log.debug("outputFile  = " + outputFile.getCanonicalPath());
			System.out.println("outputFile  = " + outputFile.getCanonicalPath());
		}
		
		// ------------------------------------------------------
		ExtensionPoint tableImporterExtPoint =
            getManager().getRegistry().getExtensionPoint(getDescriptor().getId(), TABLE_IMPORTER);
		
		List registeredPlugins = new ArrayList();
		
        for (Iterator it = tableImporterExtPoint.getConnectedExtensions().iterator();
                it.hasNext();) 
        {
            Extension ext = (Extension) it.next();
            log.info("ext.getId()    = " + ext.getId());
            
            Parameter classParam = ext.getParameter("class");
            log.info("classParam     = " + classParam);
            
            Parameter tableNameParam = ext.getParameter("tableName");
            log.info("tableNameParam = " + tableNameParam);
            String tableName = tableNameParam.valueAsString();
            
            Parameter descrParam = ext.getParameter("description");
            if (descrParam != null) {
            	descrParam.valueAsString();
            }
            log.info("descrParam     = " + descrParam);
            
            Parameter rootElementParam = ext.getParameter("rootElement");
            if (rootElementParam != null) {
            	rootElementParam.valueAsString();
            }
            log.info("rootElementParam     = " + rootElementParam);
            
            // Activate plug-in that declares extension.
            getManager().activatePlugin(ext.getDeclaringPluginDescriptor().getId());
            
            // Get plug-in class loader.
            ClassLoader classLoader = getManager().getPluginClassLoader(ext.getDeclaringPluginDescriptor());
            
            // Load ImportPlugin class.
            Class importPluginCls = classLoader.loadClass(classParam.valueAsString());
            
            
            // Create ImportPlugin instance.
            TableImporter importTablePlugin = (TableImporter) importPluginCls.newInstance();
            
            // Initialize class instance according to interface contract.
            importTablePlugin.setTableName(tableName);
            
            if (descrParam != null) {
            	importTablePlugin.setDescription(descrParam.valueAsString());
            }
            
            if (rootElementParam != null) {
            	importTablePlugin.setRootElement(rootElementParam.valueAsString());
            }
            
            importTablePlugin.setLog(log);
            
            registeredPlugins.add(importTablePlugin);
        }
        // ========================================
	    start = new Date();
	    if (startXML2AD) {
    		XML2AD impXML = new XML2AD();
    		impXML.importXML(fml2adFile.getCanonicalPath());
    	} else {
    		Importer importer = new Importer(mappingFile.getCanonicalPath(), xsdFile.getCanonicalPath(), "", "", outputFile.getCanonicalPath());
    		importer.doImportFromFile(registeredPlugins);
    	}
	    end = new Date();
	    
	    log.info("Execution time = " + (end.getTime() - start.getTime()));
	}
	
	protected void doStart() throws Exception {
		// not used because we start as application
	}

	protected void doStop() throws Exception {
		// not used bacause we start as application
	}
	
	/**
     * @see org.java.plugin.boot.ApplicationPlugin#initApplication(
     *      ExtendedProperties, String[])
     */
    protected Application initApplication(final ExtendedProperties config, final String[] args) throws Exception {
		log.debug("--- START initApplication ---------------------------");
		//
        dataFolder = new File(config.getProperty(DATA_FOLDER, "." + File.separator + "data"));
        dataFolder = dataFolder.getCanonicalFile();
        log.debug("data folder - " + dataFolder);
        if (!dataFolder.isDirectory() && !dataFolder.mkdirs()) {
            throw new Exception("data folder " + dataFolder + " not found");
        }
        
        String isClientStr = (String)config.getProperty(IS_CLIENT, "Y");
        log.debug("isClient - " + isClientStr);
        isClient = "Y".equals(isClientStr);
        
	    
    	if (args.length == 1) {
    		startXML2AD = true;
    		
    		// Test if file exits, we can read it and not directory.
    		fml2adFile = new File(args[0]);
		    if (!fml2adFile.exists() || !fml2adFile.canRead() || fml2adFile.isDirectory()) {
		    	throw new Exception("XML2AD file do NOT EXISTS or can NOT be read or IS directory!");
		    }
    	} else if (args.length < 3) {
    		throw new Exception("Not enough command line parameters!\r\nExample usage:\r\n   java CommandLineImporter <path to xml mapping file> <path to xsd file> <path to output xml file>");
    	} else {
    	    // Test if file exits, we can read it and not directory.
    	    mappingFile = new File(args[0]);
    	    if (!mappingFile.exists() || !mappingFile.canRead() || mappingFile.isDirectory()) {
    	    	throw new Exception("XML Mapping file do NOT EXISTS or can NOT be read or IS directory!");
    	    }
    	    // Test if file exits, we can read it and not directory.
    	    xsdFile = new File(args[1]);
    	    if (!xsdFile.exists() || !xsdFile.canRead() || xsdFile.isDirectory()) {
    	    	throw new Exception("XSF file do NOT EXISTS or can NOT be read or IS directory!");
    	    }
    	    // TODO, probably we should test if we have rights to create file and write to this file ...
    	    outputFile = new File(args[2]);
    	}
	    
	    if (args.length > 7) {
	    	forceConnection = true;
	    	db_host = args[3];
	    	db_port = Integer.parseInt(args[4]);
	    	db_name = args[5];
	    	db_uid  = args[6];
	    	db_pwd  = args[7];
	    }
	    
	    uid_value       = (String)config.getProperty(Ini.P_UID,       "SuperUser");
	    log.debug("uid_value       = " + uid_value);
	    pwd_value       = (String)config.getProperty(Ini.P_PWD,       "System");
	    log.debug("pwd_value       = " + pwd_value);
	    role_value      = (String)config.getProperty(Ini.P_ROLE,      "System Administrator");
	    log.debug("role_value      = " + role_value);
	    client_value    = (String)config.getProperty(Ini.P_CLIENT,    "System");
	    log.debug("client_value    = " + client_value);
	    org_value       = (String)config.getProperty(Ini.P_ORG,       "*");
	    log.debug("org_value       = " + org_value);
	    warehouse_value = (String)config.getProperty(Ini.P_WAREHOUSE, "");
	    log.debug("warehouse_value = " + warehouse_value);
	    language_value  = (String)config.getProperty(Ini.P_LANGUAGE,  "English");
	    log.debug("language_value  = " + language_value);
	    
	    log.debug("--- END initApplication ---------------------------");
	    
        return this;
    }
    
	/**
     * Returns folder where given plug-in can store it's data.
     * @param descr plug-in descriptor
     * @return plug-in data folder
     * @throws IOException if folder doesn't exist and can't be created
     */
    public File getDataFolder(final PluginDescriptor descr) throws IOException {
        File result = new File(dataFolder, descr.getId());
        if (!result.isDirectory() && !result.mkdirs()) {
            throw new IOException("can't create data folder " + result + " for plug-in " + descr.getId());
        }
        return result;
    }
    
}
