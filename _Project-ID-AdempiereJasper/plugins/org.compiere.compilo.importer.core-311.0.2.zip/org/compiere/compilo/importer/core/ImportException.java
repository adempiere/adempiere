package org.compiere.compilo.importer.core;

public class ImportException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6128612482744603905L;

	public ImportException(String string) {
		super(string);
	}
	
}
