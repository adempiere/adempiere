package org.compiere.compilo.importer;

import java.io.File;
import java.util.Date;
import java.util.logging.Level;

import org.compiere.Adempiere;
import org.compiere.db.CConnection;
import org.compiere.db.Database;
import org.compiere.util.CLogMgt;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.compiere.util.Ini;
import org.compiere.util.Login;

public class CommandLineImporter {

	/* 
	 * Invoikes DBSQL2XML program with parameters specified on command line.
	 */
  public static void main(String[] args) throws Exception {
    Date date;
    Date oldDate;

    if (args.length < 3) {
    	System.out.println("Example usage:");
    	System.out.println("   java CommandLineImporter <path to xml mapping file> <path to xsd file> <path to output xml file>");
    	System.exit(0);
    }
    File f = new File(args[0]);
    if (f.exists()) {
    	System.out.println("FILE EXISTS +++++++++++++");
    }
    
    boolean isClient = true;
    Adempiere.startup(isClient);
	CLogMgt.setLoggerLevel(Level.INFO, null);
	CLogMgt.setLevel(Level.INFO);
	//
	Ini.setProperty(Ini.P_UID,       "SuperUser");
	Ini.setProperty(Ini.P_PWD,       "System");
	Ini.setProperty(Ini.P_ROLE,      "System Administrator");
	Ini.setProperty(Ini.P_CLIENT,    "System");
	Ini.setProperty(Ini.P_ORG,       "*");
	Ini.setProperty(Ini.P_WAREHOUSE, "");
	Ini.setProperty(Ini.P_LANGUAGE,  "English");
	Login login = new Login(Env.getCtx());

//	if (!login.batchLogin(null)) {
//		System.out.println("EXITING abnormaly ....");
//		System.exit(1);	
//	}
	
	//
	CLogMgt.setLoggerLevel(Level.FINEST, null);
	CLogMgt.setLevel(Level.FINEST);

	// Force connection if there are enough parameters. Else we work with Compiere.properties
	if (args.length >= 6) {
	    CConnection cc = CConnection.get(Database.DB_ORACLE, args[1], Integer.valueOf(args[2]).intValue(), args[3], args[4], args[5]);
	    System.out.println("DB UserID:"+cc.getDbUid());
	    DB.setDBTarget(cc);
	}
	
    oldDate = new Date();
    Importer importer = new Importer(args[0], args[1], "", "", args[2]);
    importer.doImportFromFile(null);
    date = new Date();
    System.out.println("Execution time = " + (date.getTime() - oldDate.getTime()));

  }
  
}
